@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "ROOT=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%ROOT%scripts\bootstrap-mysql.ps1" -InstallRoot "%ROOT%"
if errorlevel 1 (
  powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('数据库启动失败，请重新启动电脑后再试。','齐沐堂门店管理系统')" >nul 2>nul
  exit /b 2
)
set "CFG=%USERPROFILE%\QimutangData\config\mysql.env"
for /f "usebackq tokens=1,* delims==" %%A in ("%CFG%") do (
  if /I "%%A"=="QIMUTANG_MYSQL_URL" set "QIMUTANG_MYSQL_URL=%%B"
  if /I "%%A"=="QIMUTANG_MYSQL_USER" set "QIMUTANG_MYSQL_USER=%%B"
  if /I "%%A"=="QIMUTANG_MYSQL_PASSWORD" set "QIMUTANG_MYSQL_PASSWORD=%%B"
)
set "SPRING_PROFILES_ACTIVE=mysql"
start "" "%ROOT%runtime\bin\javaw.exe" -Dfile.encoding=UTF-8 -jar "%ROOT%app\qimutang.jar" --spring.profiles.active=mysql
