@echo off
setlocal EnableExtensions
chcp 65001 >nul
where java >nul 2>nul || (echo 未检测到 JDK 17。& if not defined CI pause & exit /b 1)
where mvn >nul 2>nul || (echo 未检测到 Maven 3.9+。& if not defined CI pause & exit /b 1)
where jpackage >nul 2>nul || (echo 当前 JDK 不包含 jpackage，请安装完整 JDK 17。& if not defined CI pause & exit /b 1)

echo [1/3] 正在编译系统...
call mvn clean package
if errorlevel 1 (echo 编译失败。& if not defined CI pause & exit /b 1)

echo [2/3] 正在生成自带 Java 的 Windows 便携版...
if exist dist-portable rmdir /s /q dist-portable
jpackage --type app-image --name "齐沐堂门店管理系统" --app-version 2.5.0 --vendor "齐沐堂" --description "齐沐堂单店本地管理系统" --input target --main-jar qimutang.jar --dest dist-portable --icon "packaging\qimutang.ico" --java-options "-Dfile.encoding=UTF-8"
if errorlevel 1 (echo 便携版生成失败。& if not defined CI pause & exit /b 1)

echo [3/3] 正在压缩交付包...
powershell -NoProfile -Command "Compress-Archive -Path 'dist-portable\齐沐堂门店管理系统' -DestinationPath 'dist-portable\齐沐堂门店管理系统-2.5.0-Windows便携版.zip' -Force"
if errorlevel 1 (echo 压缩失败，但程序目录已经生成。& if not defined CI pause & exit /b 1)

echo.
echo 已生成：dist-portable\齐沐堂门店管理系统-2.5.0-Windows便携版.zip
echo 解压后双击“齐沐堂门店管理系统.exe”即可使用，无需另装 Java。
if not defined CI pause
