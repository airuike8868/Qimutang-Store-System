[CmdletBinding()]
param([string]$InstallRoot = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference='Stop'
$mysqlRoot = Join-Path $InstallRoot 'mysql'
$mysqld = Join-Path $mysqlRoot 'bin\mysqld.exe'
$mysql = Join-Path $mysqlRoot 'bin\mysql.exe'
$mysqladmin = Join-Path $mysqlRoot 'bin\mysqladmin.exe'
if (!(Test-Path $mysqld) -or !(Test-Path $mysql)) { throw '安装包缺少 MySQL 8.4 运行环境，请重新安装齐沐堂。' }
$dataBase = Join-Path $env:USERPROFILE 'QimutangData'
$dataDir = Join-Path $dataBase 'mysql-data'
$configDir = Join-Path $dataBase 'config'
$envFile = Join-Path $configDir 'mysql.env'
$myIni = Join-Path $configDir 'mysql-embedded.ini'
$logDir = Join-Path $dataBase 'logs'
New-Item -ItemType Directory -Force -Path $configDir,$logDir | Out-Null
$port = 3307
if (!(Test-Path (Join-Path $dataDir 'mysql'))) {
  New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
  & $mysqld --initialize-insecure --basedir="$mysqlRoot" --datadir="$dataDir" --console
  if ($LASTEXITCODE -ne 0) { throw 'MySQL 首次初始化失败。' }
}
@(
 '[mysqld]',
 "basedir=$($mysqlRoot -replace '\\','/')",
 "datadir=$($dataDir -replace '\\','/')",
 "port=$port",
 'bind-address=127.0.0.1',
 'character-set-server=utf8mb4',
 'collation-server=utf8mb4_0900_ai_ci',
 'skip-name-resolve',
 "log-error=$((Join-Path $logDir 'mysql-error.log') -replace '\\','/')"
) | Set-Content -LiteralPath $myIni -Encoding ASCII
$ready=$false
try { & $mysqladmin --protocol=tcp -h127.0.0.1 -P$port ping --silent 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) {$ready=$true} } catch {}
if (!$ready) {
  Start-Process -FilePath $mysqld -ArgumentList @("--defaults-file=$myIni") -WindowStyle Hidden
  for($i=0;$i -lt 60;$i++){ Start-Sleep -Milliseconds 500; try { & $mysqladmin --protocol=tcp -h127.0.0.1 -P$port ping --silent 2>$null | Out-Null; if($LASTEXITCODE -eq 0){$ready=$true;break} } catch {} }
}
if (!$ready) { throw 'MySQL 启动失败，请查看 QimutangData\logs\mysql-error.log。' }
if (!(Test-Path $envFile)) {
  $bytes = New-Object byte[] 24; [Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
  $appPass = ([Convert]::ToBase64String($bytes)).Replace('/','_').Replace('+','-').TrimEnd('=')
  $bytes2 = New-Object byte[] 24; [Security.Cryptography.RandomNumberGenerator]::Fill($bytes2)
  $rootPass = ([Convert]::ToBase64String($bytes2)).Replace('/','_').Replace('+','-').TrimEnd('=')
  $sql = @"
CREATE DATABASE IF NOT EXISTS qimutang CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE USER IF NOT EXISTS 'qimutang'@'127.0.0.1' IDENTIFIED BY '$appPass';
ALTER USER 'qimutang'@'127.0.0.1' IDENTIFIED BY '$appPass';
GRANT ALL PRIVILEGES ON qimutang.* TO 'qimutang'@'127.0.0.1';
ALTER USER 'root'@'localhost' IDENTIFIED BY '$rootPass';
FLUSH PRIVILEGES;
"@
  $tmp = Join-Path $env:TEMP "qimutang-mysql-init-$PID.sql"; Set-Content -LiteralPath $tmp -Value $sql -Encoding UTF8
  cmd /c "`"$mysql`" --protocol=tcp -h127.0.0.1 -P$port -uroot < `"$tmp`""
  Remove-Item $tmp -Force -ErrorAction SilentlyContinue
  if ($LASTEXITCODE -ne 0) { throw 'MySQL 数据库账号初始化失败。' }
  @(
    "QIMUTANG_MYSQL_URL=jdbc:mysql://127.0.0.1:$port/qimutang?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&allowPublicKeyRetrieval=true",
    'QIMUTANG_MYSQL_USER=qimutang',
    "QIMUTANG_MYSQL_PASSWORD=$appPass"
  ) | Set-Content -LiteralPath $envFile -Encoding UTF8
  try { icacls $envFile /inheritance:r /grant:r "$env:USERNAME:(F)" | Out-Null } catch {}
}
Write-Output $envFile
