#!/usr/bin/env python3
"""Build the offline Windows installer from the tested application JAR."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import struct
import subprocess
import tempfile
from pathlib import Path


VERSION = "2.5.0"
APP_DIR_NAME = "QimutangStore"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require_file(path: Path, label: str) -> Path:
    path = path.resolve()
    if not path.is_file():
        raise SystemExit(f"Missing {label}: {path}")
    return path


def require_dir(path: Path, label: str) -> Path:
    path = path.resolve()
    if not path.is_dir():
        raise SystemExit(f"Missing {label}: {path}")
    return path


def check_pe(path: Path) -> None:
    with path.open("rb") as stream:
        if stream.read(2) != b"MZ":
            raise SystemExit(f"Not a Windows executable: {path}")


def ico_images(path: Path) -> dict[int, list[tuple[int, int, int, int]]]:
    data = path.read_bytes()
    reserved, image_type, count = struct.unpack_from("<HHH", data, 0)
    if reserved != 0 or image_type != 1:
        raise SystemExit(f"Not an ICO file: {path}")
    images: dict[int, list[tuple[int, int, int, int]]] = {}
    for index in range(count):
        entry = 6 + index * 16
        width, height, _, _, planes, bits, size, offset = struct.unpack_from(
            "<BBBBHHII", data, entry
        )
        width = width or 256
        height = height or 256
        blob = data[offset:offset + size]
        if width not in (16, 32) or bits != 32 or blob.startswith(b"\x89PNG"):
            continue
        header_size, dib_width, dib_height = struct.unpack_from("<Iii", blob, 0)
        if header_size < 40 or dib_width != width or dib_height != height * 2 or planes != 1:
            continue
        pixel_offset = header_size
        pixels: list[tuple[int, int, int, int]] = []
        for top_y in range(height):
            row = height - 1 - top_y
            for x in range(width):
                blue, green, red, alpha = struct.unpack_from(
                    "<BBBB", blob, pixel_offset + (row * width + x) * 4
                )
                pixels.append((red, green, blue, alpha))
        images[width] = pixels
    if not all(size in images for size in (16, 32)):
        raise SystemExit(f"ICO lacks 16px/32px 32-bit images: {path}")
    return images


def make_4bit_icon(width: int, pixels: list[tuple[int, int, int, int]]) -> bytes:
    buckets: dict[tuple[int, int, int], list[int]] = {}
    for red, green, blue, alpha in pixels:
        if alpha < 96:
            continue
        key = (red // 16, green // 16, blue // 16)
        item = buckets.setdefault(key, [0, 0, 0, 0])
        item[0] += 1
        item[1] += red
        item[2] += green
        item[3] += blue
    ranked = sorted(buckets.values(), key=lambda item: item[0], reverse=True)
    palette = [
        (item[1] // item[0], item[2] // item[0], item[3] // item[0])
        for item in ranked[:16]
    ]
    while len(palette) < 16:
        palette.append((0, 0, 0))

    def nearest(red: int, green: int, blue: int) -> int:
        return min(
            range(16),
            key=lambda index: (
                (palette[index][0] - red) ** 2
                + (palette[index][1] - green) ** 2
                + (palette[index][2] - blue) ** 2
            ),
        )

    xor_stride = ((width * 4 + 31) // 32) * 4
    mask_stride = ((width + 31) // 32) * 4
    xor_data = bytearray()
    mask_data = bytearray()
    for bottom_y in range(width):
        top_y = width - 1 - bottom_y
        row_indexes = []
        row_mask = bytearray(mask_stride)
        for x in range(width):
            red, green, blue, alpha = pixels[top_y * width + x]
            row_indexes.append(nearest(red, green, blue))
            if alpha < 96:
                row_mask[x // 8] |= 0x80 >> (x % 8)
        packed = bytearray()
        for x in range(0, width, 2):
            packed.append((row_indexes[x] << 4) | row_indexes[x + 1])
        packed.extend(b"\0" * (xor_stride - len(packed)))
        xor_data.extend(packed)
        mask_data.extend(row_mask)

    header = struct.pack(
        "<IiiHHIIiiII",
        40, width, width * 2, 1, 4, 0, len(xor_data), 0, 0, 16, 0,
    )
    color_table = b"".join(
        struct.pack("<BBBB", blue, green, red, 0) for red, green, blue in palette
    )
    return header + color_table + bytes(xor_data) + bytes(mask_data)


def patch_sfx_icon(source: Path, icon: Path, destination: Path) -> None:
    data = bytearray(source.read_bytes())
    pe_offset = struct.unpack_from("<I", data, 0x3C)[0]
    section_count = struct.unpack_from("<H", data, pe_offset + 6)[0]
    optional_offset = pe_offset + 24
    optional_size = struct.unpack_from("<H", data, pe_offset + 20)[0]
    magic = struct.unpack_from("<H", data, optional_offset)[0]
    directory_offset = optional_offset + (112 if magic == 0x20B else 96)
    resource_rva, _ = struct.unpack_from("<II", data, directory_offset + 16)
    section_offset = optional_offset + optional_size
    sections = []
    for index in range(section_count):
        offset = section_offset + index * 40
        virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from(
            "<IIII", data, offset + 8
        )
        sections.append((virtual_address, max(virtual_size, raw_size), raw_offset))

    def rva_to_offset(rva: int) -> int:
        for virtual_address, size, raw_offset in sections:
            if virtual_address <= rva < virtual_address + size:
                return raw_offset + rva - virtual_address
        raise SystemExit(f"SFX resource RVA is invalid: {rva:#x}")

    resource_base = rva_to_offset(resource_rva)
    leaves: list[tuple[list[int], int, int]] = []

    def walk(relative: int, path: list[int]) -> None:
        directory = resource_base + relative
        named, ids = struct.unpack_from("<HH", data, directory + 12)
        for index in range(named + ids):
            entry = directory + 16 + index * 8
            name, target = struct.unpack_from("<II", data, entry)
            if name & 0x80000000:
                continue
            current = path + [name]
            if target & 0x80000000:
                walk(target & 0x7FFFFFFF, current)
            else:
                data_entry = resource_base + target
                payload_rva, payload_size = struct.unpack_from("<II", data, data_entry)
                leaves.append((current, rva_to_offset(payload_rva), payload_size))

    walk(0, [])
    source_images = ico_images(icon)
    replaced = set()
    for path, payload_offset, payload_size in leaves:
        if not path or path[0] != 3:
            continue
        width = struct.unpack_from("<i", data, payload_offset + 4)[0]
        if width not in source_images:
            continue
        replacement = make_4bit_icon(width, source_images[width])
        if len(replacement) != payload_size:
            raise SystemExit(
                f"SFX icon slot size mismatch for {width}px: {len(replacement)} != {payload_size}"
            )
        data[payload_offset:payload_offset + payload_size] = replacement
        replaced.add(width)
    if replaced != {16, 32}:
        raise SystemExit(f"Could not replace both SFX icon sizes: {sorted(replaced)}")
    destination.write_bytes(data)


def write_installer(sfx: Path, config: bytes, archive: Path, output: Path) -> None:
    with output.open("wb") as target:
        for source in (sfx,):
            with source.open("rb") as stream:
                shutil.copyfileobj(stream, target, 1024 * 1024)
        target.write(config)
        with archive.open("rb") as stream:
            shutil.copyfileobj(stream, target, 1024 * 1024)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--runtime", required=True, type=Path)
    parser.add_argument("--sfx", required=True, type=Path)
    parser.add_argument("--sevenzip", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--mysql", required=True, type=Path)
    args = parser.parse_args()

    project = require_dir(args.project, "project directory")
    runtime = require_dir(args.runtime, "Windows Java runtime")
    sfx = require_file(args.sfx, "7-Zip installer SFX")
    sevenzip = require_file(args.sevenzip, "7-Zip command")
    mysql_runtime = require_dir(args.mysql, "MySQL runtime")
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    jar = require_file(project / "app" / "qimutang.jar", "application JAR")
    icon = require_file(project / "packaging" / "qimutang.ico", "application icon")
    setup_script = require_file(
        project / "packaging" / "windows-installer" / "setup.ps1", "setup script"
    )
    uninstall_script = require_file(
        project / "packaging" / "windows-installer" / "uninstall.ps1", "uninstall script"
    )
    notices = require_file(
        project / "packaging" / "windows-installer" / "第三方组件说明.txt", "notices"
    )
    javaw = require_file(runtime / "bin" / "javaw.exe", "Windows javaw.exe")
    check_pe(javaw)
    check_pe(sfx)

    with tempfile.TemporaryDirectory(prefix="qimutang-installer-") as temp_name:
        temp = Path(temp_name)
        payload = temp / "payload"
        app_root = payload / APP_DIR_NAME
        (app_root / "app").mkdir(parents=True)
        shutil.copy2(jar, app_root / "app" / "qimutang.jar")
        shutil.copytree(runtime, app_root / "runtime")
        shutil.copytree(mysql_runtime, app_root / "mysql")
        shutil.copytree(project / "scripts", app_root / "scripts")
        shutil.copy2(project / "start-qimutang.cmd", app_root / "start-qimutang.cmd")
        shutil.copy2(icon, app_root / "qimutang.ico")
        shutil.copy2(uninstall_script, app_root / "uninstall.ps1")
        shutil.copy2(notices, app_root / "第三方组件说明.txt")
        shutil.copy2(project / "Windows使用说明.txt", app_root / "Windows使用说明.txt")
        shutil.copy2(setup_script, payload / "setup.ps1")

        patched_sfx = temp / "qimutang-installer.sfx"
        patch_sfx_icon(sfx, icon, patched_sfx)

        archive = temp / "payload.7z"
        subprocess.run(
            [
                str(sevenzip), "a", "-t7z", "-mx=9", "-m0=lzma2", "-ms=on",
                "-mmt=on", str(archive), ".",
            ],
            cwd=payload,
            check=True,
        )

        config = (
            ";!@Install@!UTF-8!\n"
            f'Title="齐沐堂门店管理系统 {VERSION} 安装程序"\n'
            'BeginPrompt="安装齐沐堂门店管理系统 2.5.0 MySQL版？程序自带 Java 17，不需要另外安装。"\n'
            'Progress="yes"\n'
            'Directory=""\n'
            'RunProgram="powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden '
            '-File \\\"%%T\\\\setup.ps1\\\""\n'
            ";!@InstallEnd@!\n"
        ).encode("utf-8")
        write_installer(patched_sfx, config, archive, output)

        subprocess.run([str(sevenzip), "t", str(output)], check=True)

    metadata = {
        "name": output.name,
        "version": VERSION,
        "size_bytes": output.stat().st_size,
        "sha256": sha256(output),
        "bundled_java": "Microsoft Build of OpenJDK 17.0.20, Windows x64, jlink runtime",
        "application_jar_sha256": sha256(jar),
        "offline": True,
        "bundled_mysql": "MySQL Community Server 8.4 LTS, Windows x64",
        "per_user_install": True,
    }
    metadata_path = output.with_suffix(output.suffix + ".json")
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", "utf-8")
    print(json.dumps(metadata, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
