package com.qimutang;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.ResultSet;
import java.util.*;
import java.util.zip.*;

/** Application-level MySQL logical backup, so backups do not depend on mysqldump being on PATH. */
final class MySqlLogicalBackup {
    private final JdbcTemplate db;
    private final ObjectMapper json = new ObjectMapper();
    private final Path uploads;

    MySqlLogicalBackup(JdbcTemplate db, Path uploads) { this.db = db; this.uploads = uploads; }

    void exportTo(Path target) throws Exception {
        Path temp = target.resolveSibling(target.getFileName() + ".part");
        Files.deleteIfExists(temp);
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(temp, StandardOpenOption.CREATE_NEW)))) {
            zip.putNextEntry(new ZipEntry("mysql-data.jsonl"));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(zip, StandardCharsets.UTF_8));
            for (String table : tables()) {
                for (Map<String,Object> row : db.queryForList("select * from " + table)) {
                    Map<String,Object> record = new LinkedHashMap<>();
                    record.put("table", table);
                    record.put("row", row);
                    writer.write(json.writeValueAsString(record));
                    writer.newLine();
                }
            }
            writer.flush();
            zip.closeEntry();
            if (uploads != null && Files.isDirectory(uploads)) {
                try (var walk = Files.walk(uploads)) {
                    for (Path file : walk.filter(Files::isRegularFile).toList()) {
                        String name = "uploads/" + uploads.relativize(file).toString().replace('\\','/');
                        zip.putNextEntry(new ZipEntry(name));
                        Files.copy(file, zip);
                        zip.closeEntry();
                    }
                }
            }
            zip.putNextEntry(new ZipEntry("backup-info.txt"));
            zip.write(("齐沐堂门店管理系统 2.5.0 MySQL 整包备份\n格式：mysql-data.jsonl + uploads\n生成时间：" + java.time.LocalDateTime.now() + "\n").getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        try { Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException e) { Files.move(temp,target,StandardCopyOption.REPLACE_EXISTING); }
    }

    @SuppressWarnings("unchecked")
    void restoreFrom(Path source) throws Exception {
        List<Map<String,Object>> records = new ArrayList<>();
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(Files.newInputStream(source)))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                if (!"mysql-data.jsonl".equals(entry.getName())) continue;
                BufferedReader reader = new BufferedReader(new InputStreamReader(zip, StandardCharsets.UTF_8));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.isBlank()) records.add(json.readValue(line, Map.class));
                }
                break;
            }
        }
        if (records.isEmpty()) throw new IllegalArgumentException("备份中没有 MySQL 数据");
        Path stagedUploads = stageUploads(source);

        db.execute("set foreign_key_checks=0");
        try {
            List<String> tables = tables();
            Collections.reverse(tables);
            for (String table : tables) db.update("delete from " + table);
            for (Map<String,Object> record : records) {
                String table = String.valueOf(record.get("table"));
                if (!safe(table) || !tables().contains(table)) continue;
                Map<String,Object> row = (Map<String,Object>) record.get("row");
                if (row == null || row.isEmpty()) continue;
                List<String> cols = new ArrayList<>(row.keySet());
                if (cols.stream().anyMatch(c -> !safe(c))) continue;
                String placeholders = String.join(",", Collections.nCopies(cols.size(), "?"));
                String sql = "insert into " + table + "(" + String.join(",", cols) + ") values(" + placeholders + ")";
                Object[] values = cols.stream().map(row::get).toArray();
                db.update(sql, values);
            }
        } finally {
            db.execute("set foreign_key_checks=1");
        }
        if (stagedUploads != null) commitStagedUploads(stagedUploads);
    }

    private Path stageUploads(Path source) throws Exception {
        if (uploads == null) return null;
        Path parent = uploads.getParent();
        if (parent == null) return null;
        Path temp = parent.resolve("uploads.restore.tmp");
        if (Files.exists(temp)) try (var walk=Files.walk(temp)) { for (Path x:walk.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(x); }
        Files.createDirectories(temp);
        boolean found=false;
        try (ZipInputStream zip = new ZipInputStream(new BufferedInputStream(Files.newInputStream(source)))) {
            ZipEntry e;
            while ((e=zip.getNextEntry())!=null) {
                if (!e.getName().startsWith("uploads/") || e.isDirectory()) continue;
                Path out=temp.resolve(e.getName().substring("uploads/".length())).normalize();
                if (!out.startsWith(temp)) throw new IllegalArgumentException("备份包含非法文件路径");
                Files.createDirectories(out.getParent()); Files.copy(zip,out,StandardCopyOption.REPLACE_EXISTING); found=true;
            }
        }
        if (!found) { try(var walk=Files.walk(temp)){for(Path x:walk.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(x);} return null; }
        return temp;
    }

    private void commitStagedUploads(Path temp) throws Exception {
        Path parent = uploads.getParent();
        Path old=parent.resolve("uploads.restore.old");
        if(Files.exists(old))try(var walk=Files.walk(old)){for(Path x:walk.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(x);}
        if(Files.exists(uploads))Files.move(uploads,old,StandardCopyOption.REPLACE_EXISTING);
        Files.move(temp,uploads,StandardCopyOption.REPLACE_EXISTING);
        if(Files.exists(old))try(var walk=Files.walk(old)){for(Path x:walk.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(x);}
    }

    private List<String> tables() throws Exception {
        List<String> out = new ArrayList<>();
        db.execute(connection -> {
            try (ResultSet rs = connection.getMetaData().getTables(connection.getCatalog(), null, "%", new String[]{"TABLE"})) {
                while (rs.next()) {
                    String table = rs.getString("TABLE_NAME");
                    if (safe(table)) out.add(table);
                }
            }
            return null;
        });
        out.removeIf(t -> t.equalsIgnoreCase("sys_config") || t.startsWith("mysql_"));
        out.sort(String::compareTo);
        return out;
    }

    private boolean safe(String value) { return value != null && value.matches("[A-Za-z0-9_]+"); }
}
