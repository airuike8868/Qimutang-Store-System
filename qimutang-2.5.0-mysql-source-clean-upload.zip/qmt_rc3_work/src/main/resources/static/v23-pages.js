const V23_PAYMENT_METHODS = ['微信', '支付宝', '现金', '银行卡', '美团', '抖音', '会员余额', '其他'];

function v23RequestId(prefix = 'REQ') {
  const random = window.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return `${prefix}-${random}`;
}

function v23CategoryManager(type, title, afterSaved) {
  api(`/v23/categories?type=${type}`).then(rows => {
    const box = modal(`${title}分类管理`, `
      <div class="notice compact">分类可自行新增、改名、排序或停用。改名会同步到当前项目/产品，历史订单仍保留成交时的分类。</div>
      <div class="category-list">${rows.map(row => `
        <button type="button" class="category-row" data-edit-category="${row.id}">
          <i style="background:${esc(row.color || '#146fca')}"></i>
          <span><b>${esc(row.name)}</b><small>排序 ${row.sort_order || 0}</small></span>
          ${statusTag(Number(row.enabled) ? '启用' : '停用')}
        </button>`).join('') || empty('还没有分类')}</div>
      <button type="button" id="v23-new-category" class="wide">新增${esc(title)}分类</button>
    `, async () => {}, { saveText: '关闭', wide: true });
    box.querySelector('#v23-new-category').addEventListener('click', () => v23CategoryForm(type, title, null, afterSaved));
    box.querySelectorAll('[data-edit-category]').forEach(button => button.addEventListener('click', () => {
      v23CategoryForm(type, title, rows.find(row => String(row.id) === button.dataset.editCategory), afterSaved);
    }));
  }).catch(showError);
}

function v23CategoryForm(type, title, row, afterSaved) {
  const editing = Boolean(row);
  modal(`${editing ? '编辑' : '新增'}${title}分类`, `
    ${field('分类名称 *', input('v23-category-name', '2至30个字', 'text', row?.name || ''))}
    <div class="form-grid two">
      ${field('显示排序', input('v23-category-sort', '数字越小越靠前', 'number', row?.sort_order || '0'))}
      ${field('标识颜色', input('v23-category-color', '分类颜色', 'color', row?.color || '#146fca'))}
      ${editing ? field('分类状态', select('v23-category-enabled', [{id: 'true', name: '启用'}, {id: 'false', name: '停用'}], 'name', Number(row.enabled) ? 'true' : 'false')) : ''}
    </div>
  `, async () => {
    const name = $('v23-category-name').value.trim();
    if (name.length < 2) throw new Error('分类名称至少2个字');
    const message = await api(editing ? `/v23/categories/${row.id}` : '/v23/categories', {
      method: editing ? 'PUT' : 'POST', body: JSON.stringify({
        type, name, sortOrder: Number($('v23-category-sort').value || 0),
        color: $('v23-category-color').value,
        enabled: editing ? $('v23-category-enabled').value === 'true' : true
      })
    });
    toast(message);
    if (afterSaved) await afterSaved();
  });
}

async function v23ServicesPage() {
  const [rows, categories] = await Promise.all([
    api('/services'), api('/v23/categories?type=SERVICE')
  ]);
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar"><button id="v23-new-service">新增项目</button><button id="v23-service-categories" class="ghost">管理项目大类</button><button id="v25-go-products" class="ghost">护理产品</button><button id="v25-go-packages" class="ghost">次卡/套餐</button></div>
    <div class="metric-grid project-metrics">
      <div class="metric primary"><span>全部服务项目</span><b>${rows.length}</b></div>
      <div class="metric"><span>护理服务</span><b>${rows.filter(r => (r.service_type || '普通服务') === '护理服务').length}</b></div>
      <div class="metric"><span>组合套餐</span><b>${rows.filter(r => r.service_type === '组合套餐').length}</b></div>
      <div class="metric"><span>当前上架</span><b>${rows.filter(r => Number(r.status)).length}</b></div>
    </div>
    <div class="notice compact"><b>2.5 项目中心：</b>普通服务、护理服务、组合套餐、护理产品、次卡统一管理。历史订单继续保留成交时的名称、分类和价格。</div>
    <div class="panel"><div class="panel-head"><div><h3>服务与组合项目</h3><p>服务大类可以自行新增；收银和业绩报表按该分类统计</p></div><span class="count-badge">${rows.length}</span></div>
      <div class="table-wrap"><table><thead><tr><th>项目</th><th>服务大类</th><th>时长</th><th>门市价</th><th>会员价</th><th>提成</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows.length ? rows.map(row => `
        <tr><td><b>${esc(row.name)}</b></td><td>${esc(row.category || '未分类')}</td><td>${Number(row.duration || 0)}分钟</td>
        <td>${money(row.list_price)}</td><td>${money(row.member_price)}</td><td>${row.commission_type === 'PERCENT' ? `${Number(row.commission_value || 0)}%` : money(row.commission_value)}</td>
        <td>${statusTag(Number(row.status) ? '上架' : '下架')}</td><td><button class="ghost small" data-v23-edit-service="${row.id}">编辑</button></td></tr>`).join('') : `<tr><td colspan="8">${empty('还没有服务项目')}</td></tr>`}</tbody></table></div>
    </div>`;
  $('v23-new-service').addEventListener('click', () => v23ServiceForm(null, categories));
  $('v23-service-categories').addEventListener('click', () => v23CategoryManager('SERVICE', '项目', v23ServicesPage));
  $('v25-go-products').addEventListener('click', () => { state.page = '护理产品'; render(); });
  $('v25-go-packages').addEventListener('click', () => { state.page = '次卡套餐'; render(); });
  content.querySelectorAll('[data-v23-edit-service]').forEach(button => button.addEventListener('click', () => {
    v23ServiceForm(rows.find(row => String(row.id) === button.dataset.v23EditService), categories);
  }));
}

function v23ServiceForm(service, categories) {
  const editing = Boolean(service);
  const activeCategories = categories.filter(row => Number(row.enabled));
  if (!activeCategories.length) return showError(new Error('请先新增并启用一个服务大类'));
  const chosen = activeCategories.some(row => row.name === service?.category) ? service?.category : activeCategories[0].name;
  modal(`${editing ? '编辑' : '新增'}服务项目`, `
    ${field('项目名称 *', input('v23-service-name', '例如：招牌修脚', 'text', service?.name || ''))}
    <div class="form-grid two">
      ${field('服务大类 *', select('v23-service-category', activeCategories.map(row => row.name), 'name', chosen))}
      ${field('服务时长（分钟）', input('v23-service-duration', '时长', 'number', service?.duration ?? '60', 'min="0"'))}
      ${field('项目类型', select('v23-service-type', ['普通服务', '护理服务', '组合套餐'], 'name', service?.service_type || '普通服务'))}
      ${field('计价单位', input('v23-service-unit', '次 / 单侧 / 双足', 'text', service?.unit || '次'))}
      ${field('门市价 *', input('v23-service-list-price', '门市价', 'number', service?.list_price ?? '', 'min="0" step="0.01"'))}
      ${field('会员价', input('v23-service-member-price', '不填则同门市价', 'number', service?.member_price ?? '', 'min="0" step="0.01"'))}
      ${field('最低销售价', input('v23-service-min-price', '低于此价需管理权限', 'number', service?.min_price ?? '0', 'min="0" step="0.01"'))}
      ${field('默认回访（天）', input('v23-service-followup-days', '0表示不自动回访', 'number', service?.followup_days ?? '0', 'min="0"'))}
      ${field('提成方式', select('v23-service-commission-type', [{id: 'FIXED', name: '固定金额'}, {id: 'PERCENT', name: '成交额百分比'}], 'name', service?.commission_type || 'FIXED'))}
      ${field('提成数值', input('v23-service-commission-value', '金额或百分比', 'number', service?.commission_value ?? '0', 'min="0" step="0.01"'))}
      ${editing ? field('项目状态', select('v23-service-status', [{id: 'true', name: '上架'}, {id: 'false', name: '下架'}], 'name', Number(service.status) ? 'true' : 'false')) : ''}
    </div>
    <label class="check-line"><input id="v23-care-required" type="checkbox" ${Number(service?.care_record_required) ? 'checked' : ''}><span><b>需要护理档案</b><small>适用于灰指甲、甲沟炎、嵌甲等长期护理</small></span></label>
    <label class="check-line"><input id="v23-photo-required" type="checkbox" ${Number(service?.photo_required) ? 'checked' : ''}><span><b>建议记录护理前后照片</b><small>用于护理过程追踪</small></span></label>
    ${field('备注', `<textarea id="v23-service-remark" placeholder="服务说明、适用情况等">${esc(service?.remark || '')}</textarea>`)}
  `, async () => {
    const listPrice = Number($('v23-service-list-price').value);
    const memberPrice = $('v23-service-member-price').value === '' ? listPrice : Number($('v23-service-member-price').value);
    const body = {
      name: $('v23-service-name').value.trim(), category: $('v23-service-category').value,
      duration: Number($('v23-service-duration').value || 0), listPrice, memberPrice,
      serviceType: $('v23-service-type').value, unit: $('v23-service-unit').value.trim() || '次',
      minPrice: Number($('v23-service-min-price').value || 0), followupDays: Number($('v23-service-followup-days').value || 0),
      careRecordRequired: $('v23-care-required').checked, photoRequired: $('v23-photo-required').checked,
      commissionType: $('v23-service-commission-type').value,
      commissionValue: Number($('v23-service-commission-value').value || 0),
      status: editing ? $('v23-service-status').value === 'true' : true,
      remark: $('v23-service-remark').value.trim()
    };
    if (!body.name) throw new Error('请输入项目名称');
    const message = await api(editing ? `/v23/services/${service.id}` : '/v23/services', {
      method: editing ? 'PUT' : 'POST', body: JSON.stringify(body)
    });
    toast(message);
    await v23ServicesPage();
  });
}

async function v23ProductsPage() {
  const [rows, categories] = await Promise.all([
    api('/v23/products'), api('/v23/categories?type=PRODUCT')
  ]);
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar"><button id="v23-new-product">新增护理产品</button><button id="v23-product-categories" class="ghost">管理产品分类</button></div>
    <div class="panel"><div class="panel-head"><div><h3>护理产品与库存</h3><p>产品在这里新增并开启“收银销售”，耗材也可保留为仅库存管理</p></div><span class="count-badge danger-bg">${rows.filter(row => Number(row.low_stock)).length} 项预警</span></div>
      <div class="table-wrap"><table><thead><tr><th>产品</th><th>分类</th><th>条码</th><th>库存</th><th>成本</th><th>零售价</th><th>会员价</th><th>收银上架</th><th>操作</th></tr></thead><tbody>${rows.length ? rows.map(row => `
        <tr class="${Number(row.low_stock) ? 'low-stock' : ''}"><td><b>${esc(row.name)}</b><small>${esc(row.product_type || '护理产品')}</small></td><td>${esc(row.category || '未分类')}</td><td>${esc(row.barcode || '-')}</td>
        <td><b>${Number(row.quantity || 0)} ${esc(row.unit || '')}</b><small>预警 ${Number(row.min_quantity || 0)}</small></td><td>${money(row.cost_price)}</td><td>${money(row.retail_price)}</td><td>${money(row.member_price)}</td>
        <td>${statusTag(Number(row.retail_enabled) ? '已上架' : '仅库存')}</td><td class="actions"><button class="ghost small" data-v23-edit-product="${row.id}">编辑</button><button class="small" data-v23-adjust-product="${row.id}">出入库</button><button class="ghost small" data-v23-product-log="${row.id}">流水</button></td></tr>`).join('') : `<tr><td colspan="9">${empty('还没有护理产品，点击上方按钮即可添加')}</td></tr>`}</tbody></table></div>
    </div>`;
  $('v23-new-product').addEventListener('click', () => v23ProductForm(null, categories));
  $('v23-product-categories').addEventListener('click', () => v23CategoryManager('PRODUCT', '产品', v23ProductsPage));
  content.querySelectorAll('[data-v23-edit-product]').forEach(button => button.addEventListener('click', () => v23ProductForm(rows.find(row => String(row.id) === button.dataset.v23EditProduct), categories)));
  content.querySelectorAll('[data-v23-adjust-product]').forEach(button => button.addEventListener('click', () => inventoryAdjust(rows.find(row => String(row.id) === button.dataset.v23AdjustProduct))));
  content.querySelectorAll('[data-v23-product-log]').forEach(button => button.addEventListener('click', () => inventoryLogs(Number(button.dataset.v23ProductLog))));
}

function v23ProductForm(product, categories) {
  const editing = Boolean(product);
  const activeCategories = categories.filter(row => Number(row.enabled));
  if (!activeCategories.length) return showError(new Error('请先新增并启用一个产品分类'));
  const chosen = activeCategories.some(row => row.name === product?.category) ? product?.category : activeCategories[0].name;
  modal(`${editing ? '编辑' : '新增'}护理产品`, `
    <div class="form-grid two">
      ${field('产品名称 *', input('v23-product-name', '例如：灰甲护理液', 'text', product?.name || ''))}
      ${field('产品分类 *', select('v23-product-category', activeCategories.map(row => row.name), 'name', chosen))}
      ${field('条码', input('v23-product-barcode', '扫码枪或手工输入', 'text', product?.barcode || ''))}
      ${field('单位 *', input('v23-product-unit', '瓶 / 盒 / 支', 'text', product?.unit || '瓶'))}
      ${!editing ? field('初始库存', input('v23-product-quantity', '当前实际库存', 'number', '0', 'min="0" step="0.01"')) : ''}
      ${field('最低库存', input('v23-product-min', '库存预警值', 'number', product?.min_quantity ?? '5', 'min="0" step="0.01"'))}
      ${field('成本价', input('v23-product-cost', '进货成本', 'number', product?.cost_price ?? '0', 'min="0" step="0.01"'))}
      ${field('零售价 *', input('v23-product-retail', '收银售价', 'number', product?.retail_price ?? '', 'min="0" step="0.01"'))}
      ${field('会员价', input('v23-product-member', '留0则按零售价', 'number', product?.member_price ?? '0', 'min="0" step="0.01"'))}
      ${field('类型', select('v23-product-type', ['护理产品', '店用耗材'], 'name', product?.product_type || '护理产品'))}
      ${field('销售提成方式', select('v23-product-commission-type', [{id: 'FIXED', name: '固定金额'}, {id: 'PERCENT', name: '成交额百分比'}], 'name', product?.commission_type || 'FIXED'))}
      ${field('销售提成数值', input('v23-product-commission-value', '金额或百分比', 'number', product?.commission_value ?? '0', 'min="0" step="0.01"'))}
      ${field('有效期', input('v23-product-expiry', '可不填', 'date', product?.expires_at || ''))}
      ${field('供应商', input('v23-product-supplier', '供应商名称', 'text', product?.supplier || ''))}
    </div>
    <label class="check-line"><input id="v23-product-retail-enabled" type="checkbox" ${editing ? (Number(product.retail_enabled) ? 'checked' : '') : 'checked'}><span><b>在收银台销售</b><small>勾选后，产品会出现在“收银开单”的护理产品页签</small></span></label>
    ${editing ? '<div class="notice compact">当前库存不能在编辑资料时直接改，请使用“出入库”，系统会保留库存流水。</div>' : ''}
  `, async () => {
    const body = {
      name: $('v23-product-name').value.trim(), category: $('v23-product-category').value,
      barcode: $('v23-product-barcode').value.trim(), unit: $('v23-product-unit').value.trim(),
      quantity: editing ? undefined : Number($('v23-product-quantity').value || 0),
      minQuantity: Number($('v23-product-min').value || 0), costPrice: Number($('v23-product-cost').value || 0),
      retailPrice: Number($('v23-product-retail').value || 0), memberPrice: Number($('v23-product-member').value || 0),
      productType: $('v23-product-type').value, commissionType: $('v23-product-commission-type').value,
      commissionValue: Number($('v23-product-commission-value').value || 0),
      expiresAt: $('v23-product-expiry').value || null, supplier: $('v23-product-supplier').value.trim(),
      retailEnabled: $('v23-product-retail-enabled').checked
    };
    if (!body.name || !body.unit) throw new Error('产品名称和单位不能为空');
    const result = await api(editing ? `/v23/products/${product.id}` : '/v23/products', {
      method: editing ? 'PUT' : 'POST', body: JSON.stringify(body)
    });
    toast(typeof result === 'string' ? result : result.message);
    await v23ProductsPage();
  }, { wide: true });
}

async function v23CheckoutPage() {
  const [customers, services, products, employees] = await Promise.all([
    api('/customers'), api('/services'), api('/v23/products?retailOnly=true'), api('/v23/employees/options')
  ]);
  const activeServices = services.filter(row => Number(row.status));
  let catalogType = 'SERVICE';
  let catalogCategory = '全部';
  let keyword = '';
  state.cart = [];
  state.payments = [];
  const content = $('content');
  content.innerHTML = `
    <div class="checkout-layout">
      <div class="panel catalog-panel">
        <div class="panel-head"><div><h3>选择服务或护理产品</h3><p>产品销售会自动扣库存，服务和产品都能分别指定员工</p></div></div>
        <div class="catalog-tools">
          <div class="segment"><button type="button" class="active" data-catalog-tab="SERVICE">服务项目</button><button type="button" data-catalog-tab="PRODUCT">护理产品</button></div>
          ${input('v23-catalog-search', '搜索名称 / 分类 / 产品条码')}
        </div>
        <div id="v23-category-filter" class="chip-row"></div>
        <div id="v23-catalog" class="service-grid"></div>
      </div>
      <div class="panel checkout-box">
        <div class="panel-head"><div><h3>本次结账</h3><p>后台按项目资料重新核价，避免前台篡改金额</p></div></div>
        ${field('顾客', select('v23-order-customer', customers, 'name', '', '散客（不留档）'))}
        <div id="v23-member-balance" class="member-hint"></div>
        <div id="v23-cart-box"></div>
        <div id="v23-price-reason-box"></div>
        <div class="pay-builder">
          ${select('v23-payment-method', V23_PAYMENT_METHODS)}
          ${input('v23-payment-amount', '支付金额', 'number', '', 'min="0" step="0.01"')}
          <button id="v23-add-payment" type="button">加入支付</button>
        </div>
        <div id="v23-payment-box"></div>
        ${field('订单备注', '<textarea id="v23-order-remark" placeholder="顾客要求、团购券号、特殊说明等"></textarea>')}
        <button id="v23-submit-order" class="wide">确认已收款并完成开单</button>
      </div>
    </div>`;

  const selectedCustomer = () => customers.find(row => String(row.id) === $('v23-order-customer').value);
  const defaultPrice = item => {
    const member = selectedCustomer();
    const memberPrice = Number(item.member_price || 0);
    const normal = Number(item.type === 'SERVICE' ? item.list_price : item.retail_price);
    return member && memberPrice > 0 ? memberPrice : normal;
  };
  const total = () => state.cart.reduce((sum, item) => sum + Number(item.price) * Number(item.quantity), 0);
  const paid = () => state.payments.reduce((sum, item) => sum + Number(item.amount), 0);
  const canChangePrice = ['管理员', '店长'].includes(state.user.role);

  const editCare = index => {
    const item = state.cart[index];
    if (!item?.careRequired) return;
    if (!selectedCustomer()) return showError(new Error('护理项目必须先选择顾客'));
    const care = item.care || {};
    const box = modal(`护理资料 · ${item.name}`, `
      <div class="notice compact">保存订单后会自动写入该顾客护理档案，并按项目设置自动生成回访任务。</div>
      <div class="chip-row"><button type="button" class="chip" data-care-template="甲沟炎">甲沟炎模板</button><button type="button" class="chip" data-care-template="灰指甲">灰指甲模板</button><button type="button" class="chip" data-care-template="嵌甲">嵌甲模板</button></div>
      <div class="form-grid two">
        ${field('左右脚 *', select('v24-care-foot', ['左脚', '右脚'], 'name', care.foot || ''))}
        ${field('具体脚趾 *', select('v24-care-toe', ['大拇趾', '第二趾', '第三趾', '第四趾', '第五趾'], 'name', care.toe || ''))}
        ${field('护理阶段', select('v24-care-stage', ['首次', '复查', '持续护理', '巩固护理'], 'name', care.stage || '首次'))}
        ${field('服务员工', `<span class="form-static">${esc(employees.find(e => String(e.id) === String(item.employeeId))?.name || '未指定')}</span>`)}
      </div>
      ${field('本次情况', `<textarea id="v24-care-description" placeholder="例如：右脚大拇趾甲缘扎肉、局部不适">${esc(care.description || '')}</textarea>`)}
      ${field('护理方案', `<textarea id="v24-care-plan" placeholder="本次处理及后续护理建议">${esc(care.plan || '')}</textarea>`)}
      <div class="form-grid two">
        ${field(`护理前照片${item.photoRequired ? ' *' : ''}`, '<input id="v24-care-before" type="file" accept="image/*">')}
        ${field('护理后照片', '<input id="v24-care-after" type="file" accept="image/*">')}
      </div>
      ${(care.beforePhoto || care.afterPhoto) ? `<div class="notice compact">已上传：${care.beforePhoto ? '护理前照片 ✓ ' : ''}${care.afterPhoto ? '护理后照片 ✓' : ''}</div>` : ''}
      ${field('备注', `<textarea id="v24-care-remark">${esc(care.remark || '')}</textarea>`)}
    `, async mask => {
      const upload = async input => {
        const file = mask.querySelector(input)?.files?.[0];
        if (!file) return '';
        const form = new FormData(); form.append('file', file);
        return api('/upload', {method: 'POST', body: form});
      };
      const beforePhoto = await upload('#v24-care-before') || care.beforePhoto || '';
      const afterPhoto = await upload('#v24-care-after') || care.afterPhoto || '';
      const next = {
        foot: mask.querySelector('#v24-care-foot').value,
        toe: mask.querySelector('#v24-care-toe').value,
        stage: mask.querySelector('#v24-care-stage').value,
        description: mask.querySelector('#v24-care-description').value.trim(),
        plan: mask.querySelector('#v24-care-plan').value.trim(),
        beforePhoto, afterPhoto,
        remark: mask.querySelector('#v24-care-remark').value.trim()
      };
      if (!next.foot || !next.toe) throw new Error('请选择左右脚和具体脚趾');
      if (item.photoRequired && !next.beforePhoto) throw new Error('该项目要求上传护理前照片');
      item.care = next;
      drawCart();
      toast('护理资料已填写');
    }, {wide: true, saveText: '保存护理资料'});
    box.querySelectorAll('[data-care-template]').forEach(button => button.addEventListener('click', () => {
      const templates = {
        '甲沟炎': {description: '甲缘扎肉/局部不适，记录红肿、肉芽及残甲情况。', plan: '精细清理甲缘与残甲，减少局部挤压；根据恢复情况安排复查，必要时评估嵌甲矫正。'},
        '灰指甲': {description: '记录受累趾甲数量、厚度、颜色、甲面及甲下碎屑情况。', plan: '清理增厚及松脆甲面，记录本次处理范围；配合日常足部清洁护理并按周期复查。'},
        '嵌甲': {description: '记录嵌入侧别、甲沟受压程度及当前不适情况。', plan: '精修嵌入甲缘，减少持续挤压；根据甲型和复发情况评估矫正及后续护理。'}
      };
      const t = templates[button.dataset.careTemplate];
      if (!t) return;
      box.querySelector('#v24-care-description').value = t.description;
      box.querySelector('#v24-care-plan').value = t.plan;
      toast(button.dataset.careTemplate + '护理模板已填入');
    }));
    return box;
  };

  const drawCatalog = () => {
    const source = (catalogType === 'SERVICE' ? activeServices.map(row => ({...row, type: 'SERVICE'})) : products.map(row => ({...row, type: 'PRODUCT'})));
    const categories = ['全部', ...new Set(source.map(row => row.category || '未分类'))];
    if (!categories.includes(catalogCategory)) catalogCategory = '全部';
    $('v23-category-filter').innerHTML = categories.map(name => `<button type="button" class="chip ${name === catalogCategory ? 'active' : ''}" data-v23-category="${esc(name)}">${esc(name)}</button>`).join('');
    const lowered = keyword.toLowerCase();
    const filtered = source.filter(row => (catalogCategory === '全部' || (row.category || '未分类') === catalogCategory)
      && `${row.name}${row.category || ''}${row.barcode || ''}`.toLowerCase().includes(lowered));
    $('v23-catalog').innerHTML = filtered.length ? filtered.map(row => {
      const out = row.type === 'PRODUCT' && Number(row.quantity) <= 0;
      const price = defaultPrice(row);
      return `<button type="button" class="service-card ${out ? 'disabled-card' : ''}" data-v23-catalog-item="${row.type}:${row.id}" ${out ? 'disabled' : ''}>
        <small>${esc(row.category || '未分类')} · ${row.type === 'PRODUCT' ? '产品' : (Number(row.care_record_required) ? '护理服务' : '普通服务')}</small><b>${esc(row.name)}</b>
        <span>${row.type === 'PRODUCT' ? `库存 ${Number(row.quantity)} ${esc(row.unit || '')}${row.barcode ? ` · ${esc(row.barcode)}` : ''}` : `${Number(row.duration || 0)} 分钟${Number(row.followup_days || 0) ? ` · ${Number(row.followup_days)}天回访` : ''}`}</span>
        <strong>${money(price)}</strong></button>`;
    }).join('') : empty(catalogType === 'PRODUCT' ? '没有可销售的护理产品，请到“护理产品”中新增并上架' : '没有符合条件的服务项目');
    $('v23-category-filter').querySelectorAll('[data-v23-category]').forEach(button => button.addEventListener('click', () => {
      catalogCategory = button.dataset.v23Category; drawCatalog();
    }));
    $('v23-catalog').querySelectorAll('[data-v23-catalog-item]').forEach(button => button.addEventListener('click', () => {
      const [type, id] = button.dataset.v23CatalogItem.split(':');
      const raw = (type === 'SERVICE' ? activeServices : products).find(row => String(row.id) === id);
      const existing = type === 'PRODUCT' ? state.cart.find(row => row.type === type && String(row.id) === id && !row.employeeId) : null;
      if (existing && existing.quantity < Number(raw.quantity)) existing.quantity += 1;
      else {
        const careRequired = type === 'SERVICE' && Number(raw.care_record_required) === 1;
        if (careRequired && !selectedCustomer()) return showError(new Error('甲沟炎、灰指甲等护理项目请先选择顾客'));
        state.cart.push({
          type, id: raw.id, name: raw.name, category: raw.category, unit: raw.unit,
          quantity: 1, stock: Number(raw.quantity || 0), list_price: raw.list_price,
          retail_price: raw.retail_price, member_price: raw.member_price,
          minPrice: Number(raw.min_price || 0), serviceType: raw.service_type || '普通服务',
          careRequired, photoRequired: Number(raw.photo_required) === 1, followupDays: Number(raw.followup_days || 0),
          care: null, price: defaultPrice({...raw, type}), changed: false, employeeId: ''
        });
      }
      state.payments = [];
      drawCart();
      const addedIndex = state.cart.length - 1;
      if (state.cart[addedIndex]?.careRequired && !state.cart[addedIndex].care) editCare(addedIndex);
    }));
  };

  const drawCart = () => {
    $('v23-cart-box').innerHTML = state.cart.length ? `
      <div class="cart-list">${state.cart.map((item, index) => `<div class="cart-item-v23">
        <div class="cart-name"><b>${esc(item.name)}</b><small>${item.type === 'PRODUCT' ? `产品 · 库存${item.stock}${esc(item.unit || '')}` : `服务 · ${esc(item.category || '未分类')}${item.careRequired ? ` · 护理档案${item.followupDays ? ` · ${item.followupDays}天回访` : ''}` : ''}`}</small>${item.careRequired ? `<button type="button" class="link" data-v24-care="${index}">${item.care ? `护理资料：${esc(item.care.foot)} ${esc(item.care.toe)} ✓` : '填写护理资料 *'}</button>` : ''}</div>
        ${item.type === 'PRODUCT' ? `<input class="qty-input" data-v23-qty="${index}" type="number" min="1" max="${item.stock}" step="1" value="${item.quantity}">` : `<span class="qty-label">1${esc(item.unit || '次')}</span>`}
        ${canChangePrice ? `<input class="price-input" data-v23-price="${index}" type="number" min="0" step="0.01" value="${Number(item.price).toFixed(2)}">` : `<strong>${money(item.price)}</strong>`}
        <select class="employee-inline" data-v23-employee="${index}"><option value="">未指定员工</option>${employees.map(row => `<option value="${row.id}" ${String(row.id) === String(item.employeeId) ? 'selected' : ''}>${esc(row.name)}</option>`).join('')}</select>
        <button type="button" class="link danger" data-v23-remove-cart="${index}">删除</button>
      </div>`).join('')}</div>
      <div class="cart-total"><span>应收合计</span><b>${money(total())}</b></div>` : empty('请从左侧选择服务或护理产品');
    const changed = state.cart.some(item => item.changed);
    $('v23-price-reason-box').innerHTML = changed ? field('改价原因 *', '<textarea id="v23-price-reason" placeholder="例如：店长批准的活动价"></textarea>') : '';
    $('v23-payment-box').innerHTML = state.payments.length ? `
      <div class="payment-list">${state.payments.map((row, index) => `<div class="cart-item"><span>${esc(row.method)}</span><strong>${money(row.amount)}</strong><button type="button" class="link danger" data-v23-remove-payment="${index}">删除</button></div>`).join('')}</div>
      <div class="payment-total"><span>已付 ${money(paid())}</span><b>待付 ${money(Math.max(0, total() - paid()))}</b></div>` : '<p class="form-tip">可分多种方式收款；系统只登记，不会自动向第三方发起支付。</p>';
    $('v23-payment-amount').value = Math.max(0, total() - paid()).toFixed(2);
    $('v23-cart-box').querySelectorAll('[data-v24-care]').forEach(button => button.addEventListener('click', () => editCare(Number(button.dataset.v24Care))));
    $('v23-cart-box').querySelectorAll('[data-v23-remove-cart]').forEach(button => button.addEventListener('click', () => {
      state.cart.splice(Number(button.dataset.v23RemoveCart), 1); state.payments = []; drawCart();
    }));
    $('v23-cart-box').querySelectorAll('[data-v23-qty]').forEach(control => control.addEventListener('change', () => {
      const index = Number(control.dataset.v23Qty); const value = Number(control.value);
      if (!Number.isInteger(value) || value < 1 || value > state.cart[index].stock) {
        showError(new Error('销售数量必须是大于0且不超过库存的整数')); control.value = state.cart[index].quantity; return;
      }
      state.cart[index].quantity = value; state.payments = []; drawCart();
    }));
    $('v23-cart-box').querySelectorAll('[data-v23-price]').forEach(control => control.addEventListener('change', () => {
      const index = Number(control.dataset.v23Price); const value = Number(control.value);
      if (!Number.isFinite(value) || value < 0) return showError(new Error('成交单价不正确'));
      if (state.cart[index].type === 'SERVICE' && value < Number(state.cart[index].minPrice || 0)) {
        control.value = Number(state.cart[index].price).toFixed(2); return showError(new Error(`成交价不能低于最低销售价 ${money(state.cart[index].minPrice)}`));
      }
      const standard = defaultPrice(state.cart[index]);
      state.cart[index].price = value; state.cart[index].changed = Math.abs(value - standard) > 0.001;
      state.payments = []; drawCart();
    }));
    $('v23-cart-box').querySelectorAll('[data-v23-employee]').forEach(control => control.addEventListener('change', () => {
      state.cart[Number(control.dataset.v23Employee)].employeeId = control.value;
    }));
    $('v23-payment-box').querySelectorAll('[data-v23-remove-payment]').forEach(button => button.addEventListener('click', () => {
      state.payments.splice(Number(button.dataset.v23RemovePayment), 1); drawCart();
    }));
  };

  content.querySelectorAll('[data-catalog-tab]').forEach(button => button.addEventListener('click', () => {
    catalogType = button.dataset.catalogTab; catalogCategory = '全部';
    content.querySelectorAll('[data-catalog-tab]').forEach(item => item.classList.toggle('active', item === button));
    drawCatalog();
  }));
  $('v23-catalog-search').addEventListener('input', () => { keyword = $('v23-catalog-search').value.trim(); drawCatalog(); });
  $('v23-order-customer').addEventListener('change', () => {
    const customer = selectedCustomer();
    $('v23-member-balance').innerHTML = customer ? `会员价已启用 · 余额 <b>${money(Number(customer.balance_principal) + Number(customer.balance_gift))}</b>（本金 ${money(customer.balance_principal)} / 赠送 ${money(customer.balance_gift)}）` : '当前按散客价格结账，不能使用会员余额。';
    state.cart.forEach(item => { if (!item.changed) item.price = defaultPrice(item); });
    state.payments = []; drawCatalog(); drawCart();
  });
  $('v23-add-payment').addEventListener('click', () => {
    const amount = Number($('v23-payment-amount').value); const method = $('v23-payment-method').value;
    if (!(amount > 0)) return showError(new Error('请输入大于0的支付金额'));
    if (paid() + amount > total() + 0.001) return showError(new Error('支付合计不能超过应收金额'));
    if (method === '会员余额' && !selectedCustomer()) return showError(new Error('散客不能使用会员余额'));
    state.payments.push({method, amount}); drawCart();
  });
  $('v23-submit-order').addEventListener('click', async () => {
    if (!state.cart.length) return showError(new Error('请选择服务或护理产品'));
    const missingCare = state.cart.find(item => item.careRequired && (!item.care || !item.care.foot || !item.care.toe));
    if (missingCare) return showError(new Error(`${missingCare.name}还没有填写护理资料`));
    if (state.cart.some(item => item.careRequired) && !selectedCustomer()) return showError(new Error('护理项目必须选择顾客'));
    if (Math.abs(paid() - total()) > 0.001) return showError(new Error('支付合计必须等于应收金额'));
    const priceReason = $('v23-price-reason')?.value.trim() || '';
    if (state.cart.some(item => item.changed) && priceReason.length < 2) return showError(new Error('改价必须填写原因'));
    const button = $('v23-submit-order'); button.disabled = true; button.textContent = '正在核价并记账…';
    const clientRequestId = button.dataset.requestId || v23RequestId('ORDER'); button.dataset.requestId = clientRequestId;
    try {
      const result = await api('/v23/orders', {method: 'POST', body: JSON.stringify({
        clientRequestId, customerId: selectedCustomer()?.id || null, priceChangeReason: priceReason,
        remark: $('v23-order-remark').value.trim(), payments: state.payments,
        items: state.cart.map(item => ({type: item.type, id: item.id, quantity: item.quantity,
          price: item.price, employeeId: item.employeeId || null, priceChangeReason: item.changed ? priceReason : '',
          care: item.careRequired ? item.care : null}))
      })});
      state.cart = []; state.payments = []; toast(`${result.duplicate ? '订单已存在，未重复记账' : '开单成功'}：${result.orderNo}`);
      state.page = '订单管理'; await render();
    } catch (error) { showError(error); button.disabled = false; button.textContent = '确认已收款并完成开单'; }
  });
  $('v23-order-customer').dispatchEvent(new Event('change'));
}

async function v23OrdersPage() {
  let rows = await api('/orders');
  const content = $('content');
  const drawRows = data => data.length ? data.map(row => `
    <tr><td><button class="link" data-v23-order-detail="${row.id}">${esc(row.order_no)}</button></td>
      <td>${esc(row.customer_name || '散客')}<small>${esc(row.phone || '')}</small></td><td><b>${money(row.received)}</b></td>
      <td>${statusTag(row.status)}</td><td>${esc(shortDate(row.created_at))}</td><td class="actions">
      <button class="ghost small" data-v23-order-detail="${row.id}">详情</button>
      ${['管理员', '店长'].includes(state.user.role) && !['已退款', '已取消'].includes(row.status) ? `<button class="ghost small danger" data-v23-refund="${row.id}">逐项退款</button>` : ''}</td></tr>`).join('') : `<tr><td colspan="6">${empty('没有符合条件的订单')}</td></tr>`;
  content.innerHTML = `
    <div class="toolbar">${input('v23-order-keyword', '订单号 / 姓名 / 手机号')}<button id="v23-search-order">查询</button><button id="v23-export-order" class="ghost">导出订单</button></div>
    <div class="panel"><div class="panel-head"><div><h3>销售订单</h3><p>服务、产品与次卡统一在订单中查账，退款必须选择具体明细</p></div></div>
      <div class="table-wrap"><table><thead><tr><th>订单号</th><th>顾客</th><th>实收</th><th>状态</th><th>时间</th><th>操作</th></tr></thead><tbody id="v23-order-rows">${drawRows(rows)}</tbody></table></div></div>`;
  const bind = () => {
    $('v23-order-rows').querySelectorAll('[data-v23-order-detail]').forEach(button => button.addEventListener('click', () => v23OrderDetail(Number(button.dataset.v23OrderDetail))));
    $('v23-order-rows').querySelectorAll('[data-v23-refund]').forEach(button => button.addEventListener('click', () => v23RefundOrder(Number(button.dataset.v23Refund))));
  };
  bind();
  $('v23-search-order').addEventListener('click', async () => {
    try { rows = await api(`/orders?q=${encodeURIComponent($('v23-order-keyword').value.trim())}`); $('v23-order-rows').innerHTML = drawRows(rows); bind(); }
    catch (error) { showError(error); }
  });
  $('v23-export-order').addEventListener('click', () => downloadCsv(`齐沐堂订单_${today()}.csv`, [
    {label: '订单号', value: 'order_no'}, {label: '顾客', value: row => row.customer_name || '散客'},
    {label: '手机号', value: 'phone'}, {label: '实收', value: 'received'}, {label: '状态', value: 'status'}, {label: '时间', value: 'created_at'}
  ], rows));
}

async function v23OrderDetail(id) {
  try {
    const data = await api(`/orders/${id}`);
    modal(`订单详情 · ${data.order.order_no}`, `
      <div class="detail-cards four"><div><span>订单状态</span>${statusTag(data.order.status)}</div><div><span>原价合计</span><b>${money(data.order.total)}</b></div><div><span>优惠</span><b>${money(data.order.discount)}</b></div><div><span>实收</span><b>${money(data.order.received)}</b></div></div>
      <h4>成交明细</h4><div class="table-wrap"><table><thead><tr><th>类型</th><th>项目/产品</th><th>数量</th><th>单价</th><th>员工</th><th>实收</th><th>提成</th></tr></thead><tbody>${data.items.map(item => `<tr>
        <td>${esc(item.item_type === 'PRODUCT' ? '护理产品' : item.item_type === 'PACKAGE' ? '次卡' : '服务')}</td><td>${esc(item.service_name)}</td><td>${Number(item.quantity || 1)}</td><td>${money(item.unit_price || item.received)}</td>
        <td>${esc(item.technician_name || '未指定')}</td><td>${money(item.received)}</td><td>${money(item.commission)}</td></tr>`).join('')}</tbody></table></div>
      <h4>付款明细</h4><div class="table-wrap"><table><thead><tr><th>方式</th><th>金额</th><th>时间</th></tr></thead><tbody>${data.payments.map(payment => `<tr><td>${esc(payment.method)}</td><td>${money(payment.amount)}</td><td>${esc(shortDate(payment.created_at))}</td></tr>`).join('')}</tbody></table></div>
      ${data.order.price_change_reason ? `<div class="notice warning compact">改价原因：${esc(data.order.price_change_reason)}</div>` : ''}
    `, async () => {}, {saveText: '关闭', wide: true});
  } catch (error) { showError(error); }
}

async function v23RefundOrder(id) {
  try {
    const data = await api(`/v23/orders/${id}/refund-preview`);
    const refundRequestId = v23RequestId('REFUND');
    const available = data.items.filter(item => Number(item.quantity || 1) - Number(item.refunded_quantity || 0) > 0 && Number(item.received) - Number(item.refunded_amount || 0) > 0);
    if (!available.length) return showError(new Error('这张订单已经没有可退款明细'));
    const hasExternal = data.payments.some(row => row.method !== '会员余额');
    modal(`逐项退款 · ${data.order.order_no}`, `
      <div class="notice warning">先在线下完成微信、支付宝、现金等实际退款，再在这里登记。系统会按所选明细回库、恢复会员余额并冲回对应员工提成。</div>
      <div class="table-wrap"><table><thead><tr><th>选择</th><th>类型</th><th>项目/产品</th><th>可退数量</th><th>退款数量</th><th>可退金额</th><th>退款金额</th><th>退回库存</th></tr></thead><tbody>${available.map(item => {
        const qty = Number(item.quantity || 1) - Number(item.refunded_quantity || 0);
        const amount = Number(item.received) - Number(item.refunded_amount || 0);
        const product = item.item_type === 'PRODUCT';
        return `<tr><td><input class="table-check" type="checkbox" data-v23-refund-select="${item.id}"></td><td>${product ? '产品' : item.item_type === 'PACKAGE' ? '次卡' : '服务'}</td><td><b>${esc(item.service_name)}</b><small>${esc(item.technician_name || '')}</small></td>
          <td>${qty}</td><td><input class="table-number" data-v23-refund-qty="${item.id}" type="number" min="0.01" max="${qty}" step="${product ? '1' : '0.01'}" value="${qty}"></td><td>${money(amount)}</td>
          <td><input class="table-number" data-v23-refund-amount="${item.id}" type="number" min="0.01" max="${amount}" step="0.01" value="${amount.toFixed(2)}"></td>
          <td>${product ? `<label class="tiny-check"><input type="checkbox" data-v23-refund-restock="${item.id}" checked>实物已收回</label>` : '-'}</td></tr>`;
      }).join('')}</tbody></table></div>
      ${field('退款原因 *', '<textarea id="v23-refund-reason" placeholder="写明退款原因和处理结果"></textarea>')}
      ${hasExternal ? '<label class="check-line danger-check"><input id="v23-refund-confirmed" type="checkbox"><span><b>已完成实际退款</b><small>已通过原渠道把钱退给顾客；本系统只登记账目，不会自动退款</small></span></label>' : ''}
    `, async mask => {
      const items = [...mask.querySelectorAll('[data-v23-refund-select]:checked')].map(check => {
        const itemId = check.dataset.v23RefundSelect;
        return {orderItemId: Number(itemId), quantity: Number(mask.querySelector(`[data-v23-refund-qty="${itemId}"]`).value),
          amount: Number(mask.querySelector(`[data-v23-refund-amount="${itemId}"]`).value),
          restock: Boolean(mask.querySelector(`[data-v23-refund-restock="${itemId}"]`)?.checked)};
      });
      const reason = $('v23-refund-reason').value.trim();
      if (!items.length) throw new Error('请至少勾选一项退款明细');
      if (reason.length < 2) throw new Error('请填写退款原因');
      if (hasExternal && !$('v23-refund-confirmed').checked) throw new Error('请先完成实际退款，并勾选确认');
      if (!confirmAction(`确认登记退款 ${money(items.reduce((sum, row) => sum + row.amount, 0))}？`)) throw new Error('已取消退款');
      const message = await api(`/v23/orders/${id}/refund-items`, {method: 'POST', body: JSON.stringify({
        clientRequestId: refundRequestId, items, reason,
        externalRefundConfirmed: !hasExternal || $('v23-refund-confirmed').checked
      })});
      toast(message); await v23OrdersPage();
    }, {saveText: '确认登记退款', wide: true});
  } catch (error) { showError(error); }
}

function v23MemberRecharge(customers, selected = '') {
  if (!customers.length) return showError(new Error('请先新增顾客'));
  const rechargeRequestId = v23RequestId('RECHARGE');
  modal('会员充值', `
    ${field('会员 *', select('v23-recharge-customer', customers, 'name', selected))}
    <div class="form-grid two">
      ${field('实收本金 *', input('v23-recharge-amount', '实际收到的钱', 'number', '', 'min="0.01" step="0.01"'))}
      ${field('赠送金额', input('v23-recharge-gift', '活动赠送金', 'number', '0', 'min="0" step="0.01"'))}
      ${field('实际付款方式 *', select('v23-recharge-method', V23_PAYMENT_METHODS.filter(name => name !== '会员余额')))}
    </div>
    ${field('备注', '<textarea id="v23-recharge-remark" placeholder="活动名称、收款凭据等"></textarea>')}
    <div class="notice warning">确认前请核对实际到账。充值本金会纳入交班日结，赠送金不会当作现金收入。</div>
  `, async () => {
    const amount = Number($('v23-recharge-amount').value); const gift = Number($('v23-recharge-gift').value || 0);
    if (!(amount > 0) || gift < 0) throw new Error('充值金额不正确');
    if (!confirmAction(`确认已收到 ${money(amount)}，另赠送 ${money(gift)}？`)) throw new Error('已取消充值');
    const message = await api('/v23/members/recharge', {method: 'POST', body: JSON.stringify({
      customerId: $('v23-recharge-customer').value, amount, gift,
      clientRequestId: rechargeRequestId, paymentMethod: $('v23-recharge-method').value,
      remark: $('v23-recharge-remark').value.trim()
    })});
    toast(message); await membersPage();
  }, {saveText: '确认已收款并充值'});
}

async function v23PackagesPage() {
  const [rows, customers, services, templates] = await Promise.all([
    api('/packages'), api('/customers'), api('/services'), api('/v25/package-templates')
  ]);
  const content = $('content');
  const canManage = ['管理员', '店长'].includes(state.user.role);
  content.innerHTML = `
    <div class="toolbar"><button id="v23-new-package">销售次卡</button>${canManage ? '<button id="v25-new-package-template" class="ghost">新建卡项模板</button>' : ''}</div>
    <div class="panel"><div class="panel-head"><div><h3>卡项模板</h3><p>标准卡项可重复销售，一键带出服务、次数、售价和有效期</p></div><span class="count-badge">${templates.length}</span></div>
      <div class="table-wrap"><table><thead><tr><th>卡项名称</th><th>类型</th><th>对应服务</th><th>次数</th><th>售价</th><th>有效期</th><th>状态</th>${canManage ? '<th>操作</th>' : ''}</tr></thead><tbody>${templates.length ? templates.map(row => `
        <tr><td><b>${esc(row.name)}</b><small>${esc(row.remark || '')}</small></td><td>${esc(row.template_type)}</td><td>${esc(row.service_name || '-')}</td><td>${Number(row.total_times || 1)}次</td><td>${money(row.price)}</td><td>${Number(row.valid_days || 0) ? `${Number(row.valid_days)}天` : '长期'}</td><td>${statusTag(Number(row.status) ? '上架' : '停用')}</td>${canManage ? `<td><button class="ghost small" data-v25-edit-template="${row.id}">编辑</button></td>` : ''}</tr>`).join('') : `<tr><td colspan="${canManage ? 8 : 7}">${empty('还没有卡项模板')}</td></tr>`}</tbody></table></div>
    </div>
    <div class="panel"><div class="panel-head"><div><h3>顾客已售次卡</h3><p>销售时同步生成订单和收款；核销只扣次数，不重复计营业额</p></div></div>
      <div class="table-wrap"><table><thead><tr><th>顾客</th><th>套餐</th><th>对应服务</th><th>售价</th><th>总次数</th><th>已用</th><th>剩余</th><th>有效期</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows.length ? rows.map(row => {
        const remaining = Number(row.total_times) - Number(row.used_times);
        return `<tr><td>${esc(row.customer_name)}</td><td><b>${esc(row.name)}</b><small>${row.sale_order_id ? `订单 #${row.sale_order_id}` : '旧版未关联收款'}</small></td><td>${esc(row.service_name || '-')}</td><td>${money(row.price || row.paid_amount)}</td>
          <td>${row.total_times}</td><td>${row.used_times}</td><td><b>${remaining}</b></td><td>${esc(row.expires_at || '长期')}</td><td>${statusTag(row.status)}</td><td class="actions">
          ${row.status === '正常' ? `<button class="small" data-v23-use-package="${row.id}" data-remaining="${remaining}">核销1次</button>` : ''}
          ${row.sale_order_id ? `<button class="ghost small" data-v23-package-order="${row.sale_order_id}">销售订单</button>` : ''}</td></tr>`;
      }).join('') : `<tr><td colspan="10">${empty('还没有已售次卡')}</td></tr>`}</tbody></table></div></div>`;
  content.querySelectorAll('[data-v23-use-package]').forEach(button => button.addEventListener('click', () => {
    modal('次卡核销确认', `
      <div class="detail-cards"><div><span>当前剩余</span><b>${button.dataset.remaining} 次</b></div><div><span>核销后</span><b>${Number(button.dataset.remaining) - 1} 次</b></div></div>
      ${field('核销备注', '<textarea id="v23-package-use-remark" placeholder="本次服务情况，可不填"></textarea>')}
      <div class="notice warning">仅在顾客实际完成本次护理后核销。核销不会重复增加营业额。</div>
    `, async () => {
      const message = await api(`/v23/packages/${button.dataset.v23UsePackage}/use`, {method: 'POST', body: JSON.stringify({remark: $('v23-package-use-remark').value.trim()})});
      toast(message); await v23PackagesPage();
    }, {saveText: '确认核销1次'});
  }));
  content.querySelectorAll('[data-v23-package-order]').forEach(button => button.addEventListener('click', () => v23OrderDetail(Number(button.dataset.v23PackageOrder))));
  if ($('v25-new-package-template')) $('v25-new-package-template').addEventListener('click', () => v25PackageTemplateForm(null, services.filter(row => Number(row.status))));
  content.querySelectorAll('[data-v25-edit-template]').forEach(button => button.addEventListener('click', () => v25PackageTemplateForm(templates.find(row => String(row.id) === button.dataset.v25EditTemplate), services.filter(row => Number(row.status)))));
  $('v23-new-package').addEventListener('click', () => v23PackageSale(customers, services.filter(row => Number(row.status)), templates.filter(row => Number(row.status))));
}

function v25PackageTemplateForm(template, services) {
  if (!services.length) return showError(new Error('请先新增并上架服务项目'));
  const editing = Boolean(template);
  modal(`${editing ? '编辑' : '新增'}卡项模板`, `
    <div class="form-grid two">
      ${field('卡项名称 *', input('v25-template-name', '例如：招牌修脚3次卡', 'text', template?.name || ''))}
      ${field('卡项类型', select('v25-template-type', ['次卡', '组合套餐'], 'name', template?.template_type || '次卡'))}
      ${field('对应服务 *', select('v25-template-service', services, 'name', template?.service_id || ''))}
      ${field('包含次数 *', input('v25-template-times', '1-999', 'number', template?.total_times || '3', 'min="1" max="999" step="1"'))}
      ${field('销售价 *', input('v25-template-price', '实际销售价', 'number', template?.price || '', 'min="0.01" step="0.01"'))}
      ${field('有效天数', input('v25-template-valid-days', '0表示长期', 'number', template?.valid_days || '0', 'min="0" max="3650" step="1"'))}
      ${editing ? field('状态', select('v25-template-status', [{id: 'true', name: '上架'}, {id: 'false', name: '停用'}], 'name', Number(template.status) ? 'true' : 'false')) : ''}
    </div>
    ${field('备注', `<textarea id="v25-template-remark" placeholder="使用说明、适用范围等">${esc(template?.remark || '')}</textarea>`)}
    <div class="notice compact">模板只定义销售规则，不直接增加营业额；实际卖给顾客后才生成订单和次卡。</div>
  `, async () => {
    const body = {
      name: $('v25-template-name').value.trim(), templateType: $('v25-template-type').value,
      serviceId: $('v25-template-service').value, totalTimes: Number($('v25-template-times').value),
      price: Number($('v25-template-price').value), validDays: Number($('v25-template-valid-days').value || 0),
      status: editing ? $('v25-template-status').value === 'true' : true,
      remark: $('v25-template-remark').value.trim()
    };
    const message = await api(editing ? `/v25/package-templates/${template.id}` : '/v25/package-templates', {
      method: editing ? 'PUT' : 'POST', body: JSON.stringify(body)
    });
    toast(message); await v23PackagesPage();
  });
}

function v23PackageSale(customers, services, templates = []) {
  if (!customers.length) return showError(new Error('请先新增顾客'));
  if (!services.length) return showError(new Error('请先新增并上架服务项目'));
  const packageRequestId = v23RequestId('PACKAGE');
  const templateOptions = [{id: '', name: '不使用模板（手工填写）'}, ...templates.map(row => ({id: row.id, name: `${row.name}｜${money(row.price)}｜${row.total_times}次`}))];
  modal('销售次卡', `
    ${templates.length ? field('快速模板', select('v25-sale-template', templateOptions)) : ''}
    <div class="form-grid two">
      ${field('顾客 *', select('v23-package-customer', customers))}
      ${field('对应服务 *', select('v23-package-service', services))}
      ${field('套餐名称 *', input('v23-package-name', '例如：招牌修脚3次卡', 'text', '招牌修脚3次卡'))}
      ${field('总次数 *', input('v23-package-times', '次数', 'number', '3', 'min="1" max="999" step="1"'))}
      ${field('套餐售价 *', input('v23-package-price', '本次实际应收', 'number', '', 'min="0.01" step="0.01"'))}
      ${field('有效期', input('v23-package-expiry', '留空为长期', 'date'))}
      ${field('付款方式 *', select('v23-package-method', V23_PAYMENT_METHODS))}
    </div>
    <div class="notice warning">本系统只登记实际收款，不会自动从微信或支付宝扣款。确认后会生成销售订单并计入日结。</div>
  `, async () => {
    const price = Number($('v23-package-price').value); const totalTimes = Number($('v23-package-times').value);
    if (!(price > 0) || !Number.isInteger(totalTimes) || totalTimes < 1) throw new Error('套餐价格或次数不正确');
    const customerId = $('v23-package-customer').value;
    if ($('v23-package-method').value === '会员余额') {
      const customer = customers.find(row => String(row.id) === customerId);
      if (Number(customer.balance_principal) + Number(customer.balance_gift) < price) throw new Error('会员余额不足');
    }
    if (!confirmAction(`确认已收款 ${money(price)} 并销售 ${totalTimes} 次套餐？`)) throw new Error('已取消销售');
    const result = await api('/v23/packages/sell', {method: 'POST', body: JSON.stringify({
      clientRequestId: packageRequestId, customerId, serviceId: $('v23-package-service').value,
      name: $('v23-package-name').value.trim(), totalTimes, price,
      expiresAt: $('v23-package-expiry').value || null,
      payments: [{method: $('v23-package-method').value, amount: price}]
    })});
    toast(`次卡销售成功：${result.orderNo}`); await v23PackagesPage();
  }, {saveText: '确认已收款并销售'});
  if (templates.length && $('v25-sale-template')) $('v25-sale-template').addEventListener('change', () => {
    const template = templates.find(row => String(row.id) === $('v25-sale-template').value);
    if (!template) return;
    $('v23-package-service').value = String(template.service_id);
    $('v23-package-name').value = template.name;
    $('v23-package-times').value = Number(template.total_times || 1);
    $('v23-package-price').value = Number(template.price || 0);
    if (Number(template.valid_days || 0) > 0) {
      const date = new Date(); date.setDate(date.getDate() + Number(template.valid_days));
      const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
      $('v23-package-expiry').value = local.toISOString().slice(0, 10);
    } else $('v23-package-expiry').value = '';
  });
}

const V23_SHIFT_METHODS = [
  ['cash', '现金（含备用金）'], ['wechat', '微信'], ['alipay', '支付宝'], ['card', '银行卡'],
  ['meituan', '美团'], ['douyin', '抖音'], ['other', '其他']
];

async function v23ShiftsPage() {
  const current = await api('/v23/shifts/current');
  const history = ['管理员', '店长'].includes(state.user.role) ? await api('/v23/shifts') : [];
  const content = $('content');
  content.innerHTML = current ? `
    <div class="panel shift-current"><div class="panel-head"><div><h3>当前班次 ${esc(current.shift_no)}</h3><p>${esc(current.opener_name || '-')} 于 ${esc(shortDate(current.opened_at))} 开班</p></div>${statusTag('营业中')}</div>
      <div class="metric-grid">${V23_SHIFT_METHODS.map(([key, label]) => `<div class="metric ${key === 'cash' ? 'primary' : ''}"><span>${label}账面应有</span><b>${money(current.summary[key])}</b></div>`).join('')}</div>
      <div class="notice compact">现金应有金额包含开班备用金 ${money(current.opening_cash)}。收款、退款、会员充值和手工收支都会进入相应渠道核对。</div>
      <button id="v23-close-shift" class="wide">交班盘点并完成日结</button>
    </div>` : `
    <div class="panel start-shift"><img src="/qimutang-logo.svg" alt="齐沐堂"><h3>今天还没有开班</h3><p>先登记收银台备用金，再开始当天营业。开班后所有收款会自动纳入日结核对。</p><button id="v23-open-shift">开始营业 / 开班</button></div>`;
  if (history.length) content.insertAdjacentHTML('beforeend', `
    <div class="panel"><div class="panel-head"><div><h3>日结历史</h3><p>差异不为0的班次需要重点查账</p></div></div><div class="table-wrap"><table><thead><tr><th>班次</th><th>营业日</th><th>开班</th><th>关班</th><th>现金差异</th><th>微信差异</th><th>支付宝差异</th><th>其他差异</th><th>备注</th></tr></thead><tbody>${history.map(row => `
      <tr><td><b>${esc(row.shift_no)}</b><small>${esc(row.status)}</small></td><td>${esc(row.business_date)}</td><td>${esc(row.opener_name || '-')}${row.opened_at ? `<small>${esc(shortDate(row.opened_at))}</small>` : ''}</td><td>${esc(row.closer_name || '-')}${row.closed_at ? `<small>${esc(shortDate(row.closed_at))}</small>` : ''}</td>
      <td class="${Number(row.difference_cash) ? 'negative' : ''}">${money(row.difference_cash)}</td><td class="${Number(row.difference_wechat) ? 'negative' : ''}">${money(row.difference_wechat)}</td><td class="${Number(row.difference_alipay) ? 'negative' : ''}">${money(row.difference_alipay)}</td>
      <td class="${Number(row.difference_other) ? 'negative' : ''}">${money(row.difference_other)}</td><td>${esc(row.remark || '-')}</td></tr>`).join('')}</tbody></table></div></div>`);
  $('v23-open-shift')?.addEventListener('click', () => modal('开班', `
    ${field('收银台备用金', input('v23-opening-cash', '现金抽屉现有金额', 'number', '0', 'min="0" step="0.01"'))}
    ${field('开班备注', '<textarea id="v23-opening-remark" placeholder="交接情况，可不填"></textarea>')}
  `, async () => { toast(await api('/v23/shifts/open', {method: 'POST', body: JSON.stringify({openingCash: Number($('v23-opening-cash').value || 0), remark: $('v23-opening-remark').value.trim()})})); await v23ShiftsPage(); }, {saveText: '确认开班'}));
  $('v23-close-shift')?.addEventListener('click', () => v23CloseShift(current));
}

function v23CloseShift(current) {
  modal(`交班日结 · ${current.shift_no}`, `
    <div class="notice warning">请按微信账单、支付宝账单、银行卡记录和现金抽屉逐项实盘。系统不会连接平台自动核账。</div>
    <div class="shift-grid">${V23_SHIFT_METHODS.map(([key, label]) => field(`${label}（账面 ${money(current.summary[key])}）`, input(`v23-actual-${key}`, '实际核对净额', 'number', Number(current.summary[key] || 0).toFixed(2), `${key === 'cash' ? 'min="0" ' : ''}step="0.01"`))).join('')}</div>
    ${field('差异原因 / 交班备注', '<textarea id="v23-shift-remark" placeholder="有差异时必须说明，如现金短款、退款未到账等"></textarea>')}
  `, async () => {
    const body = {remark: $('v23-shift-remark').value.trim()};
    V23_SHIFT_METHODS.forEach(([key]) => { body[`actual${key.charAt(0).toUpperCase()}${key.slice(1)}`] = Number($(`v23-actual-${key}`).value || 0); });
    const difference = V23_SHIFT_METHODS.reduce((sum, [key]) => sum + Math.abs(body[`actual${key.charAt(0).toUpperCase()}${key.slice(1)}`] - Number(current.summary[key] || 0)), 0);
    if (difference > 0.01 && body.remark.length < 2) throw new Error('账实存在差异，请填写原因');
    if (!confirmAction(`确认完成日结？账实差异绝对值合计 ${money(difference)}。`)) throw new Error('已取消日结');
    toast(await api(`/v23/shifts/${current.id}/close`, {method: 'POST', body: JSON.stringify(body)})); await v23ShiftsPage();
  }, {saveText: '确认交班并日结', wide: true});
}

async function v23ReportsPage() {
  const from = window.qmtReportFrom || monthStart();
  const to = window.qmtReportTo || today();
  const [summary, performance] = await Promise.all([
    api(`/reports/summary?from=${from}&to=${to}`), api(`/v23/reports/performance?from=${from}&to=${to}`)
  ]);
  const profit = Number(summary.sales) - Number(summary.expenses) - Number(summary.commissions);
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar">${input('v23-report-from', '开始日期', 'date', from)}${input('v23-report-to', '结束日期', 'date', to)}<button id="v23-load-report">查询</button><button id="v23-export-categories" class="ghost">导出分类业绩</button><button id="v23-export-employees" class="ghost">导出员工业绩</button><button id="v23-print-report" class="ghost">打印</button></div>
    <div class="metric-grid six">
      <div class="metric primary"><span>净营业额</span><b>${money(summary.sales)}</b><small>实收减退款</small></div><div class="metric"><span>订单数</span><b>${summary.orders || 0}</b></div>
      <div class="metric"><span>实际充值本金</span><b>${money(summary.recharge)}</b><small>不含赠送金</small></div><div class="metric"><span>经营支出</span><b>${money(summary.expenses)}</b><small>不含另列的提成</small></div>
      <div class="metric"><span>净提成</span><b>${money(summary.commissions)}</b><small>含退款冲回</small></div><div class="metric ${profit < 0 ? 'danger-metric' : ''}"><span>经营贡献</span><b>${money(profit)}</b><small>非会计净利润</small></div>
    </div>
    <div class="panel"><div class="panel-head"><div><h3>按类别统计</h3><p>服务与护理产品分开显示；产品毛利会扣成交时记录的成本</p></div></div>
      <div class="table-wrap"><table><thead><tr><th>业务类型</th><th>类别</th><th>销售数量</th><th>护理档案</th><th>自动回访</th><th>销售额</th><th>退款数量</th><th>退款额</th><th>净业绩</th><th>产品成本</th><th>毛利参考</th></tr></thead><tbody>${performance.categories.length ? performance.categories.map(row => `
        <tr><td>${row.item_type === 'PRODUCT' ? '护理产品' : row.item_type === 'PACKAGE' ? '次卡' : '服务'}</td><td><b>${esc(row.category)}</b></td><td>${Number(row.sold_quantity || 0)}</td><td>${Number(row.care_count || 0)}</td><td>${Number(row.followup_count || 0)}</td><td>${money(row.gross_amount)}</td><td>${Number(row.refund_quantity || 0)}</td><td>${money(row.refund_amount)}</td><td><b>${money(row.net_amount)}</b></td><td>${money(row.cost_amount)}</td><td>${money(row.gross_profit)}</td></tr>`).join('') : `<tr><td colspan="11">${empty('所选日期暂无分类业绩')}</td></tr>`}</tbody></table></div></div>
    <div class="panel"><div class="panel-head"><div><h3>员工业绩（按类别）</h3><p>同一员工在不同服务/产品类别分别统计，退款只冲回对应明细</p></div></div>
      <div class="table-wrap"><table><thead><tr><th>员工</th><th>类别</th><th>服务/销售次数</th><th>原业绩</th><th>退款</th><th>净业绩</th><th>原提成</th><th>冲回提成</th><th>净提成</th></tr></thead><tbody>${performance.employees.length ? performance.employees.map(row => `
        <tr><td><b>${esc(row.employee_name)}</b></td><td>${esc(row.category)}</td><td>${Number(row.service_count || 0)}</td><td>${money(row.gross_amount)}</td><td>${money(row.refund_amount)}</td><td><b>${money(row.net_amount)}</b></td><td>${money(row.gross_commission)}</td><td>${money(row.reversed_commission)}</td><td><b>${money(row.net_commission)}</b></td></tr>`).join('') : `<tr><td colspan="9">${empty('所选日期暂无员工业绩')}</td></tr>`}</tbody></table></div></div>
    <div class="panel"><div class="detail-cards four"><div><span>会员人数</span><b>${summary.memberCount}</b></div><div><span>会员余额负债</span><b>${money(summary.memberBalance)}</b></div><div><span>60天沉睡会员</span><b>${summary.dormantMembers}</b></div><div><span>新增顾客</span><b>${summary.newCustomers}</b></div></div>
      <div class="notice compact">经营贡献 = 净营业额－已登记支出－净提成。房租、水电、折旧等未完整登记时，它不等于会计利润。</div></div>`;
  $('v23-load-report').addEventListener('click', () => { window.qmtReportFrom = $('v23-report-from').value; window.qmtReportTo = $('v23-report-to').value; v23ReportsPage(); });
  $('v23-export-categories').addEventListener('click', () => downloadCsv(`齐沐堂分类业绩_${from}_${to}.csv`, [
    {label: '类型', value: row => row.item_type === 'PRODUCT' ? '护理产品' : row.item_type === 'PACKAGE' ? '次卡' : '服务'}, {label: '类别', value: 'category'},
    {label: '销售数量', value: 'sold_quantity'}, {label: '护理档案', value: 'care_count'}, {label: '自动回访', value: 'followup_count'}, {label: '销售额', value: 'gross_amount'}, {label: '退款额', value: 'refund_amount'}, {label: '净业绩', value: 'net_amount'}, {label: '产品成本', value: 'cost_amount'}, {label: '毛利参考', value: 'gross_profit'}
  ], performance.categories));
  $('v23-export-employees').addEventListener('click', () => downloadCsv(`齐沐堂员工业绩_${from}_${to}.csv`, [
    {label: '员工', value: 'employee_name'}, {label: '类别', value: 'category'}, {label: '次数', value: 'service_count'},
    {label: '原业绩', value: 'gross_amount'}, {label: '退款', value: 'refund_amount'}, {label: '净业绩', value: 'net_amount'},
    {label: '原提成', value: 'gross_commission'}, {label: '冲回提成', value: 'reversed_commission'}, {label: '净提成', value: 'net_commission'}
  ], performance.employees));
  $('v23-print-report').addEventListener('click', () => window.print());
}

async function v23DownloadBackup(name) {
  const response = await fetch(`${API}/system/backups/${encodeURIComponent(name)}/download`, {headers: {Authorization: `Bearer ${state.user.token}`}});
  if (!response.ok) throw new Error('备份下载失败');
  const blob = await response.blob(); const url = URL.createObjectURL(blob); const anchor = document.createElement('a');
  anchor.href = url; anchor.download = name; anchor.click(); URL.revokeObjectURL(url);
}

async function v23SettingsPage() {
  await settingsPage();
  const notice = [...document.querySelectorAll('.notice.warning.compact')].find(node => node.textContent.includes('恢复会先备份'));
  if (notice) notice.textContent = '整包备份包含数据库、护理照片和凭证，系统保留90天。恢复前会自动再备份当前数据，并在重启时执行。建议每周下载一份到U盘。';
  document.querySelectorAll('[data-restore]').forEach(button => {
    const download = document.createElement('button'); download.type = 'button'; download.className = 'ghost small'; download.textContent = '下载';
    download.addEventListener('click', async () => { try { await v23DownloadBackup(button.dataset.restore); toast('备份已下载'); } catch (error) { showError(error); } });
    button.parentElement.insertBefore(download, button);
  });
}

async function v23DashboardPage() {
  await dashboardPage();
  const stockButton = document.querySelector('[data-go="库存管理"]');
  if (stockButton) stockButton.dataset.go = '护理产品';
  const quickTargets = {收银开单: '收银开单', 新增顾客: '顾客档案', 会员充值: '会员管理', 新增预约: '预约管理', 护理档案: '护理档案', 登记支出: '收支管理'};
  document.querySelectorAll('[data-quick]').forEach(button => {
    if (!(roleMenus[state.user.role] || []).includes(quickTargets[button.dataset.quick])) button.remove();
  });
  try {
    const shift = await api('/v23/shifts/current');
    const content = $('content');
    content.insertAdjacentHTML('afterbegin', `<button type="button" id="v23-dashboard-shift" class="shift-banner ${shift ? 'open' : 'closed'}">
      <span>${shift ? '今日班次营业中' : '尚未开班'}</span><b>${shift ? `${esc(shift.shift_no)} · 账面收款持续归集` : '请先登记备用金，再开始收银'}</b><i>${shift ? '去交班日结' : '立即开班'} →</i></button>`);
    $('v23-dashboard-shift').addEventListener('click', () => { state.page = '交班日结'; render(); });
  } catch (_) { /* 技师不显示交班入口 */ }
}

async function v241CareTimelinePage() {
  const [customers, reminders, records, followups] = await Promise.all([
    api('/customers'), api('/reminders/care?days=7'), api('/care-records'), api('/followups?status=待回访').catch(() => [])
  ]);
  const grouped = new Map();
  records.forEach(row => { const key = String(row.customer_id || '0'); if (!grouped.has(key)) grouped.set(key, []); grouped.get(key).push(row); });
  const content = $('content');
  content.innerHTML = `<div class="toolbar"><button id="v241-manual-care">手工新增护理档案</button><select id="v241-care-customer"><option value="">全部顾客</option>${customers.map(c => `<option value="${c.id}">${esc(c.name)} · ${esc(c.phone || '')}</option>`).join('')}</select></div>
    <div class="stats-grid compact"><div class="stat"><span>护理档案</span><b>${records.length}</b></div><div class="stat"><span>7日内到期</span><b>${reminders.length}</b></div><div class="stat"><span>待回访</span><b>${followups.length}</b></div><div class="stat"><span>护理顾客</span><b>${grouped.size}</b></div></div>
    <div id="v241-care-timeline"></div>`;
  const draw = () => {
    const customerId = $('v241-care-customer').value;
    const rows = customerId ? records.filter(r => String(r.customer_id) === customerId) : records;
    const groups = [...new Set(rows.map(r => String(r.customer_id)))];
    $('v241-care-timeline').innerHTML = groups.length ? groups.map(id => {
      const list = rows.filter(r => String(r.customer_id) === id).sort((a,b) => String(b.care_date).localeCompare(String(a.care_date)));
      const first = list[0];
      return `<div class="panel"><div class="panel-head"><div><h3>${esc(first.customer_name || '顾客')}</h3><p>${esc(first.phone || '')} · 共 ${list.length} 次护理</p></div><span class="count-badge">${list.length}</span></div>
        <div class="timeline">${list.map((r,i) => `<div class="timeline-item"><b>${esc(shortDate(r.care_date).slice(0,10))} · ${esc(r.type || '')}</b><small>${esc(`${r.foot || ''} ${r.toe || ''}`)} · ${esc(r.stage || '未标阶段')} · ${esc(r.technician_name || '未指定')}</small><p>${esc(r.description || '未填写本次情况')}</p>${r.plan ? `<p><strong>方案：</strong>${esc(r.plan)}</p>` : ''}<small>${r.next_date ? `下次建议：${esc(r.next_date)}` : '未设置下次日期'}${r.order_id ? ` · 来源订单 #${r.order_id}` : ' · 手工档案'}</small>${(r.before_photo || r.after_photo) ? `<div><a href="${esc(r.before_photo || r.after_photo)}" target="_blank">查看护理照片</a></div>` : ''}</div>`).join('')}</div></div>`;
    }).join('') : empty('还没有符合条件的护理档案');
  };
  $('v241-care-customer').addEventListener('change', draw); draw();
  $('v241-manual-care').addEventListener('click', () => { carePage(); setTimeout(() => $('new-care')?.click(), 50); });
}

window.memberRecharge = v23MemberRecharge;
Object.assign(pages, {
  首页: v23DashboardPage,
  收银开单: v23CheckoutPage,
  订单管理: v23OrdersPage,
  项目中心: v23ServicesPage,
  护理产品: v23ProductsPage,
  次卡套餐: v23PackagesPage,
  交班日结: v23ShiftsPage,
  营业报表: v23ReportsPage,
  系统设置: v23SettingsPage,
  护理档案: v241CareTimelinePage
});

bootstrap();
