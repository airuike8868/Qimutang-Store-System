using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace QimutangDesktop;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

internal sealed class MainForm : Form
{
    private readonly WebView2 webView = new() { Dock = DockStyle.Fill };
    private readonly Label statusLabel = new()
    {
        Dock = DockStyle.Fill,
        TextAlign = ContentAlignment.MiddleCenter,
        Font = new Font("Microsoft YaHei UI", 12F),
        Text = "正在启动齐沐堂门店管理系统…"
    };
    private readonly FlowLayoutPanel recoveryActions = new()
    {
        Dock = DockStyle.Bottom,
        Height = 70,
        FlowDirection = FlowDirection.LeftToRight,
        Padding = new Padding(24, 12, 0, 0),
        Visible = false
    };
    private readonly Button retryButton = new() { Text = "一键修复并重试", AutoSize = true, Height = 38 };
    private readonly Button openLogsButton = new() { Text = "打开日志目录", AutoSize = true, Height = 38 };
    private Process? backendProcess;
    private Process? mysqlProcess;
    private bool startedBackend;
    private bool closing;
    private bool starting;

    private string DataDir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
        "QimutangData", "data");

    private string InstallRoot
    {
        get
        {
            var baseDir = AppContext.BaseDirectory.TrimEnd(
                Path.DirectorySeparatorChar,
                Path.AltDirectorySeparatorChar);
            var parent = Directory.GetParent(baseDir)?.FullName;
            if (parent is not null
                && Directory.Exists(Path.Combine(parent, "runtime"))
                && Directory.Exists(Path.Combine(parent, "app")))
                return parent;
            return baseDir;
        }
    }

    public MainForm()
    {
        Text = "齐沐堂门店管理系统 3.3.0 MySQL商业版";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1100, 720);
        Width = 1440;
        Height = 900;
        WindowState = FormWindowState.Maximized;

        try
        {
            var iconPath = Path.Combine(InstallRoot, "qimutang.ico");
            if (!File.Exists(iconPath))
                iconPath = Path.Combine(AppContext.BaseDirectory, "qimutang.ico");
            if (File.Exists(iconPath)) Icon = new Icon(iconPath);
        }
        catch { }

        recoveryActions.Controls.Add(retryButton);
        recoveryActions.Controls.Add(openLogsButton);
        Controls.Add(statusLabel);
        Controls.Add(recoveryActions);
        retryButton.Click += async (_, _) => await StartAsync(true);
        openLogsButton.Click += (_, _) => OpenLogsDirectory();
        Shown += async (_, _) => await StartAsync();
        FormClosing += OnFormClosing;
    }

    private async Task StartAsync(bool repair = false)
    {
        if (starting) return;
        starting = true;
        retryButton.Enabled = false;
        recoveryActions.Visible = false;
        try
        {
            Directory.CreateDirectory(DataDir);

            statusLabel.Text = "正在启动 MySQL 数据库…";
            await Task.Run(EnsureMySqlReady);
            statusLabel.Text = "正在启动齐沐堂门店管理系统…";

            var existingUrl = await FindRunningServerAsync(TimeSpan.FromSeconds(2));
            if (existingUrl is null)
            {
                StopStaleBackend(repair);
                StartBackend();
                statusLabel.Text = "正在初始化本地服务，首次启动通常需要 30–120 秒…";
                existingUrl = await FindRunningServerAsync(TimeSpan.FromMinutes(2), true);
            }

            if (existingUrl is null && backendProcess is { HasExited: false })
            {
                statusLabel.Text = "首次启动未完成，正在自动修复并重试一次…";
                StopOwnedBackend();
                StopStaleBackend(true);
                StartBackend();
                existingUrl = await FindRunningServerAsync(TimeSpan.FromMinutes(2), true);
            }

            if (existingUrl is null)
                throw new InvalidOperationException(BuildBackendFailureMessage());

            await ShowWebViewAsync(existingUrl);
        }
        catch (Exception ex)
        {
            try
            {
                var logDir = Path.Combine(DataDir, "logs");
                Directory.CreateDirectory(logDir);
                File.AppendAllText(
                    Path.Combine(logDir, "desktop-startup.log"),
                    $"[{DateTime.Now:O}] {ex}\r\n",
                    new UTF8Encoding(false));
            }
            catch { }
            statusLabel.Text = "启动失败\r\n\r\n" + ex.Message;
            MessageBox.Show(ex.Message, "齐沐堂门店管理系统", MessageBoxButtons.OK, MessageBoxIcon.Error);
            recoveryActions.Visible = true;
        }
        finally { starting = false; retryButton.Enabled = true; }
    }

    private void StartBackend()
    {
        var root = InstallRoot;
        var java = Path.Combine(root, "runtime", "bin", "java.exe");
        var jar = Path.Combine(root, "app", "qimutang.jar");

        if (!File.Exists(java))
            throw new FileNotFoundException("客户端缺少 Java 运行环境。", java);
        if (!File.Exists(jar))
            throw new FileNotFoundException("客户端缺少 qimutang.jar。", jar);

        var mysqlSettings = LoadMySqlSettings();

        var psi = new ProcessStartInfo
        {
            FileName = java,
            WorkingDirectory = root,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        psi.ArgumentList.Add("-Dfile.encoding=UTF-8");
        psi.ArgumentList.Add("-Dqimutang.desktop=true");
        psi.ArgumentList.Add("-jar");
        psi.ArgumentList.Add(jar);
        psi.ArgumentList.Add("--spring.profiles.active=mysql");
        psi.Environment["SPRING_PROFILES_ACTIVE"] = "mysql";
        psi.Environment["QIMUTANG_MYSQL_URL"] = mysqlSettings["QIMUTANG_MYSQL_URL"];
        psi.Environment["QIMUTANG_MYSQL_USER"] = mysqlSettings["QIMUTANG_MYSQL_USER"];
        psi.Environment["QIMUTANG_MYSQL_PASSWORD"] = mysqlSettings["QIMUTANG_MYSQL_PASSWORD"];

        backendProcess = Process.Start(psi) ?? throw new InvalidOperationException("无法启动齐沐堂后台服务。 ");
        var consoleLog = Path.Combine(DataDir, "logs", "backend-console.log");
        Directory.CreateDirectory(Path.GetDirectoryName(consoleLog)!);
        backendProcess.OutputDataReceived += (_, e) => AppendBackendLine(consoleLog, e.Data);
        backendProcess.ErrorDataReceived += (_, e) => AppendBackendLine(consoleLog, e.Data);
        backendProcess.BeginOutputReadLine();
        backendProcess.BeginErrorReadLine();
        File.WriteAllText(Path.Combine(DataDir, "backend.pid"), backendProcess.Id.ToString(), new UTF8Encoding(false));
        startedBackend = true;
    }

    private string BuildBackendFailureMessage()
    {
        var processState = "后台进程仍在运行，但未能在规定时间内完成初始化。";
        try
        {
            if (backendProcess is { HasExited: true })
                processState = $"后台进程已退出（代码 {backendProcess.ExitCode}）。";
        }
        catch { }

        var detail = ReadLatestBackendError();
        return "本地服务未能启动。" + processState
               + (string.IsNullOrWhiteSpace(detail) ? "" : "\r\n\r\n最近错误：" + detail)
               + "\r\n可点击“一键修复并重试”；若仍失败，请打开日志目录。";
    }

    private static void AppendBackendLine(string file, string? line)
    {
        if (string.IsNullOrWhiteSpace(line)) return;
        try { File.AppendAllText(file, $"[{DateTime.Now:O}] {line}\r\n", new UTF8Encoding(false)); } catch { }
    }

    private string ReadLatestBackendError()
    {
        try
        {
            foreach (var file in new[] { Path.Combine(DataDir, "logs", "qimutang.log"), Path.Combine(DataDir, "logs", "backend-console.log") })
            {
                if (!File.Exists(file)) continue;
                var lines = File.ReadLines(file).TakeLast(80).Where(x => x.Contains("ERROR", StringComparison.OrdinalIgnoreCase) || x.Contains("Exception", StringComparison.OrdinalIgnoreCase)).TakeLast(2).ToArray();
                if (lines.Length > 0) return string.Join(" / ", lines).Replace('\t', ' ').Trim();
            }
        }
        catch { }
        return string.Empty;
    }

    private void StopStaleBackend(bool force)
    {
        var pidFile = Path.Combine(DataDir, "backend.pid");
        try
        {
            if (File.Exists(pidFile) && int.TryParse(File.ReadAllText(pidFile).Trim(), out var pid))
            {
                using var process = Process.GetProcessById(pid);
                if (force || process.ProcessName.StartsWith("java", StringComparison.OrdinalIgnoreCase)) process.Kill(entireProcessTree: true);
                process.WaitForExit(5000);
            }
        }
        catch { }
        foreach (var name in new[] { "java", "javaw" })
        {
            foreach (var process in Process.GetProcessesByName(name))
            {
                try
                {
                    var executable = process.MainModule?.FileName ?? string.Empty;
                    if (executable.StartsWith(Path.Combine(InstallRoot, "runtime"), StringComparison.OrdinalIgnoreCase))
                    {
                        process.Kill(entireProcessTree: true);
                        process.WaitForExit(5000);
                    }
                }
                catch { }
                finally { process.Dispose(); }
            }
        }
        try { File.Delete(pidFile); } catch { }
        try { File.Delete(Path.Combine(DataDir, "qimutang.running.lock")); } catch { }
    }

    private void StopOwnedBackend()
    {
        try { if (backendProcess is { HasExited: false }) { backendProcess.Kill(entireProcessTree: true); backendProcess.WaitForExit(5000); } } catch { }
        backendProcess = null;
        startedBackend = false;
    }

    private void OpenLogsDirectory()
    {
        try
        {
            var path = Path.Combine(DataDir, "logs");
            Directory.CreateDirectory(path);
            Process.Start(new ProcessStartInfo { FileName = path, UseShellExecute = true });
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "无法打开日志目录", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private void EnsureMySqlReady()
    {
        var root = InstallRoot;
        var mysqlRoot = Path.Combine(root, "mysql");
        var mysqld = Path.Combine(mysqlRoot, "bin", "mysqld.exe");
        var mysql = Path.Combine(mysqlRoot, "bin", "mysql.exe");
        var mysqlAdmin = Path.Combine(mysqlRoot, "bin", "mysqladmin.exe");
        if (!File.Exists(mysqld) || !File.Exists(mysql) || !File.Exists(mysqlAdmin))
            throw new FileNotFoundException("安装包缺少 MySQL 8.4 运行环境，请重新安装。", mysqld);

        var dataBase = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            "QimutangData");
        var mysqlData = Path.Combine(dataBase, "mysql-data");
        var configDir = Path.Combine(dataBase, "config");
        var logDir = Path.Combine(dataBase, "logs");
        var envFile = Path.Combine(configDir, "mysql.env");
        var iniFile = Path.Combine(configDir, "mysql-embedded.ini");
        Directory.CreateDirectory(mysqlData);
        Directory.CreateDirectory(configDir);
        Directory.CreateDirectory(logDir);

        if (!Directory.Exists(Path.Combine(mysqlData, "mysql")))
        {
            var exitCode = RunProcess(mysqld, new[]
            {
                "--initialize-insecure",
                $"--basedir={mysqlRoot}",
                $"--datadir={mysqlData}",
                "--console"
            }, 180_000);
            if (exitCode != 0)
                throw new InvalidOperationException("MySQL 首次初始化失败，请查看 QimutangData\\logs。 ");
        }

        var mysqlRootForIni = mysqlRoot.Replace('\\', '/');
        var mysqlDataForIni = mysqlData.Replace('\\', '/');
        var logForIni = Path.Combine(logDir, "mysql-error.log").Replace('\\', '/');
        File.WriteAllText(iniFile, string.Join(Environment.NewLine, new[]
        {
            "[mysqld]",
            $"basedir={mysqlRootForIni}",
            $"datadir={mysqlDataForIni}",
            "port=3307",
            "bind-address=127.0.0.1",
            "character-set-server=utf8mb4",
            "collation-server=utf8mb4_0900_ai_ci",
            $"log-error={logForIni}",
            string.Empty
        }), new UTF8Encoding(false));

        if (!IsMySqlReady(mysqlAdmin))
        {
            var startInfo = new ProcessStartInfo
            {
                FileName = mysqld,
                WorkingDirectory = mysqlRoot,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            startInfo.ArgumentList.Add($"--defaults-file={iniFile}");
            mysqlProcess = Process.Start(startInfo)
                ?? throw new InvalidOperationException("无法启动 MySQL 数据库。 ");

            for (var i = 0; i < 120 && !IsMySqlReady(mysqlAdmin); i++)
                Thread.Sleep(500);
        }

        if (!IsMySqlReady(mysqlAdmin))
            throw new InvalidOperationException("MySQL 启动失败，请查看 QimutangData\\logs\\mysql-error.log。 ");

        if (!File.Exists(envFile))
        {
            var appPassword = CreatePassword();
            var rootPassword = CreatePassword();
            var sql = string.Join(" ", new[]
            {
                "CREATE DATABASE IF NOT EXISTS qimutang CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;",
                $"CREATE USER IF NOT EXISTS 'qimutang'@'127.0.0.1' IDENTIFIED BY '{appPassword}';",
                $"ALTER USER 'qimutang'@'127.0.0.1' IDENTIFIED BY '{appPassword}';",
                "GRANT ALL PRIVILEGES ON qimutang.* TO 'qimutang'@'127.0.0.1';",
                $"ALTER USER 'root'@'localhost' IDENTIFIED BY '{rootPassword}';",
                "FLUSH PRIVILEGES;"
            });
            var exitCode = RunProcess(mysql, new[]
            {
                "--protocol=tcp", "-h127.0.0.1", "-P3307", "-uroot", "-e", sql
            }, 60_000);
            if (exitCode != 0)
                throw new InvalidOperationException("MySQL 数据库账号初始化失败。 ");

            File.WriteAllLines(envFile, new[]
            {
                "QIMUTANG_MYSQL_URL=jdbc:mysql://127.0.0.1:3307/qimutang?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&allowPublicKeyRetrieval=true",
                "QIMUTANG_MYSQL_USER=qimutang",
                $"QIMUTANG_MYSQL_PASSWORD={appPassword}"
            }, new UTF8Encoding(false));
        }

        _ = LoadMySqlSettings();
    }

    private static bool IsMySqlReady(string mysqlAdmin)
    {
        try
        {
            return RunProcess(mysqlAdmin, new[]
            {
                "--protocol=tcp", "-h127.0.0.1", "-P3307", "ping", "--silent"
            }, 5_000) == 0;
        }
        catch
        {
            return false;
        }
    }

    private static int RunProcess(string fileName, IEnumerable<string> arguments, int timeoutMs)
    {
        using var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = fileName,
                UseShellExecute = false,
                CreateNoWindow = true
            }
        };
        foreach (var argument in arguments)
            process.StartInfo.ArgumentList.Add(argument);
        if (!process.Start())
            throw new InvalidOperationException($"无法启动组件：{Path.GetFileName(fileName)}");
        if (!process.WaitForExit(timeoutMs))
        {
            try { process.Kill(entireProcessTree: true); } catch { }
            throw new TimeoutException($"组件启动超时：{Path.GetFileName(fileName)}");
        }
        return process.ExitCode;
    }

    private static string CreatePassword() =>
        Convert.ToHexString(RandomNumberGenerator.GetBytes(24)).ToLowerInvariant();

    private static Dictionary<string, string> LoadMySqlSettings()
    {
        var envFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            "QimutangData", "config", "mysql.env");
        if (!File.Exists(envFile))
            throw new FileNotFoundException("MySQL 配置文件不存在。", envFile);

        var settings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var line in File.ReadAllLines(envFile))
        {
            var split = line.IndexOf('=');
            if (split <= 0) continue;
            settings[line[..split].Trim()] = line[(split + 1)..].Trim();
        }
        foreach (var key in new[]
                 {
                     "QIMUTANG_MYSQL_URL",
                     "QIMUTANG_MYSQL_USER",
                     "QIMUTANG_MYSQL_PASSWORD"
                 })
        {
            if (!settings.ContainsKey(key))
                throw new InvalidOperationException($"MySQL 配置缺少：{key}");
        }
        return settings;
    }

    private async Task<string?> FindRunningServerAsync(TimeSpan timeout, bool stopWhenBackendExits = false)
    {
        var end = DateTime.UtcNow + timeout;
        using var http = new HttpClient { Timeout = TimeSpan.FromMilliseconds(900) };

        while (DateTime.UtcNow < end)
        {
            if (stopWhenBackendExits && backendProcess is { HasExited: true }) return null;
            var port = ReadServerPort();
            var url = $"http://127.0.0.1:{port}";
            try
            {
                using var response = await http.GetAsync(url + "/api/health");
                if (response.StatusCode == HttpStatusCode.OK)
                    return url;
            }
            catch { }

            await Task.Delay(400);
        }

        return null;
    }

    private int ReadServerPort()
    {
        try
        {
            var file = Path.Combine(DataDir, "server.port");
            if (File.Exists(file) && int.TryParse(File.ReadAllText(file).Trim(), out var port)
                && port is > 0 and <= 65535)
                return port;
        }
        catch { }
        return 8080;
    }

    private async Task ShowWebViewAsync(string url)
    {
        var webData = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "QimutangStoreSystem", "WebView2");
        Directory.CreateDirectory(webData);

        CoreWebView2Environment environment;
        try
        {
            environment = await CoreWebView2Environment.CreateAsync(null, webData);
        }
        catch (WebView2RuntimeNotFoundException)
        {
            throw new InvalidOperationException("电脑缺少 Microsoft Edge WebView2 Runtime。请安装 WebView2 Runtime 后重新打开齐沐堂系统。 ");
        }

        Controls.Clear();
        Controls.Add(webView);
        await webView.EnsureCoreWebView2Async(environment);

        webView.CoreWebView2.Settings.AreDevToolsEnabled = false;
        webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
        webView.CoreWebView2.Settings.IsStatusBarEnabled = false;
        webView.CoreWebView2.Settings.IsZoomControlEnabled = true;
        webView.CoreWebView2.DocumentTitleChanged += (_, _) =>
        {
            var title = webView.CoreWebView2.DocumentTitle;
            if (!string.IsNullOrWhiteSpace(title)) Text = title;
        };
        webView.CoreWebView2.NewWindowRequested += (_, e) =>
        {
            e.Handled = true;
            webView.CoreWebView2.Navigate(e.Uri);
        };
        webView.Source = new Uri(url);
    }

    private void OnFormClosing(object? sender, FormClosingEventArgs e)
    {
        if (closing) return;
        closing = true;

        if (!startedBackend) return;

        try
        {
            Directory.CreateDirectory(DataDir);
            File.WriteAllText(Path.Combine(DataDir, "shutdown.request"), DateTime.Now.ToString("O"));
        }
        catch { }

        try
        {
            if (backendProcess is { HasExited: false })
            {
                if (!backendProcess.WaitForExit(2500))
                    backendProcess.Kill(entireProcessTree: true);
            }
        }
        catch { }
        try { File.Delete(Path.Combine(DataDir, "backend.pid")); } catch { }
    }
}
