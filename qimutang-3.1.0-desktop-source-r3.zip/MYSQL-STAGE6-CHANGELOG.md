# 齐沐堂 2.5.0 MySQL 改造阶段6

1. 修复旧 Windows 构建脚本仍显示/打包 2.3.0 的问题，统一为 2.5.0。
2. Windows 打包输入加入 MySQL 配置脚本和启动入口，避免生成一个无法完成数据库配置的空壳安装包。
3. 新增 `scripts/mysql-business-regression.ps1`，固定正式发布前必须完成的 12 项业务回归检查。
4. 明确正式发布门槛：Windows 11 + MySQL 8 真机完成迁移、收银、库存、提成、退款、备份恢复后，才可标记为正式版。
5. 当前 Linux 构建环境没有 Maven/MySQL Server，阶段6仍属于发布候选源码，不虚报真机验收通过。
