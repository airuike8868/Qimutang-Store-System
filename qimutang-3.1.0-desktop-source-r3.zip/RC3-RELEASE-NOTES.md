# 齐沐堂门店管理系统 2.5.0 MySQL RC3

RC3 目标：安装与首次启动收口，不新增大型业务功能。

## 本轮改动
- 新增 `scripts/首次配置MySQL.bat`，首次部署不再要求用户手工拼 PowerShell 参数。
- 首次配置会检查 MySQL 客户端、创建/初始化数据库与专用账号，并写入用户目录配置。
- 数据库密码输入采用隐藏输入，完成后清理当前批处理环境变量。
- `start-qimutang.cmd` 继续只从 `%USERPROFILE%\QimutangData\config\mysql.env` 读取数据库连接，不把密码写进程序目录。
- 修订 README：正式 MySQL 版不再错误描述为 SQLite 单机版，也不再声称未经真机验收的 EXE 已经交付。
- 版本标识更新为 `2.5.0-mysql-rc3`。

## 发布门槛
RC3 仍是候选版。正式版必须在 Windows 11 + MySQL 8 真机完成安装、初始化、迁移、收银、退款、库存、会员、提成、查账、备份恢复和重启一致性测试。
