@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "APP_ROOT=%~dp0"
set "APP_JAR=%APP_ROOT%app\qimutang.jar"
set "JAVA_CMD=java"

if exist "%APP_ROOT%runtime\bin\java.exe" set "JAVA_CMD=%APP_ROOT%runtime\bin\java.exe"
if not exist "%APP_JAR%" set "APP_JAR=%APP_ROOT%target\qimutang.jar"

if not exist "%APP_JAR%" (
  echo 未找到 app\qimutang.jar，请重新解压完整安装包。
  pause
  exit /b 1
)

if not exist "%APP_ROOT%runtime\bin\java.exe" (
  where java >nul 2>nul
  if errorlevel 1 (
    echo 当前电脑没有 Java 17。请使用“Windows安装版”或“Windows便携版”，它们已经自带 Java。
    pause
    exit /b 1
  )
)

"%JAVA_CMD%" -version 2>&1 | findstr /r /c:"version.*17[.]" >nul
if errorlevel 1 (
  echo 检测到的 Java 版本不是 17。请安装 JDK 17，或使用已经自带 Java 的 Windows 安装版/便携版。
  pause
  exit /b 1
)

if not exist "%APP_ROOT%data\uploads\customer" mkdir "%APP_ROOT%data\uploads\customer"
if not exist "%APP_ROOT%data\backup" mkdir "%APP_ROOT%data\backup"

"%JAVA_CMD%" -Dfile.encoding=UTF-8 -Dqimutang.data-dir="%APP_ROOT%data" -jar "%APP_JAR%"

if errorlevel 1 (
  echo.
  echo 系统未能正常启动。请把本窗口最后20行内容截图发给技术支持。
  pause
)
