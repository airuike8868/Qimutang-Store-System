@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "ROOT=%~dp0"
set "CFG=%USERPROFILE%\QimutangData\config\mysql.env"
if not exist "%CFG%" (
  echo [齐沐堂] 尚未配置 MySQL。
  echo 请先运行 scripts\configure-mysql-windows.ps1 完成数据库配置。
  pause
  exit /b 2
)
for /f "usebackq tokens=1,* delims==" %%A in ("%CFG%") do (
  if /I "%%A"=="QIMUTANG_MYSQL_URL" set "QIMUTANG_MYSQL_URL=%%B"
  if /I "%%A"=="QIMUTANG_MYSQL_USER" set "QIMUTANG_MYSQL_USER=%%B"
  if /I "%%A"=="QIMUTANG_MYSQL_PASSWORD" set "QIMUTANG_MYSQL_PASSWORD=%%B"
)
if "%QIMUTANG_MYSQL_PASSWORD%"=="" (
  echo [齐沐堂] MySQL 密码配置为空，请重新配置。
  pause
  exit /b 3
)
set "SPRING_PROFILES_ACTIVE=mysql"
"%ROOT%runtime\bin\javaw.exe" -Dfile.encoding=UTF-8 -jar "%ROOT%app\qimutang.jar" --spring.profiles.active=mysql
