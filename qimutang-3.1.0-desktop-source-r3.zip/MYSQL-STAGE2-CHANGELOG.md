# 齐沐堂 2.5.0 MySQL 改造阶段2

本阶段在“阶段1”基础上继续完成：

1. SQLite / MySQL 双数据库兼容辅助层 `DbCompat`。
2. 新增记录ID兼容：SQLite `last_insert_rowid()` / MySQL `last_insert_id()`。
3. 字段存在检测改为 JDBC Metadata，不再依赖 SQLite `pragma_table_info`。
4. 2.3 / 2.5 增量迁移增加 MySQL 兼容处理。
5. MySQL 索引改为 Metadata 检测后创建，避免重复执行失败。
6. 预约时间冲突判断增加 MySQL `timestampadd/str_to_date` 版本。
7. 首页提醒、护理到期、沉睡会员等日期 SQL 增加 MySQL 方言。
8. 系统设置写入增加 MySQL `ON DUPLICATE KEY UPDATE`。
9. 增加旧 SQLite → 当前 MySQL 的管理员迁移服务：
   `POST /api/system/mysql/migrate-sqlite`。
10. 迁移固定读取 `%USERPROFILE%/QimutangData/data/qimutang.db`，不允许任意路径。
11. 迁移采用安全合并策略，重复主键/唯一键不会覆盖目标库。
12. MySQL 模式新增应用级 ZIP 逻辑备份与恢复，不强依赖 `mysqldump`。
13. 新增 `mysql/README-MySQL8.md` 和 `scripts/start-mysql-mode.bat`。

## 当前验证状态

- 已完成源码级改造和静态检查。
- 当前运行容器没有 Maven 和 MySQL Server，因此本阶段没有宣称“已通过真实 MySQL 8 编译/联调”。
- 下一阶段应在 Windows + MySQL 8 环境执行：编译、建库、全量迁移、数量核对、收银/退款/库存/提成/备份恢复回归测试，再生成正式安装包。
