#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

mvn clean package
mkdir -p dist
jpackage \
  --type dmg \
  --name "Qimutang" \
  --app-version 2.5.0 \
  --vendor "Qimutang" \
  --description "Qimutang Store Management System" \
  --input target \
  --main-jar qimutang.jar \
  --dest dist \
  --java-options "-Dfile.encoding=UTF-8" \
  --mac-package-name "Qimutang"

echo "macOS installation package generated in dist/."
