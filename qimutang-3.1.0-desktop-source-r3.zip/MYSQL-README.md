# 齐沐堂 2.5.0 MySQL 商业版改造（阶段1）

已加入 MySQL Connector/J 与 mysql Spring Profile。

目标：MySQL 8.x、utf8mb4，支持 QIMUTANG_MYSQL_URL / USER / PASSWORD 环境变量。

当前是数据库改造第一阶段：驱动、连接池、Profile 已加入。现有业务代码仍含 SQLite 专用 SQL，因此本阶段不能作为 MySQL 正式生产版直接启动。下一阶段要完成 SQL 方言兼容、MySQL 建表脚本、旧库迁移、MySQL 备份恢复。

正式迁移前不要删除原 SQLite 数据库。
