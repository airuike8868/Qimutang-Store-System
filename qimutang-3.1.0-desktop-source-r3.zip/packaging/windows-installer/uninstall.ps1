[CmdletBinding()]
param(
    [string]$InstallRoot,
    [switch]$Final
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

if (-not $Final) {
    if (-not $InstallRoot) {
        $InstallRoot = Join-Path $env:LOCALAPPDATA 'Programs\QimutangStore'
    }
    $tempScript = Join-Path $env:TEMP "qimutang-uninstall-$PID.ps1"
    Copy-Item -LiteralPath $PSCommandPath -Destination $tempScript -Force
    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    Start-Process -FilePath $powershell -WindowStyle Hidden -ArgumentList @(
        '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden',
        '-File', "`"$tempScript`"", '-InstallRoot', "`"$InstallRoot`"", '-Final'
    )
    exit 0
}

try {
    $answer = [System.Windows.Forms.MessageBox]::Show(
        "确定卸载齐沐堂门店管理系统吗？`r`n`r`n营业数据库、顾客图片和备份不会删除，以后重新安装仍可继续使用。",
        '卸载齐沐堂门店管理系统',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question
    )
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { exit 0 }

    $javaw = Join-Path $InstallRoot 'runtime\bin\javaw.exe'
    $running = @(Get-Process -Name 'javaw' -ErrorAction SilentlyContinue | Where-Object {
        try {
            $_.Path -and ([IO.Path]::GetFullPath($_.Path) -ieq [IO.Path]::GetFullPath($javaw))
        } catch {
            $false
        }
    })
    if ($running.Count -gt 0) {
        $dataRoot = Join-Path $env:USERPROFILE 'QimutangData\data'
        New-Item -ItemType Directory -Force -Path $dataRoot | Out-Null
        Set-Content -LiteralPath (Join-Path $dataRoot 'shutdown.request') -Value 'uninstaller' -Encoding Ascii
        for ($attempt = 0; $attempt -lt 40; $attempt++) {
            Start-Sleep -Milliseconds 250
            $remaining = @($running | Where-Object { Get-Process -Id $_.Id -ErrorAction SilentlyContinue })
            if ($remaining.Count -eq 0) { break }
        }
        $running | Where-Object { Get-Process -Id $_.Id -ErrorAction SilentlyContinue } |
            Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 800
    }

    $shell = New-Object -ComObject WScript.Shell
    $desktop = $shell.SpecialFolders.Item('Desktop')
    Remove-Item -LiteralPath (Join-Path $desktop '齐沐堂门店管理系统.lnk') -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\齐沐堂') -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\QimutangStore' -Recurse -Force -ErrorAction SilentlyContinue

    if (Test-Path $InstallRoot) {
        Remove-Item -LiteralPath $InstallRoot -Recurse -Force
    }
    $dataRoot = Join-Path $env:USERPROFILE 'QimutangData\data'
    [System.Windows.Forms.MessageBox]::Show(
        "卸载完成。`r`n`r`n营业数据已保留在：$dataRoot",
        '齐沐堂门店管理系统',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
    Remove-Item -LiteralPath $PSCommandPath -Force -ErrorAction SilentlyContinue
    exit 0
} catch {
    [System.Windows.Forms.MessageBox]::Show(
        "卸载未完成：$($_.Exception.Message)",
        '齐沐堂门店管理系统',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}
