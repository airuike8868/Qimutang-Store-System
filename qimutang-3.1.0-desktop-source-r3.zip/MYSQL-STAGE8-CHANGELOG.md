# 齐沐堂 2.5.0 MySQL 改造阶段8

本阶段重点收口发布版本一致性与安装前检查：

1. 修复离线 Windows 安装器仍残留 2.3.0 版本号的问题，统一为 2.5.0。
2. 修复 JAR Manifest 的 Implementation-Version，统一为 2.5.0。
3. Linux/macOS jpackage 脚本版本号同步为 2.5.0，避免跨平台包版本漂移。
4. README 的 Windows 交付文件名同步到 2.5.0 MySQL 版。
5. 新增 Windows 发布前检查脚本：检查 Java/JDK、Maven、jpackage、MySQL 客户端与 MySQL 8 版本，并给出明确失败原因。
6. 保留 SQLite 驱动仅用于旧数据迁移；正式运行默认 MySQL profile。

注意：阶段8仍不是“真机验收通过”的正式版。必须在 Windows 11 + MySQL 8 环境完成编译、初始化、业务回归、备份恢复后再标记正式版。
