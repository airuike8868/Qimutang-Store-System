# 齐沐堂 2.5.0 MySQL 改造阶段5

1. Windows 启动入口正式切换为 MySQL profile，不再默认误启 SQLite。
2. 新增 `configure-mysql-windows.ps1`，初始化数据库后写入本机 MySQL 连接配置。
3. MySQL 密码不写入安装目录/JAR，保存在当前 Windows 用户的 `QimutangData/config/mysql.env`。
4. 安装程序版本号修正为 2.5.0，桌面/开始菜单快捷方式改为 MySQL 启动器。
5. 继续保留旧 `QimutangData/data/qimutang.db`，升级过程不删除 SQLite 原库。
6. 正式发布前仍必须在 Windows 11 + MySQL 8 实机完成业务回归和迁移恢复测试。
