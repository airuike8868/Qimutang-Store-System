package com.qimutang;

import io.jsonwebtoken.Jwts;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.crypto.spec.SecretKeySpec;
import java.util.List;
import java.util.Map;

@Component
class AuthInterceptor implements HandlerInterceptor {
    private final String key = "qimutang-local-key-change-before-production-2026";
    private final JdbcTemplate db;

    AuthInterceptor(JdbcTemplate db) {
        this.db = db;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                             Object handler) throws Exception {
        if ("OPTIONS".equals(request.getMethod())) return true;
        String token = request.getHeader("Authorization");
        if (token != null && token.startsWith("Bearer ")) token = token.substring(7);
        try {
            Map<String, Object> claims = Jwts.parser()
                    .verifyWith(new SecretKeySpec(key.getBytes(), "HmacSHA256"))
                    .build().parseSignedClaims(token).getPayload();
            long userId = ((Number) claims.get("id")).longValue();
            List<String> roles = db.query(
                    "select role from users where id=? and deleted=0",
                    (rs, index) -> rs.getString("role"), userId);
            if (roles.isEmpty()) throw new IllegalArgumentException("账号已停用");
            request.setAttribute("userId", userId);
            request.setAttribute("role", roles.get(0));
            return true;
        } catch (Exception ignored) {
            response.setStatus(401);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"success\":false,\"message\":\"登录已失效或账号已停用，请重新登录\"}");
            return false;
        }
    }
}
