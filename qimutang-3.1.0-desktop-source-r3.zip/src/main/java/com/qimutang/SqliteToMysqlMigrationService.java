package com.qimutang;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.*;

/** Imports the previous local SQLite database into an initialized MySQL 8 database. */
@Service
class SqliteToMysqlMigrationService {
    private final JdbcTemplate target;
    private final Path dataDir;

    SqliteToMysqlMigrationService(JdbcTemplate target, @Value("${qimutang.data-dir}") String dataDir) {
        this.target = target;
        this.dataDir = Path.of(dataDir).toAbsolutePath().normalize();
    }

    @Transactional
    Map<String,Object> migrateDefaultSqlite() throws Exception {
        if (!DbCompat.isMySql(target)) throw new IllegalArgumentException("当前不是 MySQL 模式，无需迁移");
        Path source = dataDir.resolve("qimutang.db").normalize();
        if (!source.startsWith(dataDir) || !Files.isRegularFile(source)) {
            throw new IllegalArgumentException("未找到旧版 SQLite 数据库：" + source);
        }

        Map<String,Object> report = new LinkedHashMap<>();
        List<Map<String,Object>> tablesReport = new ArrayList<>();
        int totalRead = 0, totalInserted = 0;

        try (Connection src = DriverManager.getConnection("jdbc:sqlite:" + source)) {
            List<String> tables = new ArrayList<>();
            try (PreparedStatement ps = src.prepareStatement(
                    "select name from sqlite_master where type='table' and name not like 'sqlite_%' order by name");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) tables.add(rs.getString(1));
            }

            for (String table : tables) {
                if (!safeName(table) || !targetTableExists(table)) continue;
                List<String> sourceColumns = sourceColumns(src, table);
                Set<String> targetColumns = targetColumns(table);
                List<String> columns = sourceColumns.stream().filter(targetColumns::contains).toList();
                if (columns.isEmpty()) continue;

                int read = 0, inserted = 0;
                String select = "select " + String.join(",", columns) + " from " + table;
                String placeholders = String.join(",", Collections.nCopies(columns.size(), "?"));
                String insert = "insert ignore into " + table + "(" + String.join(",", columns) + ") values(" + placeholders + ")";

                try (Statement st = src.createStatement(); ResultSet rs = st.executeQuery(select)) {
                    while (rs.next()) {
                        read++;
                        Object[] values = new Object[columns.size()];
                        for (int i = 0; i < values.length; i++) values[i] = rs.getObject(i + 1);
                        inserted += Math.max(0, target.update(insert, values));
                    }
                }
                totalRead += read;
                totalInserted += inserted;
                tablesReport.add(Map.of("table",table,"sourceRows",read,"insertedRows",inserted,"skippedRows",read-inserted));
            }
        }

        report.put("source", source.toString());
        report.put("sourceRows", totalRead);
        report.put("insertedRows", totalInserted);
        report.put("skippedRows", totalRead-totalInserted);
        report.put("tables", tablesReport);
        report.put("message", "SQLite→MySQL 迁移完成；重复主键/唯一键记录按安全合并策略跳过");
        return report;
    }

    private boolean targetTableExists(String table) throws SQLException {
        Boolean result = target.execute(connection -> {
            try (ResultSet rs = connection.getMetaData().getTables(connection.getCatalog(), null, table, new String[]{"TABLE"})) {
                return rs.next();
            }
        });
        return Boolean.TRUE.equals(result);
    }

    private Set<String> targetColumns(String table) throws SQLException {
        Set<String> columns = new LinkedHashSet<>();
        target.execute(connection -> {
            try (ResultSet rs = connection.getMetaData().getColumns(connection.getCatalog(), null, table, null)) {
                while (rs.next()) columns.add(rs.getString("COLUMN_NAME"));
            }
            return null;
        });
        return columns;
    }

    private List<String> sourceColumns(Connection src, String table) throws SQLException {
        List<String> columns = new ArrayList<>();
        try (Statement st = src.createStatement(); ResultSet rs = st.executeQuery("pragma table_info(" + table + ")")) {
            while (rs.next()) columns.add(rs.getString("name"));
        }
        return columns;
    }

    private boolean safeName(String value) { return value != null && value.matches("[A-Za-z0-9_]+"); }
}

@RestController
@RequestMapping("/api/system/mysql")
class SqliteToMysqlMigrationApi {
    private final SqliteToMysqlMigrationService migration;
    SqliteToMysqlMigrationApi(SqliteToMysqlMigrationService migration) { this.migration = migration; }

    private void admin(HttpServletRequest request) {
        if (!"管理员".equals(String.valueOf(request.getAttribute("role"))))
            throw new IllegalArgumentException("只有管理员可以迁移数据库");
    }

    @PostMapping("/migrate-sqlite")
    Object migrate(HttpServletRequest request) throws Exception {
        admin(request);
        return Map.of("success", true, "data", migration.migrateDefaultSqlite());
    }
}
