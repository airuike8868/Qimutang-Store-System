package com.qimutang;

import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.DependsOn;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;

@Component
@DependsOn("api")
class V23Migration {
    private final JdbcTemplate db;

    V23Migration(JdbcTemplate db) {
        this.db = db;
    }

    @PostConstruct
    void migrate() {
        ddl("create table if not exists categories(" +
                "id integer primary key autoincrement," +
                "type text not null," +
                "name text not null," +
                "sort_order integer default 0," +
                "color text default '#146fca'," +
                "enabled integer default 1," +
                "created_at text,updated_at text,deleted integer default 0," +
                "unique(type,name))");

        ddl("create table if not exists refund_items(" +
                "id integer primary key autoincrement," +
                "refund_id integer not null," +
                "order_item_id integer not null," +
                "quantity decimal not null," +
                "amount decimal not null," +
                "restock integer default 0," +
                "commission_reversal decimal default 0," +
                "created_at text,updated_at text,deleted integer default 0)");

        ddl("create table if not exists shifts(" +
                "id integer primary key autoincrement," +
                "shift_no text unique not null," +
                "business_date text not null," +
                "status text default '营业中'," +
                "opener_id integer," +
                "opening_cash decimal default 0," +
                "opened_at text," +
                "closer_id integer," +
                "closed_at text," +
                "expected_cash decimal default 0,actual_cash decimal default 0,difference_cash decimal default 0," +
                "expected_wechat decimal default 0,actual_wechat decimal default 0,difference_wechat decimal default 0," +
                "expected_alipay decimal default 0,actual_alipay decimal default 0,difference_alipay decimal default 0," +
                "expected_card decimal default 0,actual_card decimal default 0,difference_card decimal default 0," +
                "expected_meituan decimal default 0,actual_meituan decimal default 0,difference_meituan decimal default 0," +
                "expected_douyin decimal default 0,actual_douyin decimal default 0,difference_douyin decimal default 0," +
                "expected_other decimal default 0,actual_other decimal default 0,difference_other decimal default 0," +
                "remark text,created_at text,updated_at text,deleted integer default 0)");

        ensureColumn("services", "category_id", "integer");
        ensureColumn("services", "service_type", "text default '普通服务'");
        ensureColumn("services", "unit", "text default '次'");
        ensureColumn("services", "min_price", "decimal default 0");
        ensureColumn("services", "care_record_required", "integer default 0");
        ensureColumn("services", "photo_required", "integer default 0");
        ensureColumn("services", "followup_days", "integer default 0");
        ensureColumn("inventory", "barcode", "text");
        ensureColumn("inventory", "retail_price", "decimal default 0");
        ensureColumn("inventory", "member_price", "decimal default 0");
        ensureColumn("inventory", "retail_enabled", "integer default 0");
        ensureColumn("inventory", "product_type", "text default '耗材'");
        ensureColumn("inventory", "expires_at", "text");
        ensureColumn("inventory", "commission_type", "text default 'FIXED'");
        ensureColumn("inventory", "commission_value", "decimal default 0");

        ensureColumn("orders", "shift_id", "integer");
        ensureColumn("orders", "client_request_id", "text");
        ensureColumn("orders", "business_date", "text");
        ensureColumn("orders", "price_change_reason", "text");

        ensureColumn("order_items", "item_type", "text default 'SERVICE'");
        ensureColumn("order_items", "inventory_id", "integer");
        ensureColumn("order_items", "package_id", "integer");
        ensureColumn("order_items", "quantity", "decimal default 1");
        ensureColumn("order_items", "unit_price", "decimal default 0");
        ensureColumn("order_items", "category_name", "text");
        ensureColumn("order_items", "cost_price", "decimal default 0");
        ensureColumn("order_items", "original_price", "decimal default 0");
        ensureColumn("order_items", "price_change_reason", "text");

        ensureColumn("commissions", "category_name", "text");
        ensureColumn("commissions", "source_reversal_id", "integer");
        ensureColumn("commission_reversals", "order_item_id", "integer");
        ensureColumn("commission_reversals", "employee_id", "integer");
        ensureColumn("commission_reversals", "payroll_migrated", "integer default 0");

        ensureColumn("packages", "price", "decimal default 0");
        ensureColumn("packages", "paid_amount", "decimal default 0");
        ensureColumn("packages", "sale_order_id", "integer");

        ensureColumn("balance_logs", "principal_change", "decimal default 0");
        ensureColumn("balance_logs", "gift_change", "decimal default 0");
        ensureColumn("balance_logs", "payment_method", "text");
        ensureColumn("balance_logs", "client_request_id", "text");
        ensureColumn("refunds", "client_request_id", "text");

        createIndexes();

        seedCategories();
        backfillSnapshots();
        backfillCommissionReversals();

        String now = LocalDateTime.now().toString();
        DbCompat.upsertSetting(db,"app_version","2.3.1","系统版本",now);
    }

    private void seedCategories() {
        List<String> serviceCategories = List.of(
                "基础修脚", "甲沟炎护理", "嵌甲护理", "足部问题护理",
                "足疗", "推拿按摩", "组合项目", "卡项套餐", "其他"
        );
        List<String> productCategories = List.of(
                "护理液", "修护产品", "足部用品", "日常护理", "其他"
        );
        int sort = 10;
        for (String name : serviceCategories) {
            insertCategory("SERVICE", name, sort);
            sort += 10;
        }
        sort = 10;
        for (String name : productCategories) {
            insertCategory("PRODUCT", name, sort);
            sort += 10;
        }
        for (Map<String, Object> row : db.queryForList(
                "select distinct trim(category) name from services where deleted=0 and trim(coalesce(category,''))<>''")) {
            insertCategory("SERVICE", String.valueOf(row.get("name")), sort++);
        }
        for (Map<String, Object> row : db.queryForList(
                "select distinct trim(category) name from inventory where deleted=0 and trim(coalesce(category,''))<>''")) {
            insertCategory("PRODUCT", String.valueOf(row.get("name")), sort++);
        }
    }

    private void insertCategory(String type, String name, int sort) {
        String now = LocalDateTime.now().toString();
        DbCompat.insertCategoryIfMissing(db,type,name,sort,now);
    }

    private void backfillSnapshots() {
        db.update("update orders set business_date=substr(created_at,1,10) " +
                "where business_date is null or trim(business_date)='' ");
        db.update("update order_items set item_type='SERVICE' " +
                "where item_type is null or trim(item_type)='' ");
        db.update("update order_items set quantity=1 where quantity is null or quantity<=0");
        db.update("update order_items set unit_price=received where unit_price is null or unit_price=0");
        db.update("update order_items set original_price=price where original_price is null or original_price=0");
        db.update("update order_items set category_name=(select category from services s where s.id=order_items.service_id) " +
                "where (category_name is null or trim(category_name)='') and service_id is not null");
        db.update("update commissions set category_name=(select category_name from order_items oi where oi.id=commissions.order_item_id) " +
                "where category_name is null or trim(category_name)='' ");
        db.update("update balance_logs set principal_change=change_amount,payment_method=coalesce(payment_method,'历史未记录') " +
                "where type='充值' and coalesce(principal_change,0)=0 and coalesce(gift_change,0)=0");
    }

    private void backfillCommissionReversals() {
        for (Map<String, Object> reversal : db.queryForList(
                "select * from commission_reversals cr where cr.deleted=0 and cr.amount>0 " +
                        "and coalesce(cr.payroll_migrated,0)=0 " +
                        "and not exists(select 1 from commissions c where c.source_reversal_id=cr.id and c.deleted=0) order by cr.id")) {
            long reversalId = ((Number) reversal.get("id")).longValue();
            if (!(reversal.get("order_id") instanceof Number)) {
                db.update("update commission_reversals set payroll_migrated=1 where id=?", reversalId);
                continue;
            }
            long orderId = ((Number) reversal.get("order_id")).longValue();
            BigDecimal reversalAmount = new BigDecimal(String.valueOf(reversal.get("amount")));
            List<Map<String, Object>> commissions = db.queryForList(
                    "select * from commissions where order_id=? and deleted=0 and amount>0 and employee_id is not null order by id",
                    orderId);
            BigDecimal total = commissions.stream()
                    .map(row -> new BigDecimal(String.valueOf(row.get("amount"))))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            if (total.signum() <= 0) {
                db.update("update commission_reversals set payroll_migrated=1 where id=?", reversalId);
                continue;
            }
            BigDecimal target = reversalAmount.min(total).setScale(2, RoundingMode.HALF_UP);
            BigDecimal allocated = BigDecimal.ZERO;
            Object reversalTimeValue = reversal.get("created_at");
            String reversalTime = reversalTimeValue == null ? LocalDateTime.now().toString() : String.valueOf(reversalTimeValue);
            for (int index = 0; index < commissions.size(); index++) {
                Map<String, Object> commission = commissions.get(index);
                BigDecimal part = index == commissions.size() - 1
                        ? target.subtract(allocated)
                        : target.multiply(new BigDecimal(String.valueOf(commission.get("amount"))))
                        .divide(total, 2, RoundingMode.HALF_UP);
                if (part.signum() <= 0) continue;
                allocated = allocated.add(part);
                Object settledAtValue = commission.get("settled_at");
                boolean alreadyIncludedInPaidPayroll = commission.get("settled") instanceof Number
                        && ((Number) commission.get("settled")).intValue() == 1
                        && settledAtValue != null && !String.valueOf(settledAtValue).isBlank()
                        && reversalTime.compareTo(String.valueOf(settledAtValue)) <= 0;
                if (alreadyIncludedInPaidPayroll) continue;
                String insertSql = DbCompat.isMySql(db)
                        ? "insert ignore into commissions(employee_id,order_id,order_item_id,service_name,rate,amount,category_name,source_reversal_id,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,0)"
                        : "insert or ignore into commissions(employee_id,order_id,order_item_id,service_name,rate,amount,category_name,source_reversal_id,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,0)";
                db.update(insertSql, commission.get("employee_id"), orderId, commission.get("order_item_id"),
                        "历史退款冲回#" + reversalId, part.negate(), part.negate(),
                        commission.get("category_name"), reversalId, reversalTime, reversalTime);
            }
            db.update("update commission_reversals set payroll_migrated=1,updated_at=coalesce(updated_at,?) where id=?",
                    LocalDateTime.now().toString(), reversalId);
        }
    }

    private void ensureColumn(String table, String column, String definition) {
        DbCompat.ensureColumn(db, table, column, definition);
    }

    private void ddl(String sql) {
        if (!DbCompat.isMySql(db)) { db.execute(sql); return; }
        String x = DbCompat.mysqlDdl(sql)
                .replace("type text not null", "type varchar(40) not null")
                .replace("name text not null", "name varchar(191) not null")
                .replace("shift_no text unique not null", "shift_no varchar(80) unique not null")
                .replace("business_date text not null", "business_date varchar(20) not null");
        db.execute(x);
    }

    private void createIndexes() {
        if (DbCompat.isMySql(db)) {
            DbCompat.createIndexIfMissing(db,"inventory","idx_inventory_barcode_unique","barcode,deleted",true);
            DbCompat.createIndexIfMissing(db,"orders","idx_orders_client_request_unique","client_request_id,deleted",true);
            DbCompat.createIndexIfMissing(db,"balance_logs","idx_balance_logs_request_unique","client_request_id,deleted",true);
            DbCompat.createIndexIfMissing(db,"refunds","idx_refunds_request_unique","client_request_id,deleted",true);
            DbCompat.createIndexIfMissing(db,"orders","idx_orders_created_at","created_at",false);
            DbCompat.createIndexIfMissing(db,"order_items","idx_order_items_order","order_id",false);
            DbCompat.createIndexIfMissing(db,"refund_items","idx_refund_items_order_item","order_item_id",false);
            DbCompat.createIndexIfMissing(db,"inventory_logs","idx_inventory_logs_created","created_at",false);
            DbCompat.createIndexIfMissing(db,"audit_logs","idx_audit_logs_created","created_at",false);
            DbCompat.createIndexIfMissing(db,"commissions","idx_commissions_source_reversal_item_unique","source_reversal_id,order_item_id,employee_id,deleted",true);
        } else {
            db.execute("create unique index if not exists idx_inventory_barcode_unique on inventory(barcode) where barcode is not null and trim(barcode)<>'' and deleted=0");
            db.execute("create unique index if not exists idx_orders_client_request_unique on orders(client_request_id) where client_request_id is not null and trim(client_request_id)<>''");
            db.execute("create unique index if not exists idx_balance_logs_request_unique on balance_logs(client_request_id) where client_request_id is not null and trim(client_request_id)<>''");
            db.execute("create unique index if not exists idx_refunds_request_unique on refunds(client_request_id) where client_request_id is not null and trim(client_request_id)<>''");
            db.execute("create index if not exists idx_orders_created_at on orders(created_at)");
            db.execute("create index if not exists idx_order_items_order on order_items(order_id)");
            db.execute("create index if not exists idx_refund_items_order_item on refund_items(order_item_id)");
            db.execute("create index if not exists idx_inventory_logs_created on inventory_logs(created_at)");
            db.execute("create index if not exists idx_audit_logs_created on audit_logs(created_at)");
            db.execute("drop index if exists idx_commissions_source_reversal_unique");
            db.execute("create unique index if not exists idx_commissions_source_reversal_item_unique on commissions(source_reversal_id,order_item_id,employee_id) where source_reversal_id is not null and deleted=0");
        }
    }
}
