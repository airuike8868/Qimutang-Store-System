package com.qimutang;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/system/mysql")
class MySqlReadinessApi {
    private final MySqlReadinessService readiness;
    MySqlReadinessApi(MySqlReadinessService readiness) { this.readiness = readiness; }

    private void admin(HttpServletRequest request) {
        if (!"管理员".equals(String.valueOf(request.getAttribute("role"))))
            throw new IllegalArgumentException("只有管理员可以执行 MySQL 验收");
    }

    @GetMapping("/readiness")
    Object readiness(HttpServletRequest request) throws Exception {
        admin(request);
        return Map.of("success", true, "data", readiness.check());
    }

    @GetMapping("/migration-counts")
    Object counts(HttpServletRequest request) {
        admin(request);
        return Map.of("success", true, "data", readiness.migrationCounts());
    }
}
