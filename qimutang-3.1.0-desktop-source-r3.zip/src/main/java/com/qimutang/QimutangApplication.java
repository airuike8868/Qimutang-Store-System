package com.qimutang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.imageio.ImageIO;
import java.awt.Desktop;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.URI;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@SpringBootApplication
@EnableScheduling
public class QimutangApplication {
    private static FileChannel instanceChannel;
    private static FileLock instanceLock;
    private static ConfigurableApplicationContext applicationContext;
    private static TrayIcon trayIcon;
    private static final AtomicBoolean EXITING = new AtomicBoolean(false);

    public static void main(String[] args) throws Exception {
        Path dataDir = Path.of(System.getProperty(
                "qimutang.data-dir",
                Path.of(System.getProperty("user.home"), "QimutangData", "data").toString()
        )).toAbsolutePath().normalize();

        System.setProperty("qimutang.data-dir", dataDir.toString());
        Files.createDirectories(dataDir.resolve("uploads/customer"));
        Files.createDirectories(dataDir.resolve("backup"));

        Path lockPath = dataDir.resolve("qimutang.running.lock");
        instanceChannel = FileChannel.open(lockPath,
                StandardOpenOption.CREATE, StandardOpenOption.WRITE);
        try {
            instanceLock = instanceChannel.tryLock();
        } catch (Exception ignored) {
            instanceLock = null;
        }

        if (instanceLock == null) {
            int runningPort = readPort(dataDir.resolve("server.port"), 8080);
            if (!Boolean.getBoolean("qimutang.desktop")) {
                waitAndOpenBrowser(runningPort, 20);
            }
            return;
        }

        Runtime.getRuntime().addShutdownHook(new Thread(
                QimutangApplication::releaseProcessResources,
                "qimutang-shutdown"
        ));

        Path shutdownRequest = dataDir.resolve("shutdown.request");
        Files.deleteIfExists(shutdownRequest);
        startShutdownRequestWatcher(shutdownRequest);

        // Only the process holding the data-directory lock may replace the live database.
        applyPendingRestore(dataDir);

        int requestedPort = Integer.getInteger("server.port", 8080);
        int port = chooseAvailablePort(requestedPort);
        System.setProperty("server.port", String.valueOf(port));
        Files.writeString(dataDir.resolve("server.port"), String.valueOf(port),
                StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING);

        applicationContext = SpringApplication.run(QimutangApplication.class, args);
        if (!Boolean.getBoolean("qimutang.desktop")) {
            installTrayIcon(port);
            openBrowserWhenReady(port, 30);
        }
    }

    private static int chooseAvailablePort(int preferred) {
        for (int candidate = preferred; candidate < preferred + 20; candidate++) {
            try (ServerSocket socket = new ServerSocket()) {
                socket.setReuseAddress(false);
                socket.bind(new InetSocketAddress("127.0.0.1", candidate));
                return candidate;
            } catch (IOException ignored) {
                // Try the next local port. This avoids an unexplained startup failure.
            }
        }
        throw new IllegalStateException("系统端口被占用，请关闭其他本地服务后重试");
    }

    private static int readPort(Path portFile, int fallback) {
        try {
            int port = Integer.parseInt(Files.readString(portFile).trim());
            return port > 0 && port <= 65535 ? port : fallback;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static void openBrowserWhenReady(int port, int attempts) {
        Thread opener = new Thread(
                () -> waitAndOpenBrowser(port, attempts),
                "qimutang-browser-opener"
        );
        opener.setDaemon(true);
        opener.start();
    }

    private static void waitAndOpenBrowser(int port, int attempts) {
        String url = "http://127.0.0.1:" + port;
        for (int i = 0; i < attempts; i++) {
            try {
                HttpURLConnection connection = (HttpURLConnection)
                        URI.create(url + "/api/health").toURL().openConnection();
                connection.setConnectTimeout(800);
                connection.setReadTimeout(800);
                if (connection.getResponseCode() == 200) {
                    openBrowser(port);
                    return;
                }
            } catch (Exception ignored) {
                // The embedded server is still starting.
            }
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    private static void openBrowser(int port) {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(URI.create("http://127.0.0.1:" + port));
            }
        } catch (Exception ignored) {
            // The service keeps running and can still be opened manually.
        }
    }

    private static void installTrayIcon(int port) {
        if (!SystemTray.isSupported()) return;
        try (InputStream input = QimutangApplication.class.getResourceAsStream(
                "/static/qimutang-logo.png")) {
            if (input == null) return;
            Image image = ImageIO.read(input);
            if (image == null) return;

            PopupMenu menu = new PopupMenu();
            MenuItem openItem = new MenuItem("打开齐沐堂管理系统");
            openItem.addActionListener(event -> openBrowser(port));
            menu.add(openItem);
            menu.addSeparator();

            MenuItem exitItem = new MenuItem("退出系统");
            exitItem.addActionListener(event -> exitApplication());
            menu.add(exitItem);

            trayIcon = new TrayIcon(image, "齐沐堂门店管理系统", menu);
            trayIcon.setImageAutoSize(true);
            trayIcon.addActionListener(event -> openBrowser(port));
            SystemTray.getSystemTray().add(trayIcon);
        } catch (Exception ignored) {
            trayIcon = null;
        }
    }

    private static void exitApplication() {
        if (!EXITING.compareAndSet(false, true)) return;
        Thread exitThread = new Thread(() -> {
            if (trayIcon != null && SystemTray.isSupported()) {
                try {
                    SystemTray.getSystemTray().remove(trayIcon);
                } catch (Exception ignored) {
                    // Continue shutting down even if the tray was already removed.
                }
                trayIcon = null;
            }
            if (applicationContext != null) {
                applicationContext.close();
                applicationContext = null;
            }
            releaseProcessResources();
            System.exit(0);
        }, "qimutang-exit");
        exitThread.setDaemon(false);
        exitThread.start();
    }

    private static void startShutdownRequestWatcher(Path request) {
        Thread watcher = new Thread(() -> {
            while (!EXITING.get()) {
                try {
                    if (Files.deleteIfExists(request)) {
                        exitApplication();
                        return;
                    }
                } catch (Exception ignored) {
                    // Try again; a security scanner may briefly hold the request file.
                }
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }, "qimutang-local-control");
        watcher.setDaemon(true);
        watcher.start();
    }

    private static synchronized void releaseProcessResources() {
        try {
            if (instanceLock != null && instanceLock.isValid()) instanceLock.release();
        } catch (Exception ignored) {
            // The operating system also releases the lock when the process exits.
        }
        instanceLock = null;
        try {
            if (instanceChannel != null && instanceChannel.isOpen()) instanceChannel.close();
        } catch (Exception ignored) {
            // Best-effort shutdown cleanup.
        }
        instanceChannel = null;
    }

    private static void applyPendingRestore(Path dataDir) throws IOException {
        Path marker = dataDir.resolve("restore.pending");
        if (!Files.isRegularFile(marker)) return;

        String fileName = Files.readString(marker, StandardCharsets.UTF_8).trim();
        if (!fileName.matches("qimutang_[A-Za-z0-9_-]+\\.(db|zip)")) {
            Files.deleteIfExists(marker);
            return;
        }

        Path backupDir = dataDir.resolve("backup").normalize();
        Path source = backupDir.resolve(fileName).normalize();
        if (!source.startsWith(backupDir) || !Files.isRegularFile(source)) {
            Files.deleteIfExists(marker);
            return;
        }

        Path database = dataDir.resolve("qimutang.db");
        if (Files.isRegularFile(database)) {
            String stamp = LocalDateTime.now().format(
                    DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS"));
            Files.copy(database, backupDir.resolve("qimutang_before_restore_" + stamp + ".db"),
                    StandardCopyOption.COPY_ATTRIBUTES);
        }

        Files.deleteIfExists(dataDir.resolve("qimutang.db-wal"));
        Files.deleteIfExists(dataDir.resolve("qimutang.db-shm"));
        if (fileName.endsWith(".zip")) {
            restoreFullBackup(source, dataDir, database);
        } else {
            Files.copy(source, database, StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.COPY_ATTRIBUTES);
        }
        Files.deleteIfExists(marker);
    }

    private static void restoreFullBackup(Path source, Path dataDir, Path database) throws IOException {
        Path stage = Files.createTempDirectory(dataDir, ".qimutang-restore-");
        try {
            try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(source))) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    String name = entry.getName().replace('\\', '/');
                    if (!("qimutang.db".equals(name) || name.startsWith("uploads/"))) continue;
                    Path target = stage.resolve(name).normalize();
                    if (!target.startsWith(stage)) throw new IOException("备份包包含不安全的路径");
                    if (entry.isDirectory()) {
                        Files.createDirectories(target);
                    } else {
                        Files.createDirectories(target.getParent());
                        Files.copy(zip, target, StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }
            Path restoredDb = stage.resolve("qimutang.db");
            if (!Files.isRegularFile(restoredDb)) throw new IOException("整包备份中缺少数据库文件");
            Files.move(restoredDb, database, StandardCopyOption.REPLACE_EXISTING);

            Path restoredUploads = stage.resolve("uploads");
            Path liveUploads = dataDir.resolve("uploads").normalize();
            if (Files.isDirectory(restoredUploads)) {
                try (var walk = Files.walk(restoredUploads)) {
                    for (Path path : walk.sorted().toList()) {
                        Path relative = restoredUploads.relativize(path);
                        Path target = liveUploads.resolve(relative).normalize();
                        if (!target.startsWith(liveUploads)) throw new IOException("备份包包含不安全的附件路径");
                        if (Files.isDirectory(path)) Files.createDirectories(target);
                        else {
                            Files.createDirectories(target.getParent());
                            Files.copy(path, target, StandardCopyOption.REPLACE_EXISTING,
                                    StandardCopyOption.COPY_ATTRIBUTES);
                        }
                    }
                }
            }
        } finally {
            if (Files.exists(stage)) {
                try (var walk = Files.walk(stage)) {
                    for (Path path : walk.sorted(Comparator.reverseOrder()).toList()) {
                        Files.deleteIfExists(path);
                    }
                }
            }
        }
    }
}
