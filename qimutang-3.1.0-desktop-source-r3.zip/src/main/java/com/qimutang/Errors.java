package com.qimutang;
import org.springframework.web.bind.annotation.*;import java.util.*;import org.slf4j.*;
@RestControllerAdvice class Errors {
 private static final Logger log=LoggerFactory.getLogger(Errors.class);
 @ExceptionHandler(IllegalArgumentException.class) Map<String,Object> business(IllegalArgumentException e){return Map.of("success",false,"message",e.getMessage());}
 @ExceptionHandler(Exception.class) Map<String,Object> other(Exception e){log.error("系统操作失败",e);return Map.of("success",false,"message","操作失败，请检查输入数据或联系管理员");}
}
