package com.qimutang;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/v23")
class V23Api {
    private static final Set<String> PAYMENT_METHODS = Set.of(
            "微信", "支付宝", "现金", "银行卡", "美团", "抖音", "会员余额", "其他"
    );
    private static final Set<String> CATEGORY_TYPES = Set.of("SERVICE", "PRODUCT");
    private final JdbcTemplate db;

    V23Api(JdbcTemplate db) {
        this.db = db;
    }

    private Map<String, Object> ok(Object data) {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("success", true);
        response.put("data", data);
        return response;
    }

    private Map<String, Object> fail(String message) {
        return Map.of("success", false, "message", message);
    }

    private String now() {
        return LocalDateTime.now().toString();
    }

    private long uid(HttpServletRequest request) {
        Object value = request.getAttribute("userId");
        if (!(value instanceof Number)) throw new IllegalArgumentException("登录已失效，请重新登录");
        return ((Number) value).longValue();
    }

    private String role(HttpServletRequest request) {
        return String.valueOf(request.getAttribute("role"));
    }

    private void require(HttpServletRequest request, String... roles) {
        String current = role(request);
        if (Arrays.stream(roles).noneMatch(current::equals)) {
            throw new IllegalArgumentException("当前账号没有此操作权限");
        }
    }

    private String text(Object value) {
        return Objects.toString(value, "").trim();
    }

    private BigDecimal decimal(Object value, String label) {
        try {
            return new BigDecimal(String.valueOf(value == null || "".equals(value) ? 0 : value))
                    .setScale(2, RoundingMode.HALF_UP);
        } catch (Exception e) {
            throw new IllegalArgumentException(label + "格式不正确");
        }
    }

    private Long nullableLong(Object value) {
        if (value == null || text(value).isBlank()) return null;
        try {
            return Long.parseLong(text(value));
        } catch (Exception e) {
            throw new IllegalArgumentException("编号格式不正确");
        }
    }

    private void log(HttpServletRequest request, String type, String content) {
        String time = now();
        db.update("insert into audit_logs(user_id,type,content,ip,created_at,updated_at) values(?,?,?,?,?,?)",
                uid(request), type, content, request.getRemoteAddr(), time, time);
    }

    @GetMapping("/categories")
    Object categories(@RequestParam(required = false) String type,
                      HttpServletRequest request) {
        require(request, "管理员", "店长", "前台", "技师");
        String selected = text(type).toUpperCase(Locale.ROOT);
        boolean canManage = List.of("管理员", "店长").contains(role(request));
        String enabledSql = canManage ? "" : " and enabled=1";
        if (selected.isBlank()) {
            return ok(db.queryForList("select * from categories where deleted=0" + enabledSql +
                    " order by type,sort_order,id"));
        }
        if (!CATEGORY_TYPES.contains(selected)) return fail("分类类型不正确");
        return ok(db.queryForList("select * from categories where deleted=0 and type=?" + enabledSql +
                " order by sort_order,id", selected));
    }

    @PostMapping("/categories")
    Object addCategory(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长");
        String type = text(body.get("type")).toUpperCase(Locale.ROOT);
        String name = text(body.get("name"));
        if (!CATEGORY_TYPES.contains(type)) return fail("分类类型不正确");
        if (name.length() < 2 || name.length() > 30) return fail("分类名称请输入2至30个字");
        int sort = decimal(body.getOrDefault("sortOrder", 0), "排序").intValue();
        String color = text(body.getOrDefault("color", "#146fca"));
        if (!color.matches("#[0-9a-fA-F]{6}")) color = "#146fca";
        String time = now();
        try {
            db.update("insert into categories(type,name,sort_order,color,enabled,created_at,updated_at,deleted) values(?,?,?,?,1,?,?,0)",
                    type, name, sort, color, time, time);
        } catch (Exception e) {
            return fail("这个分类已经存在");
        }
        log(request, "分类管理", "新增" + ("SERVICE".equals(type) ? "服务" : "产品") + "分类：" + name);
        return ok("分类已保存");
    }

    @PutMapping("/categories/{id}")
    @Transactional
    Object updateCategory(@PathVariable long id, @RequestBody Map<String, Object> body,
                          HttpServletRequest request) {
        require(request, "管理员", "店长");
        String name = text(body.get("name"));
        if (name.length() < 2 || name.length() > 30) return fail("分类名称请输入2至30个字");
        int sort = decimal(body.getOrDefault("sortOrder", 0), "排序").intValue();
        boolean enabled = Boolean.parseBoolean(String.valueOf(body.getOrDefault("enabled", true)));
        String color = text(body.getOrDefault("color", "#146fca"));
        if (!color.matches("#[0-9a-fA-F]{6}")) color = "#146fca";
        Map<String, Object> old;
        try {
            old = db.queryForMap("select * from categories where id=? and deleted=0", id);
        } catch (Exception e) {
            return fail("分类不存在");
        }
        try {
            db.update("update categories set name=?,sort_order=?,color=?,enabled=?,updated_at=? where id=?",
                    name, sort, color, enabled ? 1 : 0, now(), id);
            String type = text(old.get("type"));
            String oldName = text(old.get("name"));
            if (!oldName.equals(name)) {
                if ("SERVICE".equals(type)) db.update("update services set category=?,updated_at=? where category=? and deleted=0", name, now(), oldName);
                if ("PRODUCT".equals(type)) db.update("update inventory set category=?,updated_at=? where category=? and deleted=0", name, now(), oldName);
            }
        } catch (Exception e) {
            return fail("这个分类名称已经存在");
        }
        log(request, "分类管理", "分类“" + old.get("name") + "”修改为“" + name + "”，状态：" +
                (enabled ? "启用" : "停用"));
        return ok("分类已更新，历史订单分类不会改变");
    }

    @GetMapping("/employees/options")
    Object employeeOptions(HttpServletRequest request) {
        require(request, "管理员", "店长", "前台", "技师");
        return ok(db.queryForList("select id,name,position from employees where deleted=0 and status='在职' order by id"));
    }

    @PostMapping("/services")
    Object addService(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长");
        return saveService(null, body, request);
    }

    @PutMapping("/services/{id}")
    Object updateService(@PathVariable long id, @RequestBody Map<String, Object> body,
                         HttpServletRequest request) {
        require(request, "管理员", "店长");
        return saveService(id, body, request);
    }

    private Object saveService(Long id, Map<String, Object> body, HttpServletRequest request) {
        String name = text(body.get("name"));
        String category = text(body.get("category"));
        int duration = decimal(body.getOrDefault("duration", 0), "服务时长").intValue();
        BigDecimal listPrice = decimal(body.getOrDefault("listPrice", 0), "门市价");
        BigDecimal memberPrice = decimal(body.getOrDefault("memberPrice", listPrice), "会员价");
        String commissionType = text(body.getOrDefault("commissionType", "FIXED"));
        String serviceType = text(body.getOrDefault("serviceType", "普通服务"));
        String unit = text(body.getOrDefault("unit", "次"));
        BigDecimal minPrice = decimal(body.getOrDefault("minPrice", 0), "最低销售价");
        boolean careRecordRequired = Boolean.parseBoolean(String.valueOf(body.getOrDefault("careRecordRequired", false)));
        boolean photoRequired = Boolean.parseBoolean(String.valueOf(body.getOrDefault("photoRequired", false)));
        int followupDays = decimal(body.getOrDefault("followupDays", 0), "回访周期").intValue();
        BigDecimal commission = decimal(body.getOrDefault("commissionValue", 0), "服务提成");
        if (name.isBlank()) return fail("请输入服务项目名称");
        if (category.isBlank()) return fail("请选择服务分类");
        if (duration < 0 || listPrice.signum() < 0 || memberPrice.signum() < 0 || minPrice.signum() < 0 || followupDays < 0 || commission.signum() < 0) {
            return fail("时长、价格和提成不能小于0");
        }
        if (!Set.of("FIXED", "PERCENT").contains(commissionType)
                || ("PERCENT".equals(commissionType) && commission.compareTo(new BigDecimal("100")) > 0)) {
            return fail("服务提成方式或数值不正确");
        }
        List<Map<String, Object>> categoryRows = db.queryForList(
                "select id from categories where type='SERVICE' and name=? and enabled=1 and deleted=0", category);
        if (categoryRows.isEmpty()) return fail("所选服务分类不存在或已停用");
        long categoryId = ((Number) categoryRows.get(0).get("id")).longValue();
        String time = now();
        boolean status = Boolean.parseBoolean(String.valueOf(body.getOrDefault("status", true)));
        if (id == null) {
            db.update("insert into services(name,category,category_id,duration,list_price,member_price,commission_type,commission_value,status,group_buy,remark,created_at,updated_at,deleted,service_type,unit,min_price,care_record_required,photo_required,followup_days) values(?,?,?,?,?,?,?,?,?,0,?,?,?,0,?,?,?,?,?,?)",
                    name, category, categoryId, duration, listPrice, memberPrice, commissionType,
                    commission, status ? 1 : 0, text(body.get("remark")), time, time, serviceType, unit, minPrice, careRecordRequired ? 1 : 0, photoRequired ? 1 : 0, followupDays);
            log(request, "项目管理", "新增服务项目：" + name + "，分类：" + category);
            return ok("服务项目已保存");
        }
        int changed = db.update("update services set name=?,category=?,category_id=?,duration=?,list_price=?,member_price=?,commission_type=?,commission_value=?,status=?,remark=?,updated_at=?,service_type=?,unit=?,min_price=?,care_record_required=?,photo_required=?,followup_days=? where id=? and deleted=0",
                name, category, categoryId, duration, listPrice, memberPrice, commissionType,
                commission, status ? 1 : 0, text(body.get("remark")), time, serviceType, unit, minPrice, careRecordRequired ? 1 : 0, photoRequired ? 1 : 0, followupDays, id);
        if (changed == 0) return fail("服务项目不存在");
        log(request, "项目管理", "修改服务项目：" + name + "，分类：" + category);
        return ok("服务项目已更新");
    }

    @GetMapping("/products")
    Object products(@RequestParam(defaultValue = "false") boolean retailOnly,
                    HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        boolean manager = List.of("管理员", "店长").contains(role(request));
        if (retailOnly || !manager) {
            return ok(db.queryForList("select id,name,category,quantity,unit,barcode,retail_price,member_price," +
                    "retail_enabled,product_type,expires_at,commission_type,commission_value," +
                    "case when quantity<=min_quantity then 1 else 0 end low_stock " +
                    "from inventory where deleted=0 and retail_enabled=1 order by name,id"));
        }
        return ok(db.queryForList("select *,case when quantity<=min_quantity then 1 else 0 end low_stock " +
                "from inventory where deleted=0 order by low_stock desc,id desc"));
    }

    @PostMapping("/products")
    @Transactional
    Object addProduct(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长");
        String name = text(body.get("name"));
        String category = text(body.get("category"));
        String unit = text(body.getOrDefault("unit", "瓶"));
        String barcode = text(body.get("barcode"));
        String type = text(body.getOrDefault("productType", "护理产品"));
        BigDecimal quantity = decimal(body.getOrDefault("quantity", 0), "初始库存");
        BigDecimal cost = decimal(body.getOrDefault("costPrice", 0), "成本价");
        BigDecimal retail = decimal(body.getOrDefault("retailPrice", 0), "零售价");
        BigDecimal member = decimal(body.getOrDefault("memberPrice", 0), "会员价");
        BigDecimal minimum = decimal(body.getOrDefault("minQuantity", 0), "最低库存");
        BigDecimal commission = decimal(body.getOrDefault("commissionValue", 0), "销售提成");
        String commissionType = text(body.getOrDefault("commissionType", "FIXED"));
        boolean retailEnabled = Boolean.parseBoolean(String.valueOf(body.getOrDefault("retailEnabled", true)));
        if (name.isBlank()) return fail("请输入护理产品名称");
        if (unit.isBlank()) return fail("请输入单位");
        if (quantity.signum() < 0 || cost.signum() < 0 || retail.signum() < 0 || member.signum() < 0 || minimum.signum() < 0) {
            return fail("库存和价格不能小于0");
        }
        if (retailEnabled && retail.signum() <= 0) return fail("启用收银销售时，零售价必须大于0");
        if (!Set.of("FIXED", "PERCENT").contains(commissionType)) return fail("销售提成方式不正确");
        if (commission.signum() < 0 || ("PERCENT".equals(commissionType) && commission.compareTo(new BigDecimal("100")) > 0)) {
            return fail("销售提成数值不正确");
        }
        String time = now();
        try {
            db.update("insert into inventory(name,category,quantity,unit,cost_price,min_quantity,supplier,barcode,retail_price,member_price,retail_enabled,product_type,expires_at,commission_type,commission_value,created_at,updated_at,deleted) " +
                            "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
                    name, category, quantity, unit, cost, minimum, text(body.get("supplier")),
                    barcode.isBlank() ? null : barcode, retail, member, retailEnabled ? 1 : 0, type,
                    text(body.get("expiresAt")).isBlank() ? null : text(body.get("expiresAt")),
                    commissionType, commission, time, time);
        } catch (Exception e) {
            return fail(barcode.isBlank() ? "护理产品保存失败，请检查填写内容" : "条码已被其他产品使用");
        }
        long id = DbCompat.lastInsertId(db);
        if (quantity.signum() > 0) {
            db.update("insert into inventory_logs(inventory_id,type,before_qty,change_qty,after_qty,unit_cost,operator_id,remark,created_at,updated_at) values(?,'期初入库',0,?,?,?,?,?,?,?)",
                    id, quantity, quantity, cost, uid(request), "新增护理产品时登记期初库存", time, time);
        }
        log(request, "护理产品", "新增护理产品：" + name + "，库存" + quantity + unit + "，收银销售：" +
                (retailEnabled ? "启用" : "停用"));
        return ok(Map.of("id", id, "message", retailEnabled ? "保存成功，已在收银台上架" : "保存成功，当前未在收银台上架"));
    }

    @PutMapping("/products/{id}")
    Object updateProduct(@PathVariable long id, @RequestBody Map<String, Object> body,
                         HttpServletRequest request) {
        require(request, "管理员", "店长");
        String name = text(body.get("name"));
        String unit = text(body.getOrDefault("unit", "瓶"));
        String barcode = text(body.get("barcode"));
        BigDecimal cost = decimal(body.getOrDefault("costPrice", 0), "成本价");
        BigDecimal retail = decimal(body.getOrDefault("retailPrice", 0), "零售价");
        BigDecimal member = decimal(body.getOrDefault("memberPrice", 0), "会员价");
        BigDecimal minimum = decimal(body.getOrDefault("minQuantity", 0), "最低库存");
        BigDecimal commission = decimal(body.getOrDefault("commissionValue", 0), "销售提成");
        String commissionType = text(body.getOrDefault("commissionType", "FIXED"));
        boolean retailEnabled = Boolean.parseBoolean(String.valueOf(body.getOrDefault("retailEnabled", true)));
        if (name.isBlank() || unit.isBlank()) return fail("商品名称和单位不能为空");
        if (cost.signum() < 0 || retail.signum() < 0 || member.signum() < 0 || minimum.signum() < 0) {
            return fail("库存和价格不能小于0");
        }
        if (retailEnabled && retail.signum() <= 0) return fail("启用收银销售时，零售价必须大于0");
        if (!Set.of("FIXED", "PERCENT").contains(commissionType)) return fail("销售提成方式不正确");
        try {
            int changed = db.update("update inventory set name=?,category=?,unit=?,cost_price=?,min_quantity=?,supplier=?,barcode=?,retail_price=?,member_price=?,retail_enabled=?,product_type=?,expires_at=?,commission_type=?,commission_value=?,updated_at=? where id=? and deleted=0",
                    name, text(body.get("category")), unit, cost, minimum, text(body.get("supplier")),
                    barcode.isBlank() ? null : barcode, retail, member, retailEnabled ? 1 : 0,
                    text(body.getOrDefault("productType", "护理产品")),
                    text(body.get("expiresAt")).isBlank() ? null : text(body.get("expiresAt")),
                    commissionType, commission, now(), id);
            if (changed == 0) return fail("护理产品不存在");
        } catch (Exception e) {
            return fail("条码已被其他产品使用");
        }
        log(request, "护理产品", "修改护理产品：" + name + "，收银销售：" + (retailEnabled ? "启用" : "停用"));
        return ok(retailEnabled ? "产品已更新，并在收银台显示" : "产品已更新，当前不在收银台显示");
    }

    @PostMapping("/members/recharge")
    @Transactional
    Object recharge(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        String clientRequestId = text(body.get("clientRequestId"));
        if (!clientRequestId.isBlank() && db.queryForObject(
                "select count(*) from balance_logs where client_request_id=? and deleted=0",
                Integer.class, clientRequestId) > 0) {
            return ok("该笔充值已登记，系统没有重复入账");
        }
        long customerId = Long.parseLong(text(body.get("customerId")));
        BigDecimal principal = decimal(body.get("amount"), "充值本金");
        BigDecimal gift = decimal(body.getOrDefault("gift", 0), "赠送金额");
        String paymentMethod = text(body.get("paymentMethod"));
        if (principal.signum() <= 0 || gift.signum() < 0) return fail("充值本金必须大于0，赠送金额不能为负数");
        if (!PAYMENT_METHODS.contains(paymentMethod) || "会员余额".equals(paymentMethod)) return fail("充值付款方式不正确");
        Map<String, Object> customer;
        try {
            customer = db.queryForMap("select * from customers where id=? and deleted=0", customerId);
        } catch (Exception e) {
            return fail("顾客不存在");
        }
        BigDecimal before = decimal(customer.get("balance_principal"), "本金余额")
                .add(decimal(customer.get("balance_gift"), "赠送金余额"));
        String time = now();
        db.update("update customers set balance_principal=balance_principal+?,balance_gift=balance_gift+?,updated_at=? where id=?",
                principal, gift, time, customerId);
        db.update("insert into balance_logs(customer_id,type,before_amount,change_amount,after_amount,operator_id,remark,principal_change,gift_change,payment_method,client_request_id,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
                customerId, "充值", before, principal.add(gift), before.add(principal).add(gift), uid(request),
                text(body.get("remark")), principal, gift, paymentMethod,
                clientRequestId.isBlank() ? null : clientRequestId, time, time);
        log(request, "会员充值", customer.get("name") + "实收本金" + principal + "，赠送" + gift + "，方式" + paymentMethod);
        return ok("充值成功：实收" + principal + "，赠送" + gift);
    }

    @PostMapping("/orders")
    @Transactional
    Object createOrder(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        String clientRequestId = text(body.get("clientRequestId"));
        if (!clientRequestId.isBlank()) {
            List<Map<String, Object>> existing = db.queryForList(
                    "select id,order_no from orders where client_request_id=? and deleted=0", clientRequestId);
            if (!existing.isEmpty()) {
                Map<String, Object> row = existing.get(0);
                return ok(Map.of("orderId", row.get("id"), "orderNo", row.get("order_no"), "duplicate", true));
            }
        }
        Long customerId = nullableLong(body.get("customerId"));
        if (customerId != null && db.queryForObject(
                "select count(*) from customers where id=? and deleted=0", Integer.class, customerId) == 0) {
            return fail("顾客不存在");
        }
        Object rawItems = body.get("items");
        if (!(rawItems instanceof List<?> itemList) || itemList.isEmpty()) return fail("请至少选择一个服务或护理产品");
        List<PreparedItem> items = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;
        BigDecimal originalTotal = BigDecimal.ZERO;
        String globalPriceReason = text(body.get("priceChangeReason"));
        for (Object raw : itemList) {
            if (!(raw instanceof Map<?, ?> map)) return fail("订单项目格式不正确");
            PreparedItem item = prepareItem(map, customerId != null, globalPriceReason, request);
            items.add(item);
            total = total.add(item.lineTotal());
            originalTotal = originalTotal.add(item.originalUnitPrice().multiply(item.quantity()));
        }
        total = total.setScale(2, RoundingMode.HALF_UP);
        List<PaymentInput> payments = parsePayments(body.get("payments"), customerId);
        BigDecimal paid = payments.stream().map(PaymentInput::amount).reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_UP);
        if (paid.compareTo(total) != 0) return fail("支付合计必须与订单金额完全一致");
        for (PreparedItem item : items) {
            if ("PRODUCT".equals(item.type())) {
                BigDecimal stock = db.queryForObject("select quantity from inventory where id=? and deleted=0", BigDecimal.class, item.sourceId());
                if (stock == null || stock.compareTo(item.quantity()) < 0) return fail(item.name() + "库存不足");
            }
        }
        String time = now();
        String orderNo = "QM" + System.currentTimeMillis() + String.format("%02d", new Random().nextInt(100));
        Long shiftId = currentShiftId();
        db.update("insert into orders(order_no,customer_id,total,discount,received,status,operator_id,remark,shift_id,client_request_id,business_date,price_change_reason,created_at,updated_at,deleted) values(?,?,?,?,?,'正常',?,?,?,?,?,?,?,?,0)",
                orderNo, customerId, originalTotal, originalTotal.subtract(total), total, uid(request),
                text(body.get("remark")), shiftId, clientRequestId.isBlank() ? null : clientRequestId,
                LocalDate.now().toString(), globalPriceReason, time, time);
        long orderId = DbCompat.lastInsertId(db);
        for (PreparedItem item : items) {
            db.update("insert into order_items(order_id,service_id,service_name,price,received,technician_id,technician_name,commission,item_type,inventory_id,quantity,unit_price,category_name,cost_price,original_price,price_change_reason,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
                    orderId, "SERVICE".equals(item.type()) ? item.sourceId() : null, item.name(), item.lineTotal(), item.lineTotal(),
                    item.employeeId(), item.employeeName(), item.commission(), item.type(),
                    "PRODUCT".equals(item.type()) ? item.sourceId() : null, item.quantity(), item.unitPrice(),
                    item.category(), item.costPrice(), item.originalUnitPrice(), item.priceReason(), time, time);
            long orderItemId = DbCompat.lastInsertId(db);
            if (item.employeeId() != null && item.commission().signum() > 0) {
                db.update("insert into commissions(employee_id,order_id,order_item_id,service_name,rate,amount,category_name,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,0)",
                        item.employeeId(), orderId, orderItemId, item.name(), item.commissionRate(), item.commission(), item.category(), time, time);
            }
            if ("PRODUCT".equals(item.type())) deductProductStock(item, orderId, time, request);
        }
        savePayments(orderId, customerId, payments, time, request);
        if (customerId != null) {
            db.update("update customers set visit_count=visit_count+1,total_spent=total_spent+?,last_visit=?,updated_at=? where id=?",
                    total, time, time, customerId);
        }
        log(request, "收银开单", "订单" + orderNo + "，实收" + total + "，服务/产品" + items.size() + "项");
        return ok(Map.of("orderId", orderId, "orderNo", orderNo, "total", total));
    }

    private PreparedItem prepareItem(Map<?, ?> map, boolean member, String globalReason,
                                     HttpServletRequest request) {
        String type = text(map.get("type")).toUpperCase(Locale.ROOT);
        if (!Set.of("SERVICE", "PRODUCT").contains(type)) throw new IllegalArgumentException("订单项目类型不正确");
        long id = Long.parseLong(text(map.get("id")));
        BigDecimal quantity = decimal(map.containsKey("quantity") ? map.get("quantity") : 1, "数量");
        if (quantity.signum() <= 0) throw new IllegalArgumentException("数量必须大于0");
        Long employeeId = nullableLong(map.get("employeeId"));
        String employeeName = "";
        if (employeeId != null) {
            try {
                employeeName = db.queryForObject("select name from employees where id=? and deleted=0 and status='在职'", String.class, employeeId);
            } catch (Exception e) {
                throw new IllegalArgumentException("服务员工不存在或已离职");
            }
        }
        Map<String, Object> source;
        String name;
        String category;
        BigDecimal original;
        BigDecimal cost = BigDecimal.ZERO;
        String commissionType;
        BigDecimal commissionValue;
        if ("SERVICE".equals(type)) {
            try {
                source = db.queryForMap("select * from services where id=? and deleted=0 and status=1", id);
            } catch (Exception e) {
                throw new IllegalArgumentException("服务项目不存在或已经下架");
            }
            name = text(source.get("name"));
            category = text(source.get("category"));
            BigDecimal listPrice = decimal(source.get("list_price"), "门市价");
            BigDecimal memberPrice = decimal(source.get("member_price"), "会员价");
            original = member && memberPrice.signum() > 0 ? memberPrice : listPrice;
            commissionType = text(source.getOrDefault("commission_type", "FIXED"));
            commissionValue = decimal(source.getOrDefault("commission_value", 0), "提成");
        } else {
            try {
                source = db.queryForMap("select * from inventory where id=? and deleted=0 and retail_enabled=1", id);
            } catch (Exception e) {
                throw new IllegalArgumentException("护理产品不存在或未开启收银销售");
            }
            name = text(source.get("name"));
            category = text(source.get("category"));
            BigDecimal retailPrice = decimal(source.get("retail_price"), "零售价");
            BigDecimal memberPrice = decimal(source.get("member_price"), "会员价");
            original = member && memberPrice.signum() > 0 ? memberPrice : retailPrice;
            cost = decimal(source.get("cost_price"), "成本价");
            commissionType = text(source.getOrDefault("commission_type", "FIXED"));
            commissionValue = decimal(source.getOrDefault("commission_value", 0), "销售提成");
        }
        BigDecimal requested = map.containsKey("price") ? decimal(map.get("price"), "成交单价") : original;
        String reason = text(map.get("priceChangeReason"));
        if (reason.isBlank()) reason = globalReason;
        if (requested.signum() < 0) throw new IllegalArgumentException("成交单价不能小于0");
        if (requested.compareTo(original) != 0) {
            if (!List.of("管理员", "店长").contains(role(request))) {
                throw new IllegalArgumentException("前台不能修改项目或产品价格");
            }
            if (reason.length() < 2) throw new IllegalArgumentException("改价必须填写原因");
        }
        BigDecimal lineTotal = requested.multiply(quantity).setScale(2, RoundingMode.HALF_UP);
        BigDecimal commission = "PERCENT".equals(commissionType)
                ? lineTotal.multiply(commissionValue).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP)
                : commissionValue.multiply(quantity).setScale(2, RoundingMode.HALF_UP);
        return new PreparedItem(type, id, name, category, quantity, original, requested, lineTotal,
                cost, employeeId, employeeName, commission, commissionValue, reason);
    }

    private List<PaymentInput> parsePayments(Object rawPayments, Long customerId) {
        if (!(rawPayments instanceof List<?> list) || list.isEmpty()) {
            throw new IllegalArgumentException("请选择付款方式");
        }
        List<PaymentInput> result = new ArrayList<>();
        for (Object raw : list) {
            if (!(raw instanceof Map<?, ?> map)) throw new IllegalArgumentException("付款明细格式不正确");
            String method = text(map.get("method"));
            BigDecimal amount = decimal(map.get("amount"), "付款金额");
            if (!PAYMENT_METHODS.contains(method)) throw new IllegalArgumentException("付款方式不正确");
            if (amount.signum() <= 0) throw new IllegalArgumentException("付款金额必须大于0");
            if ("会员余额".equals(method) && customerId == null) throw new IllegalArgumentException("散客不能使用会员余额");
            result.add(new PaymentInput(method, amount));
        }
        return result;
    }

    private void savePayments(long orderId, Long customerId, List<PaymentInput> payments,
                              String time, HttpServletRequest request) {
        for (PaymentInput payment : payments) {
            db.update("insert into payments(order_id,method,amount,created_at,updated_at,deleted) values(?,?,?,?,?,0)",
                    orderId, payment.method(), payment.amount(), time, time);
            long paymentId = DbCompat.lastInsertId(db);
            if ("会员余额".equals(payment.method())) {
                Map<String, BigDecimal> used = deductBalance(customerId, payment.amount(), orderId, time, request);
                db.update("insert into member_payment_allocations(payment_id,customer_id,principal_amount,gift_amount,created_at,updated_at,deleted) values(?,?,?,?,?,?,0)",
                        paymentId, customerId, used.get("principal"), used.get("gift"), time, time);
            }
        }
    }

    private Map<String, BigDecimal> deductBalance(long customerId, BigDecimal amount, long orderId,
                                                   String time, HttpServletRequest request) {
        Map<String, Object> balances;
        try {
            balances = db.queryForMap("select balance_principal,balance_gift from customers where id=? and deleted=0", customerId);
        } catch (Exception e) {
            throw new IllegalArgumentException("会员不存在");
        }
        BigDecimal principal = decimal(balances.get("balance_principal"), "本金余额");
        BigDecimal gift = decimal(balances.get("balance_gift"), "赠送金余额");
        BigDecimal before = principal.add(gift);
        if (before.compareTo(amount) < 0) throw new IllegalArgumentException("会员余额不足");
        BigDecimal giftUse = gift.min(amount);
        BigDecimal principalUse = amount.subtract(giftUse);
        db.update("update customers set balance_gift=balance_gift-?,balance_principal=balance_principal-?,updated_at=? where id=?",
                giftUse, principalUse, time, customerId);
        db.update("insert into balance_logs(customer_id,type,before_amount,change_amount,after_amount,order_id,operator_id,remark,principal_change,gift_change,payment_method,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
                customerId, "消费", before, amount.negate(), before.subtract(amount), orderId, uid(request),
                "订单消费（优先使用赠送金）", principalUse.negate(), giftUse.negate(), "会员余额", time, time);
        return Map.of("principal", principalUse, "gift", giftUse);
    }

    private void deductProductStock(PreparedItem item, long orderId, String time,
                                    HttpServletRequest request) {
        BigDecimal before = db.queryForObject("select quantity from inventory where id=?", BigDecimal.class, item.sourceId());
        BigDecimal after = before.subtract(item.quantity());
        if (after.signum() < 0) throw new IllegalArgumentException(item.name() + "库存不足");
        db.update("update inventory set quantity=?,updated_at=? where id=?", after, time, item.sourceId());
        db.update("insert into inventory_logs(inventory_id,type,before_qty,change_qty,after_qty,unit_cost,operator_id,remark,created_at,updated_at,deleted) values(?,'零售出库',?,?,?,?,?,?,?, ?,0)",
                item.sourceId(), before, item.quantity().negate(), after, item.costPrice(), uid(request),
                "订单" + orderId + "护理产品销售", time, time);
    }

    @GetMapping("/orders/{id}/refund-preview")
    Object refundPreview(@PathVariable long id, HttpServletRequest request) {
        require(request, "管理员", "店长");
        List<Map<String, Object>> orders = db.queryForList("select * from orders where id=? and deleted=0", id);
        if (orders.isEmpty()) return fail("订单不存在");
        List<Map<String, Object>> items = db.queryForList(
                "select oi.*,coalesce((select sum(ri.quantity) from refund_items ri where ri.order_item_id=oi.id and ri.deleted=0),0) refunded_quantity," +
                        "coalesce((select sum(ri.amount) from refund_items ri where ri.order_item_id=oi.id and ri.deleted=0),0) refunded_amount " +
                        "from order_items oi where oi.order_id=? and oi.deleted=0 order by oi.id", id);
        BigDecimal refunded = db.queryForObject("select coalesce(sum(amount),0) from refunds where order_id=? and deleted=0", BigDecimal.class, id);
        return ok(Map.of("order", orders.get(0), "items", items, "refunded", refunded,
                "remaining", decimal(orders.get(0).get("received"), "实收").subtract(refunded),
                "payments", db.queryForList("select * from payments where order_id=? and deleted=0", id)));
    }

    @PostMapping("/orders/{id}/refund-items")
    @Transactional
    Object refundItems(@PathVariable long id, @RequestBody Map<String, Object> body,
                       HttpServletRequest request) {
        require(request, "管理员", "店长");
        String clientRequestId = text(body.get("clientRequestId"));
        if (!clientRequestId.isBlank() && db.queryForObject(
                "select count(*) from refunds where client_request_id=? and deleted=0",
                Integer.class, clientRequestId) > 0) {
            return ok("该笔退款已登记，系统没有重复冲账");
        }
        String reason = text(body.get("reason"));
        if (reason.length() < 2) return fail("请填写退款原因");
        Object rawSelections = body.get("items");
        if (!(rawSelections instanceof List<?> selections) || selections.isEmpty()) return fail("请选择要退款的项目或产品");
        Map<String, Object> order;
        try {
            order = db.queryForMap("select * from orders where id=? and deleted=0", id);
        } catch (Exception e) {
            return fail("订单不存在");
        }
        boolean hasExternal = db.queryForObject("select count(*) from payments where order_id=? and deleted=0 and method<>'会员余额'", Integer.class, id) > 0;
        if (hasExternal && !Boolean.parseBoolean(String.valueOf(body.getOrDefault("externalRefundConfirmed", false)))) {
            return fail("请先完成微信、支付宝、现金等实际退款，再勾选已完成实际退款");
        }
        List<RefundLine> lines = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;
        for (Object raw : selections) {
            if (!(raw instanceof Map<?, ?> map)) return fail("退款明细格式不正确");
            long orderItemId = Long.parseLong(text(map.get("orderItemId")));
            Map<String, Object> item;
            try {
                item = db.queryForMap("select * from order_items where id=? and order_id=? and deleted=0", orderItemId, id);
            } catch (Exception e) {
                return fail("退款项目不存在");
            }
            BigDecimal soldQty = decimal(item.getOrDefault("quantity", 1), "销售数量");
            BigDecimal refundedQty = db.queryForObject("select coalesce(sum(quantity),0) from refund_items where order_item_id=? and deleted=0", BigDecimal.class, orderItemId);
            BigDecimal availableQty = soldQty.subtract(refundedQty);
            BigDecimal quantity = decimal(map.containsKey("quantity") ? map.get("quantity") : availableQty, "退款数量");
            if (quantity.signum() <= 0 || quantity.compareTo(availableQty) > 0) return fail(item.get("service_name") + "退款数量不正确");
            BigDecimal lineReceived = decimal(item.get("received"), "项目实收");
            BigDecimal refundedAmount = db.queryForObject("select coalesce(sum(amount),0) from refund_items where order_item_id=? and deleted=0", BigDecimal.class, orderItemId);
            BigDecimal remainingAmount = lineReceived.subtract(refundedAmount);
            BigDecimal unitPrice = decimal(item.getOrDefault("unit_price", lineReceived.divide(soldQty, 2, RoundingMode.HALF_UP)), "成交单价");
            BigDecimal amount = map.containsKey("amount") ? decimal(map.get("amount"), "退款金额")
                    : unitPrice.multiply(quantity).setScale(2, RoundingMode.HALF_UP);
            if (amount.signum() <= 0 || amount.compareTo(remainingAmount) > 0) return fail(item.get("service_name") + "退款金额不正确");
            String type = text(item.getOrDefault("item_type", "SERVICE"));
            boolean restock = "PRODUCT".equals(type) && Boolean.parseBoolean(String.valueOf(
                    map.containsKey("restock") ? map.get("restock") : false));
            if ("PACKAGE".equals(type)) {
                Long packageId = nullableLong(item.get("package_id"));
                if (packageId != null) {
                    Map<String, Object> pack = db.queryForMap("select used_times,total_times from packages where id=? and deleted=0", packageId);
                    if (((Number) pack.get("used_times")).intValue() > 0) return fail("次卡已经核销，不能直接整卡退款，请先撤销核销");
                    if (quantity.compareTo(availableQty) != 0 || amount.compareTo(remainingAmount) != 0) return fail("未使用次卡只能整卡退款");
                }
            }
            lines.add(new RefundLine(item, quantity, amount, restock));
            total = total.add(amount);
        }
        BigDecimal received = decimal(order.get("received"), "订单实收");
        BigDecimal alreadyRefunded = db.queryForObject("select coalesce(sum(amount),0) from refunds where order_id=? and deleted=0", BigDecimal.class, id);
        if (total.add(alreadyRefunded).compareTo(received) > 0) return fail("退款金额超过订单剩余可退金额");
        String time = now();
        db.update("insert into refunds(order_id,amount,reason,operator_id,client_request_id,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,0)",
                id, total, reason, uid(request), clientRequestId.isBlank() ? null : clientRequestId, time, time);
        long refundId = DbCompat.lastInsertId(db);
        allocateRefundPayments(id, refundId, total, time, request);
        for (RefundLine line : lines) applyRefundLine(line, id, refundId, time, request);
        BigDecimal allRefunded = alreadyRefunded.add(total);
        String status = allRefunded.compareTo(received) == 0 ? "已退款" : "部分退款";
        db.update("update orders set status=?,updated_at=? where id=?", status, time, id);
        if (order.get("customer_id") != null) {
            db.update("update customers set total_spent=max(total_spent-?,0),updated_at=? where id=?",
                    total, time, order.get("customer_id"));
        }
        db.update("insert into finance_records(business_date,direction,category,amount,payment_method,operator_id,remark,created_at,updated_at,deleted) values(?,'支出','订单退款',?,'原支付渠道',?,?,?,?,0)",
                LocalDate.now().toString(), total, uid(request), "订单" + order.get("order_no") + "；已确认实际退款；" + reason, time, time);
        log(request, "逐项退款", "订单" + order.get("order_no") + "退款" + total + "，" + lines.size() + "项，原因：" + reason);
        return ok("退款登记成功：" + total + "，库存和对应员工提成已按所选项目处理");
    }

    private void allocateRefundPayments(long orderId, long refundId, BigDecimal amount,
                                        String time, HttpServletRequest request) {
        BigDecimal remaining = amount;
        for (Map<String, Object> payment : db.queryForList(
                "select * from payments where order_id=? and deleted=0 order by id desc", orderId)) {
            if (remaining.signum() <= 0) break;
            long paymentId = ((Number) payment.get("id")).longValue();
            BigDecimal paid = decimal(payment.get("amount"), "支付金额");
            BigDecimal returned = db.queryForObject("select coalesce(sum(amount),0) from refund_payments where payment_id=? and deleted=0", BigDecimal.class, paymentId);
            BigDecimal part = paid.subtract(returned).min(remaining);
            if (part.signum() <= 0) continue;
            String method = text(payment.get("method"));
            db.update("insert into refund_payments(refund_id,payment_id,method,amount,created_at,updated_at,deleted) values(?,?,?,?,?,?,0)",
                    refundId, paymentId, method, part, time, time);
            if ("会员余额".equals(method)) restoreMemberPayment(paymentId, part, orderId, time, request);
            remaining = remaining.subtract(part);
        }
        if (remaining.signum() > 0) throw new IllegalArgumentException("订单支付明细异常，无法完成退款登记");
    }

    private void restoreMemberPayment(long paymentId, BigDecimal amount, long orderId,
                                      String time, HttpServletRequest request) {
        Map<String, Object> allocation = db.queryForMap("select * from member_payment_allocations where payment_id=? and deleted=0", paymentId);
        long customerId = ((Number) allocation.get("customer_id")).longValue();
        BigDecimal giftAvailable = decimal(allocation.get("gift_amount"), "赠送金支付")
                .subtract(decimal(allocation.get("gift_refunded"), "赠送金已退"));
        BigDecimal principalAvailable = decimal(allocation.get("principal_amount"), "本金支付")
                .subtract(decimal(allocation.get("principal_refunded"), "本金已退"));
        BigDecimal gift = giftAvailable.min(amount);
        BigDecimal principal = amount.subtract(gift);
        if (principal.compareTo(principalAvailable) > 0) throw new IllegalArgumentException("会员余额退款分配异常");
        BigDecimal before = db.queryForObject("select balance_principal+balance_gift from customers where id=?", BigDecimal.class, customerId);
        db.update("update customers set balance_gift=balance_gift+?,balance_principal=balance_principal+?,updated_at=? where id=?",
                gift, principal, time, customerId);
        db.update("update member_payment_allocations set gift_refunded=gift_refunded+?,principal_refunded=principal_refunded+?,updated_at=? where payment_id=?",
                gift, principal, time, paymentId);
        db.update("insert into balance_logs(customer_id,type,before_amount,change_amount,after_amount,order_id,operator_id,remark,principal_change,gift_change,payment_method,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
                customerId, "退款", before, amount, before.add(amount), orderId, uid(request),
                "逐项退款，按原本金/赠送金恢复", principal, gift, "会员余额", time, time);
    }

    private void applyRefundLine(RefundLine line, long orderId, long refundId, String time,
                                 HttpServletRequest request) {
        Map<String, Object> item = line.item();
        long orderItemId = ((Number) item.get("id")).longValue();
        BigDecimal itemReceived = decimal(item.get("received"), "项目实收");
        BigDecimal commission = decimal(item.getOrDefault("commission", 0), "项目提成");
        BigDecimal alreadyReversed = db.queryForObject("select coalesce(sum(amount),0) from commission_reversals where order_item_id=? and deleted=0", BigDecimal.class, orderItemId);
        BigDecimal reversal = itemReceived.signum() == 0 ? BigDecimal.ZERO
                : commission.multiply(line.amount()).divide(itemReceived, 2, RoundingMode.HALF_UP)
                .min(commission.subtract(alreadyReversed).max(BigDecimal.ZERO));
        db.update("insert into refund_items(refund_id,order_item_id,quantity,amount,restock,commission_reversal,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,0)",
                refundId, orderItemId, line.quantity(), line.amount(), line.restock() ? 1 : 0, reversal, time, time);
        if (reversal.signum() > 0) {
            db.update("insert into commission_reversals(order_id,refund_id,amount,order_item_id,employee_id,payroll_migrated,created_at,updated_at,deleted) values(?,?,?,?,?,1,?,?,0)",
                    orderId, refundId, reversal, orderItemId, item.get("technician_id"), time, time);
            long reversalId = DbCompat.lastInsertId(db);
            if (item.get("technician_id") != null) {
                db.update("insert into commissions(employee_id,order_id,order_item_id,service_name,rate,amount,category_name,source_reversal_id,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,0)",
                        item.get("technician_id"), orderId, orderItemId,
                        "退款冲回-" + text(item.get("service_name")), reversal.negate(), reversal.negate(),
                        text(item.get("category_name")), reversalId, time, time);
            }
        }
        String type = text(item.getOrDefault("item_type", "SERVICE"));
        if ("PRODUCT".equals(type) && line.restock()) {
            long inventoryId = ((Number) item.get("inventory_id")).longValue();
            BigDecimal before = db.queryForObject("select quantity from inventory where id=?", BigDecimal.class, inventoryId);
            BigDecimal after = before.add(line.quantity());
            db.update("update inventory set quantity=?,updated_at=? where id=?", after, time, inventoryId);
            db.update("insert into inventory_logs(inventory_id,type,before_qty,change_qty,after_qty,unit_cost,operator_id,remark,created_at,updated_at,deleted) values(?,'销售退货',?,?,?,?,?,?,?, ?,0)",
                    inventoryId, before, line.quantity(), after, item.get("cost_price"), uid(request),
                    "订单" + orderId + "逐项退货回库", time, time);
        }
        if ("PACKAGE".equals(type) && item.get("package_id") != null) {
            db.update("update packages set status='已退款',updated_at=? where id=?", time, item.get("package_id"));
        }
    }

    @GetMapping("/shifts/current")
    Object currentShift(HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        List<Map<String, Object>> rows = db.queryForList("select s.*,u.name opener_name from shifts s left join users u on u.id=s.opener_id where s.deleted=0 and s.status='营业中' order by s.id desc limit 1");
        if (rows.isEmpty()) return ok(null);
        Map<String, Object> result = new LinkedHashMap<>(rows.get(0));
        result.put("summary", shiftSummary(rows.get(0)));
        return ok(result);
    }

    @PostMapping("/shifts/open")
    Object openShift(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        if (currentShiftId() != null) return fail("当前已经有营业中的班次，请先交班日结");
        BigDecimal openingCash = decimal(body.getOrDefault("openingCash", 0), "备用金");
        if (openingCash.signum() < 0) return fail("备用金不能小于0");
        String time = now();
        String shiftNo = "JB" + System.currentTimeMillis();
        db.update("insert into shifts(shift_no,business_date,status,opener_id,opening_cash,opened_at,remark,created_at,updated_at,deleted) values(?,?,'营业中',?,?,?,?,?,?,0)",
                shiftNo, LocalDate.now().toString(), uid(request), openingCash, time, text(body.get("remark")), time, time);
        log(request, "交接班", "开班" + shiftNo + "，备用金" + openingCash);
        return ok("开班成功：" + shiftNo);
    }

    @PostMapping("/shifts/{id}/close")
    @Transactional
    Object closeShift(@PathVariable long id, @RequestBody Map<String, Object> body,
                      HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        Map<String, Object> shift;
        try {
            shift = db.queryForMap("select * from shifts where id=? and deleted=0 and status='营业中'", id);
        } catch (Exception e) {
            return fail("营业中的班次不存在");
        }
        Map<String, BigDecimal> expected = shiftSummary(shift);
        Map<String, BigDecimal> actual = new LinkedHashMap<>();
        for (String key : List.of("cash", "wechat", "alipay", "card", "meituan", "douyin", "other")) {
            BigDecimal value = decimal(body.getOrDefault("actual" + capitalize(key), 0), "实盘金额");
            if ("cash".equals(key) && value.signum() < 0) return fail("现金实盘金额不能小于0");
            actual.put(key, value);
        }
        BigDecimal totalDifference = BigDecimal.ZERO;
        for (String key : actual.keySet()) totalDifference = totalDifference.add(actual.get(key).subtract(expected.get(key)).abs());
        String remark = text(body.get("remark"));
        if (totalDifference.compareTo(new BigDecimal("0.01")) > 0 && remark.length() < 2) {
            return fail("存在账目差异，请填写差异原因");
        }
        String time = now();
        db.update("update shifts set status='已日结',closer_id=?,closed_at=?," +
                        "expected_cash=?,actual_cash=?,difference_cash=?,expected_wechat=?,actual_wechat=?,difference_wechat=?," +
                        "expected_alipay=?,actual_alipay=?,difference_alipay=?,expected_card=?,actual_card=?,difference_card=?," +
                        "expected_meituan=?,actual_meituan=?,difference_meituan=?,expected_douyin=?,actual_douyin=?,difference_douyin=?," +
                        "expected_other=?,actual_other=?,difference_other=?,remark=?,updated_at=? where id=?",
                uid(request), time,
                expected.get("cash"), actual.get("cash"), actual.get("cash").subtract(expected.get("cash")),
                expected.get("wechat"), actual.get("wechat"), actual.get("wechat").subtract(expected.get("wechat")),
                expected.get("alipay"), actual.get("alipay"), actual.get("alipay").subtract(expected.get("alipay")),
                expected.get("card"), actual.get("card"), actual.get("card").subtract(expected.get("card")),
                expected.get("meituan"), actual.get("meituan"), actual.get("meituan").subtract(expected.get("meituan")),
                expected.get("douyin"), actual.get("douyin"), actual.get("douyin").subtract(expected.get("douyin")),
                expected.get("other"), actual.get("other"), actual.get("other").subtract(expected.get("other")),
                remark, time, id);
        log(request, "交接班", "日结" + shift.get("shift_no") + "，差异绝对值合计" + totalDifference);
        return ok("日结完成，差异合计：" + totalDifference.setScale(2, RoundingMode.HALF_UP));
    }

    @GetMapping("/shifts")
    Object shifts(HttpServletRequest request) {
        require(request, "管理员", "店长");
        return ok(db.queryForList("select s.*,o.name opener_name,c.name closer_name from shifts s left join users o on o.id=s.opener_id left join users c on c.id=s.closer_id where s.deleted=0 order by s.id desc limit 180"));
    }

    private Long currentShiftId() {
        List<Long> ids = db.query("select id from shifts where deleted=0 and status='营业中' order by id desc limit 1",
                (rs, rowNum) -> rs.getLong(1));
        return ids.isEmpty() ? null : ids.get(0);
    }

    private Map<String, BigDecimal> shiftSummary(Map<String, Object> shift) {
        String start = text(shift.get("opened_at"));
        String end = text(shift.get("closed_at"));
        if (end.isBlank()) end = now();
        Map<String, BigDecimal> values = new LinkedHashMap<>();
        values.put("cash", decimal(shift.getOrDefault("opening_cash", 0), "备用金"));
        for (String key : List.of("wechat", "alipay", "card", "meituan", "douyin", "other")) values.put(key, BigDecimal.ZERO);

        for (Map<String, Object> row : db.queryForList(
                "select method,sum(amount) amount from payments where deleted=0 and created_at>=? and created_at<=? group by method", start, end)) {
            addMethod(values, text(row.get("method")), decimal(row.get("amount"), "收款"));
        }
        for (Map<String, Object> row : db.queryForList(
                "select method,sum(amount) amount from refund_payments where deleted=0 and created_at>=? and created_at<=? group by method", start, end)) {
            addMethod(values, text(row.get("method")), decimal(row.get("amount"), "退款").negate());
        }
        for (Map<String, Object> row : db.queryForList(
                "select payment_method method,sum(principal_change) amount from balance_logs where deleted=0 and type='充值' and created_at>=? and created_at<=? group by payment_method", start, end)) {
            addMethod(values, text(row.get("method")), decimal(row.get("amount"), "充值"));
        }
        for (Map<String, Object> row : db.queryForList(
                "select payment_method method,sum(case when direction='收入' then amount else -amount end) amount from finance_records where deleted=0 and category<>'订单退款' and created_at>=? and created_at<=? group by payment_method", start, end)) {
            addMethod(values, text(row.get("method")), decimal(row.get("amount"), "收支"));
        }
        return values;
    }

    private void addMethod(Map<String, BigDecimal> values, String method, BigDecimal amount) {
        String key = switch (method) {
            case "现金" -> "cash";
            case "微信" -> "wechat";
            case "支付宝" -> "alipay";
            case "银行卡" -> "card";
            case "美团" -> "meituan";
            case "抖音" -> "douyin";
            case "会员余额" -> null;
            default -> "other";
        };
        if (key != null) values.put(key, values.get(key).add(amount));
    }

    private String capitalize(String value) {
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    @GetMapping("/reports/performance")
    Object performance(@RequestParam String from, @RequestParam String to,
                       HttpServletRequest request) {
        require(request, "管理员", "店长");
        LocalDate start;
        LocalDate end;
        try {
            start = LocalDate.parse(from);
            end = LocalDate.parse(to);
        } catch (Exception e) {
            return fail("查询日期不正确");
        }
        if (start.isAfter(end)) return fail("开始日期不能晚于结束日期");
        List<Map<String, Object>> categories = db.queryForList(
                "select coalesce(nullif(oi.category_name,''),'未分类') category,oi.item_type," +
                        "sum(oi.quantity) sold_quantity,sum(oi.received) gross_amount," +
                        "sum(coalesce((select sum(ri.quantity) from refund_items ri where ri.order_item_id=oi.id and ri.deleted=0),0)) refund_quantity," +
                        "sum(coalesce((select sum(ri.amount) from refund_items ri where ri.order_item_id=oi.id and ri.deleted=0),0)) refund_amount," +
                        "sum(case when oi.item_type='PRODUCT' then oi.cost_price*(oi.quantity-coalesce((select sum(ri.quantity) from refund_items ri where ri.order_item_id=oi.id and ri.restock=1 and ri.deleted=0),0)) else 0 end) cost_amount " +
                        "from order_items oi join orders o on o.id=oi.order_id " +
                        "where oi.deleted=0 and o.deleted=0 and date(o.business_date) between date(?) and date(?) " +
                        "group by oi.category_name,oi.item_type order by gross_amount desc", from, to);
        for (Map<String, Object> row : categories) {
            BigDecimal gross = decimal(row.get("gross_amount"), "销售额");
            BigDecimal refund = decimal(row.get("refund_amount"), "退款额");
            BigDecimal cost = decimal(row.get("cost_amount"), "成本");
            row.put("net_amount", gross.subtract(refund));
            row.put("gross_profit", gross.subtract(refund).subtract(cost));
        }
        List<Map<String, Object>> employees = db.queryForList(
                "select oi.technician_id,coalesce(nullif(oi.technician_name,''),'未指定') employee_name," +
                        "coalesce(nullif(oi.category_name,''),'未分类') category," +
                        "count(*) service_count,sum(oi.received) gross_amount," +
                        "sum(coalesce((select sum(ri.amount) from refund_items ri where ri.order_item_id=oi.id and ri.deleted=0),0)) refund_amount," +
                        "sum(oi.commission) gross_commission," +
                        "sum(coalesce((select sum(cr.amount) from commission_reversals cr where cr.order_item_id=oi.id and cr.deleted=0),0)) reversed_commission " +
                        "from order_items oi join orders o on o.id=oi.order_id " +
                        "where oi.deleted=0 and o.deleted=0 and oi.technician_id is not null and date(o.business_date) between date(?) and date(?) " +
                        "group by oi.technician_id,oi.technician_name,oi.category_name order by gross_amount desc", from, to);
        for (Map<String, Object> row : employees) {
            row.put("net_amount", decimal(row.get("gross_amount"), "员工业绩")
                    .subtract(decimal(row.get("refund_amount"), "员工退款")));
            row.put("net_commission", decimal(row.get("gross_commission"), "员工提成")
                    .subtract(decimal(row.get("reversed_commission"), "冲回提成")));
        }
        return ok(Map.of("categories", categories, "employees", employees));
    }


    @GetMapping("/package-templates")
    Object packageTemplates(HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        boolean canManage = List.of("管理员", "店长").contains(role(request));
        String statusSql = canManage ? "" : " and pt.status=1";
        return ok(db.queryForList(
                "select pt.*,s.name service_name,s.category service_category from package_templates pt " +
                        "left join services s on s.id=pt.service_id " +
                        "where pt.deleted=0" + statusSql + " order by pt.status desc,pt.id desc"));
    }

    @PostMapping("/package-templates")
    Object createPackageTemplate(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长");
        return savePackageTemplate(null, body, request);
    }

    @PutMapping("/package-templates/{id}")
    Object updatePackageTemplate(@PathVariable long id, @RequestBody Map<String, Object> body,
                                 HttpServletRequest request) {
        require(request, "管理员", "店长");
        return savePackageTemplate(id, body, request);
    }

    private Object savePackageTemplate(Long id, Map<String, Object> body, HttpServletRequest request) {
        String name = text(body.get("name"));
        String templateType = text(body.getOrDefault("templateType", "次卡"));
        if (!Set.of("次卡", "组合套餐").contains(templateType)) return fail("卡项类型不正确");
        if (name.isBlank() || name.length() > 60) return fail("请输入1至60个字的卡项名称");
        Long serviceId = nullableLong(body.get("serviceId"));
        if (serviceId == null) return fail("请选择对应服务项目");
        if (db.queryForObject("select count(*) from services where id=? and deleted=0 and status=1", Integer.class, serviceId) == 0) {
            return fail("对应服务项目不存在或已下架");
        }
        int totalTimes;
        int validDays;
        try {
            totalTimes = Integer.parseInt(text(body.getOrDefault("totalTimes", 1)));
            validDays = Integer.parseInt(text(body.getOrDefault("validDays", 0)));
        } catch (Exception e) {
            return fail("次数或有效期格式不正确");
        }
        if (totalTimes < 1 || totalTimes > 999) return fail("次数请输入1至999");
        if (validDays < 0 || validDays > 3650) return fail("有效期请输入0至3650天");
        BigDecimal price = decimal(body.get("price"), "售价");
        if (price.signum() <= 0) return fail("售价必须大于0");
        boolean status = Boolean.parseBoolean(String.valueOf(body.getOrDefault("status", true)));
        String time = now();
        try {
            if (id == null) {
                db.update("insert into package_templates(name,template_type,service_id,total_times,price,valid_days,status,remark,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,0)",
                        name, templateType, serviceId, totalTimes, price, validDays, status ? 1 : 0,
                        text(body.get("remark")), time, time);
                log(request, "项目中心", "新增卡项模板：" + name);
            } else {
                if (db.queryForObject("select count(*) from package_templates where id=? and deleted=0", Integer.class, id) == 0) {
                    return fail("卡项模板不存在");
                }
                db.update("update package_templates set name=?,template_type=?,service_id=?,total_times=?,price=?,valid_days=?,status=?,remark=?,updated_at=? where id=?",
                        name, templateType, serviceId, totalTimes, price, validDays, status ? 1 : 0,
                        text(body.get("remark")), time, id);
                log(request, "项目中心", "修改卡项模板：" + name + "，状态：" + (status ? "上架" : "停用"));
            }
        } catch (Exception e) {
            return fail("卡项名称已存在，请换一个名称");
        }
        return ok("卡项模板已保存");
    }

    @PostMapping("/packages/sell")
    @Transactional
    Object sellPackage(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        String clientRequestId = text(body.get("clientRequestId"));
        if (!clientRequestId.isBlank()) {
            List<Map<String, Object>> existing = db.queryForList(
                    "select p.id packageId,o.id orderId,o.order_no orderNo from orders o " +
                            "left join packages p on p.sale_order_id=o.id and p.deleted=0 " +
                            "where o.client_request_id=? and o.deleted=0 limit 1", clientRequestId);
            if (!existing.isEmpty()) return ok(existing.get(0));
        }
        long customerId = Long.parseLong(text(body.get("customerId")));
        long serviceId = Long.parseLong(text(body.get("serviceId")));
        int totalTimes;
        try {
            totalTimes = Integer.parseInt(text(body.get("totalTimes")));
        } catch (Exception e) {
            return fail("套餐次数不正确");
        }
        if (totalTimes <= 0 || totalTimes > 999) return fail("套餐次数请输入1至999");
        String name = text(body.get("name"));
        if (name.isBlank()) return fail("请输入套餐名称");
        BigDecimal price = decimal(body.get("price"), "套餐价格");
        if (price.signum() <= 0) return fail("套餐价格必须大于0");
        if (db.queryForObject("select count(*) from customers where id=? and deleted=0", Integer.class, customerId) == 0) return fail("顾客不存在");
        Map<String, Object> service;
        try {
            service = db.queryForMap("select * from services where id=? and deleted=0 and status=1", serviceId);
        } catch (Exception e) {
            return fail("对应服务项目不存在或已下架");
        }
        List<PaymentInput> payments = parsePayments(body.get("payments"), customerId);
        BigDecimal paid = payments.stream().map(PaymentInput::amount).reduce(BigDecimal.ZERO, BigDecimal::add);
        if (paid.setScale(2, RoundingMode.HALF_UP).compareTo(price) != 0) return fail("付款合计必须等于套餐价格");
        String time = now();
        String orderNo = "TK" + System.currentTimeMillis();
        db.update("insert into orders(order_no,customer_id,total,discount,received,status,operator_id,remark,shift_id,client_request_id,business_date,created_at,updated_at,deleted) values(?,?,?,?,?,'正常',?,?,?,?,?,?,?,0)",
                orderNo, customerId, price, BigDecimal.ZERO, price, uid(request), "次卡销售：" + name,
                currentShiftId(), clientRequestId.isBlank() ? null : clientRequestId, LocalDate.now().toString(), time, time);
        long orderId = DbCompat.lastInsertId(db);
        db.update("insert into order_items(order_id,service_id,service_name,price,received,commission,item_type,quantity,unit_price,category_name,original_price,created_at,updated_at,deleted) values(?,?,?,?,?,0,'PACKAGE',1,?,'套餐次卡',?,?,?,0)",
                orderId, serviceId, name, price, price, price, price, time, time);
        long orderItemId = DbCompat.lastInsertId(db);
        db.update("insert into packages(customer_id,name,service_id,total_times,used_times,expires_at,status,price,paid_amount,sale_order_id,created_at,updated_at,deleted) values(?,?,?,?,0,?,'正常',?,?,?,?,?,0)",
                customerId, name, serviceId, totalTimes,
                text(body.get("expiresAt")).isBlank() ? null : text(body.get("expiresAt")),
                price, price, orderId, time, time);
        long packageId = DbCompat.lastInsertId(db);
        db.update("update order_items set package_id=? where id=?", packageId, orderItemId);
        savePayments(orderId, customerId, payments, time, request);
        db.update("update customers set total_spent=total_spent+?,updated_at=? where id=?", price, time, customerId);
        log(request, "次卡销售", name + "，次数" + totalTimes + "，实收" + price + "，订单" + orderNo);
        return ok(Map.of("packageId", packageId, "orderId", orderId, "orderNo", orderNo));
    }

    @PostMapping("/packages/{id}/use")
    @Transactional
    Object usePackage(@PathVariable long id, @RequestBody Map<String, Object> body,
                      HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        Map<String, Object> pack;
        try {
            pack = db.queryForMap("select * from packages where id=? and deleted=0", id);
        } catch (Exception e) {
            return fail("次卡不存在");
        }
        int total = ((Number) pack.get("total_times")).intValue();
        int used = ((Number) pack.get("used_times")).intValue();
        if (!"正常".equals(text(pack.get("status")))) return fail("该次卡当前不能核销");
        if (used >= total) return fail("该次卡剩余次数不足");
        if (pack.get("expires_at") != null && !text(pack.get("expires_at")).isBlank()
                && LocalDate.parse(text(pack.get("expires_at"))).isBefore(LocalDate.now())) return fail("该次卡已经到期");
        String time = now();
        String status = used + 1 >= total ? "已用完" : "正常";
        db.update("update packages set used_times=used_times+1,status=?,updated_at=? where id=?", status, time, id);
        db.update("insert into package_logs(package_id,order_id,before_times,change_times,after_times,operator_id,remark,created_at,updated_at,deleted) values(?,?,?,-1,?,?,?,?,?,0)",
                id, nullableLong(body.get("orderId")), total - used, total - used - 1, uid(request), text(body.get("remark")), time, time);
        log(request, "次卡核销", pack.get("name") + "核销1次，剩余" + (total - used - 1));
        return ok("核销成功，剩余" + (total - used - 1) + "次");
    }

    private record PreparedItem(String type, long sourceId, String name, String category,
                                BigDecimal quantity, BigDecimal originalUnitPrice, BigDecimal unitPrice,
                                BigDecimal lineTotal, BigDecimal costPrice, Long employeeId,
                                String employeeName, BigDecimal commission, BigDecimal commissionRate,
                                String priceReason) {
    }

    private record PaymentInput(String method, BigDecimal amount) {
    }

    private record RefundLine(Map<String, Object> item, BigDecimal quantity,
                              BigDecimal amount, boolean restock) {
    }
}
