#!/usr/bin/env python3
"""Compatibility entry point for the current 2.3 business smoke test."""
import runpy
from pathlib import Path

runpy.run_path(str(Path(__file__).with_name("v23-smoke-test.py")), run_name="__main__")
