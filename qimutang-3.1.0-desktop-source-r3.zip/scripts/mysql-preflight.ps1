$ErrorActionPreference = 'Stop'
Write-Host '齐沐堂 2.5.0 MySQL 环境检查' -ForegroundColor Cyan
$mysql = Get-Command mysql.exe -ErrorAction SilentlyContinue
if (-not $mysql) {
  Write-Host '未检测到 mysql.exe。请先安装 MySQL Server 8.x，再重新运行本脚本。' -ForegroundColor Yellow
  exit 2
}
$version = & $mysql.Source --version
Write-Host "检测到: $version"
if ($version -notmatch 'Ver 8\\.') {
  Write-Host '警告：当前不是 MySQL 8.x，正式门店版不建议继续。' -ForegroundColor Yellow
}
$port = Get-NetTCPConnection -LocalPort 3306 -State Listen -ErrorAction SilentlyContinue
if ($port) { Write-Host '3306 端口正在监听。' -ForegroundColor Green } else { Write-Host '3306 未监听，请确认 MySQL 服务已启动。' -ForegroundColor Red; exit 3 }
Write-Host '环境检查通过。' -ForegroundColor Green
