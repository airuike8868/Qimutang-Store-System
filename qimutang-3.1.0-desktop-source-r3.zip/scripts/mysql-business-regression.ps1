[CmdletBinding()]
param([string]$BaseUrl='http://127.0.0.1:18080')
$ErrorActionPreference='Stop'
Write-Host '齐沐堂 2.5.0 MySQL 业务回归检查' -ForegroundColor Cyan
$checks = @(
 'MySQL 8连接与utf8mb4',
 '管理员登录与权限',
 '会员充值及付款方式',
 '服务+护理产品混合开单',
 '微信/支付宝/现金/银行卡/会员余额组合支付',
 '产品库存扣减与库存流水',
 '员工业绩与提成',
 '部分退款资金及提成冲减',
 '全额退款库存回补且不重复回库',
 'SQLite旧数据迁移数量核对',
 'MySQL备份、清空测试库、恢复、再次核对',
 '退出重启后数据一致性'
)
$i=1
foreach($c in $checks){ Write-Host ("[{0:00}] {1}" -f $i,$c); $i++ }
Write-Host ''
Write-Host '本脚本是正式验收清单，不会伪造业务测试结果。需在 Windows 11 + MySQL 8 实机逐项执行并保存结果。' -ForegroundColor Yellow
