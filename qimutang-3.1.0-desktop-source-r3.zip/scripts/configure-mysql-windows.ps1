[CmdletBinding()]
param(
  [string]$MySqlBin = "mysql",
  [string]$HostName = "127.0.0.1",
  [int]$Port = 3306,
  [string]$RootUser = "root",
  [Parameter(Mandatory=$true)][string]$RootPassword,
  [string]$Database = "qimutang",
  [string]$AppUser = "qimutang",
  [Parameter(Mandatory=$true)][string]$AppPassword
)
$ErrorActionPreference='Stop'
$init = Join-Path $PSScriptRoot 'mysql-init-windows.ps1'
& $init -MySqlBin $MySqlBin -HostName $HostName -Port $Port -RootUser $RootUser -RootPassword $RootPassword -Database $Database -AppUser $AppUser -AppPassword $AppPassword
if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw "数据库初始化失败" }
$configRoot = Join-Path $env:USERPROFILE 'QimutangData\config'
New-Item -ItemType Directory -Force -Path $configRoot | Out-Null
$envFile = Join-Path $configRoot 'mysql.env'
$url = "jdbc:mysql://${HostName}:${Port}/${Database}?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&allowPublicKeyRetrieval=true"
@(
 "QIMUTANG_MYSQL_URL=$url",
 "QIMUTANG_MYSQL_USER=$AppUser",
 "QIMUTANG_MYSQL_PASSWORD=$AppPassword"
) | Set-Content -LiteralPath $envFile -Encoding UTF8
Write-Host "[OK] 齐沐堂 MySQL 配置已写入 $envFile" -ForegroundColor Green
Write-Host "注意：该文件包含数据库密码，只允许门店管理员账户访问。" -ForegroundColor Yellow
try {
  $acl = Get-Acl $envFile
  $acl.SetAccessRuleProtection($true,$false)
  foreach($rule in @($acl.Access)){ $acl.RemoveAccessRule($rule) | Out-Null }
  $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
  $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($me,'FullControl','Allow')
  $acl.AddAccessRule($rule)
  Set-Acl -LiteralPath $envFile -AclObject $acl
  Write-Host "[OK] 数据库配置文件权限已限制为当前 Windows 用户。" -ForegroundColor Green
} catch { Write-Warning "无法自动收紧 mysql.env 权限，请确保其他 Windows 用户无法读取该文件。" }
