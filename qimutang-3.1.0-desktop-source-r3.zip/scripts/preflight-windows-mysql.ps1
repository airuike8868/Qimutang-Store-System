[CmdletBinding()]
param(
  [string]$MySqlBin = "mysql"
)
$ErrorActionPreference = 'Stop'
$failed = $false
function Check-Cmd([string]$Name,[string]$Hint) {
  $cmd = Get-Command $Name -ErrorAction SilentlyContinue
  if (-not $cmd) { Write-Host "[FAIL] $Name 未找到。$Hint" -ForegroundColor Red; $script:failed=$true; return $null }
  Write-Host "[OK] $Name -> $($cmd.Source)" -ForegroundColor Green
  return $cmd
}
$java=Check-Cmd 'java' '需要完整 JDK 17。'
$mvn=Check-Cmd 'mvn' '需要 Maven 3.9+。'
$jpackage=Check-Cmd 'jpackage' '请使用包含 jpackage 的完整 JDK 17。'
$mysql=Check-Cmd $MySqlBin '需要 MySQL 8 Client/Server，或用 -MySqlBin 指定 mysql.exe。'
if ($java) { & $java.Source -version }
if ($mvn) { & $mvn.Source -version }
if ($mysql) {
  $ver = (& $mysql.Source --version | Out-String).Trim()
  Write-Host "MySQL: $ver"
  if ($ver -notmatch 'Ver 8\.') { Write-Host '[FAIL] 当前 mysql 客户端不是 MySQL 8.x。' -ForegroundColor Red; $failed=$true }
}
if ($failed) { throw '发布前环境检查未通过。' }
Write-Host '[OK] Windows + MySQL 构建前置环境检查通过。' -ForegroundColor Green
