@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0.."
echo ========================================
echo   齐沐堂 2.5.0 MySQL 首次配置
echo ========================================
where powershell >nul 2>nul || (echo [失败] 未找到 PowerShell。& pause & exit /b 1)
where mysql >nul 2>nul || (echo [失败] 未找到 MySQL 8 客户端，请先安装 MySQL 8。& pause & exit /b 1)
set /p ROOTUSER=MySQL管理员账号 [root]: 
if "%ROOTUSER%"=="" set ROOTUSER=root
set /p DBNAME=数据库名 [qimutang]: 
if "%DBNAME%"=="" set DBNAME=qimutang
set /p APPUSER=程序数据库账号 [qimutang]: 
if "%APPUSER%"=="" set APPUSER=qimutang
for /f "delims=" %%P in ('powershell -NoProfile -Command "$p=Read-Host '请输入MySQL管理员密码' -AsSecureString;$b=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($p);[Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)"') do set "ROOTPASS=%%P"
for /f "delims=" %%P in ('powershell -NoProfile -Command "$p=Read-Host '请设置齐沐堂数据库专用密码' -AsSecureString;$b=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($p);[Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)"') do set "APPPASS=%%P"
if "%ROOTPASS%"=="" (echo [失败] 管理员密码不能为空。& pause & exit /b 2)
if "%APPPASS%"=="" (echo [失败] 程序数据库密码不能为空。& pause & exit /b 3)
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\configure-mysql-windows.ps1" -RootUser "%ROOTUSER%" -RootPassword "%ROOTPASS%" -Database "%DBNAME%" -AppUser "%APPUSER%" -AppPassword "%APPPASS%"
if errorlevel 1 (echo [失败] MySQL配置失败，请查看上方错误。& pause & exit /b 4)
set ROOTPASS=
set APPPASS=
echo.
echo [完成] MySQL配置成功。现在可以双击 start-qimutang.cmd 启动系统。
pause
