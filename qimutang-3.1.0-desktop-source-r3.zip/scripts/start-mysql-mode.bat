@echo off
setlocal
chcp 65001 >nul
set SPRING_PROFILES_ACTIVE=mysql
if "%QIMUTANG_MYSQL_USER%"=="" set QIMUTANG_MYSQL_USER=qimutang
if "%QIMUTANG_MYSQL_URL%"=="" set QIMUTANG_MYSQL_URL=jdbc:mysql://127.0.0.1:3306/qimutang?useUnicode=true^&characterEncoding=utf8^&serverTimezone=Asia/Shanghai^&useSSL=false^&allowPublicKeyRetrieval=true
if "%QIMUTANG_MYSQL_PASSWORD%"=="" (
  echo 请先设置环境变量 QIMUTANG_MYSQL_PASSWORD
  pause
  exit /b 1
)
java -jar app\qimutang.jar --spring.profiles.active=mysql
