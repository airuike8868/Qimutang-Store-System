$ErrorActionPreference = 'Stop'
Write-Host '齐沐堂 2.5.0 MySQL RC2 并发/幂等验收' -ForegroundColor Cyan
$checks = @(
 '同一 clientRequestId 连续提交两次收银，仅一张订单',
 '同一 clientRequestId 并发提交两次收银，仅一张订单',
 '同一退款 clientRequestId 连续提交两次，仅一笔退款',
 '两次并发退款总额超过实收时，至少一笔必须失败',
 '会员余额不足时并发余额支付不得出现负余额',
 '产品并发销售不得出现负库存',
 '退款 restock=true 仅回库一次',
 '失败事务不得留下孤立 payment/order_item/refund_item',
 '重启后订单、支付、库存、余额、退款数据一致',
 '备份后恢复，核心表数量及附件目录一致'
)
$i=1
foreach($c in $checks){ Write-Host ("[{0,2}] [ ] {1}" -f $i,$c); $i++ }
Write-Host "`n说明：此脚本输出人工/自动化验收项，不代表当前机器已通过 Windows+MySQL 真机测试。" -ForegroundColor Yellow
