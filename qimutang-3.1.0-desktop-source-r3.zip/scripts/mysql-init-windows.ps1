param(
  [string]$MySqlBin = "mysql",
  [string]$HostName = "127.0.0.1",
  [int]$Port = 3306,
  [string]$RootUser = "root",
  [string]$RootPassword = "",
  [string]$Database = "qimutang",
  [string]$AppUser = "qimutang",
  [string]$AppPassword = ""
)
$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($RootPassword)) { throw "请通过 -RootPassword 提供 MySQL root 密码" }
if ([string]::IsNullOrWhiteSpace($AppPassword)) { throw "请通过 -AppPassword 提供应用数据库密码" }

$mysql = Get-Command $MySqlBin -ErrorAction SilentlyContinue
if (-not $mysql) { throw "未找到 mysql.exe，请安装 MySQL 8 后重试，或通过 -MySqlBin 指定完整路径" }

$sql = @"
CREATE DATABASE IF NOT EXISTS ``$Database`` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE USER IF NOT EXISTS '$AppUser'@'localhost' IDENTIFIED BY '$AppPassword';
ALTER USER '$AppUser'@'localhost' IDENTIFIED BY '$AppPassword';
GRANT ALL PRIVILEGES ON ``$Database``.* TO '$AppUser'@'localhost';
CREATE USER IF NOT EXISTS '$AppUser'@'127.0.0.1' IDENTIFIED BY '$AppPassword';
ALTER USER '$AppUser'@'127.0.0.1' IDENTIFIED BY '$AppPassword';
GRANT ALL PRIVILEGES ON ``$Database``.* TO '$AppUser'@'127.0.0.1';
FLUSH PRIVILEGES;
"@
$temp = Join-Path $env:TEMP ("qimutang-mysql-init-" + [guid]::NewGuid().ToString("N") + ".sql")
try {
  [IO.File]::WriteAllText($temp, $sql, [Text.UTF8Encoding]::new($false))
  $env:MYSQL_PWD = $RootPassword
  & $mysql.Source -h $HostName -P $Port -u $RootUser --default-character-set=utf8mb4 --execute="source $($temp.Replace('\\','/'))"
  if ($LASTEXITCODE -ne 0) { throw "MySQL 初始化失败，退出码 $LASTEXITCODE" }
  Write-Host "[OK] 数据库 $Database 与账号 $AppUser 初始化完成。" -ForegroundColor Green
} finally {
  Remove-Item Env:MYSQL_PWD -ErrorAction SilentlyContinue
  Remove-Item $temp -Force -ErrorAction SilentlyContinue
}
