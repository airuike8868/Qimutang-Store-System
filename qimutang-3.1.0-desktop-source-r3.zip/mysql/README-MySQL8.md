# 齐沐堂 2.5.0 MySQL 8 模式

## 目标
- 保留现有单店业务功能。
- MySQL 8 作为正式经营数据库。
- 旧版 `%USERPROFILE%\\QimutangData\\data\\qimutang.db` 不自动删除。
- 首次切换后可由管理员执行 SQLite→MySQL 安全合并迁移。

## 建库
```sql
CREATE DATABASE qimutang CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
CREATE USER 'qimutang'@'localhost' IDENTIFIED BY '请换成强密码';
GRANT ALL PRIVILEGES ON qimutang.* TO 'qimutang'@'localhost';
FLUSH PRIVILEGES;
```

## 启动
设置环境变量：
- `SPRING_PROFILES_ACTIVE=mysql`
- `QIMUTANG_MYSQL_URL=jdbc:mysql://127.0.0.1:3306/qimutang?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&allowPublicKeyRetrieval=true`
- `QIMUTANG_MYSQL_USER=qimutang`
- `QIMUTANG_MYSQL_PASSWORD=你的密码`

系统会自动创建/补齐表结构。

## 旧数据迁移
1. 先完整备份旧 `QimutangData` 文件夹。
2. 启动 MySQL 模式并登录管理员。
3. 调用后台管理员接口 `POST /api/system/mysql/migrate-sqlite`。
4. 系统只从固定路径读取旧 `qimutang.db`，不会接受任意文件路径。
5. 迁移采用 `INSERT IGNORE` 安全合并，重复主键/唯一键记录不会覆盖 MySQL 已有记录。
6. 对照顾客数、订单数、充值流水、库存、护理档案、提成等进行核验。

## 备份恢复
MySQL 模式不依赖 SQLite 文件，也不依赖系统 PATH 中的 `mysqldump`：
- 系统内“完整备份”生成 ZIP 逻辑备份。
- 包含 `mysql-data.jsonl`。
- 恢复前系统自动再做一次完整备份。
- MySQL 恢复当前为应用内逻辑恢复，执行后立即生效。

## 重要
正式门店不要把 MySQL 3306 开放到公网。单店本机建议只监听 `127.0.0.1`。
