const API = '/api';
const root = document.getElementById('app');
const pages = {};

const state = {
  user: loadUser(),
  page: '首页',
  cart: [],
  payments: [],
  searchSeed: null,
  checkoutTicket: null,
  branding: { system_name: '齐沐堂门店管理系统', brand_logo: '/qimutang-logo.png' },
  navSummary: {},
  navSummaryAt: 0
};

const menuGroups = [
  { title: '经营', items: ['首页', '服务看板', '收银开单', '订单管理', '预约管理', '交班日结'] },
  { title: '顾客', items: ['顾客档案', '护理档案', '会员管理', '会员卡', '回访提醒', '经营提醒'] },
  { title: '门店', items: ['项目中心', '护理产品', '员工管理', '排钟工位', '采购管理'] },
  { title: '财务', items: ['收支管理', '工资提成', '营业报表'] },
  { title: '风控', items: ['审批中心', '异常中心'] },
  { title: '系统', items: ['系统设置'] }
];

const iconPaths = {
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v10h13V10"/><path d="M9 20v-6h6v6"/>',
  board: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3Z"/><path d="M9 8h6M9 12h6"/>',
  order: '<path d="M7 3h10v4H7z"/><path d="M5 5H4v16h16V5h-1"/><path d="m8 14 2.2 2.2L16 10.5"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/><path d="M8 14h3v3H8z"/>',
  shift: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2M8 3l1.5 2M16 3l-1.5 2"/>',
  customer: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  care: '<path d="M12 21s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.6-7 10-7 10Z"/><path d="M9 13h6M12 10v6"/>',
  card: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
  project: '<path d="M4 7h16M4 12h16M4 17h16"/><circle cx="8" cy="7" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="10" cy="17" r="2"/>',
  product: '<path d="M4 8 12 3l8 5-8 5-8-5Z"/><path d="m4 8 8 5 8-5v8l-8 5-8-5V8Z"/>',
  employee: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0M16 5a3 3 0 0 1 0 6M17 14a5 5 0 0 1 4 5"/>',
  station: '<path d="M4 18h16M6 18V9h12v9M9 9V5h6v4"/><path d="M9 13h6"/>',
  purchase: '<path d="M3 4h2l2.2 10.2a2 2 0 0 0 2 1.6h7.9a2 2 0 0 0 2-1.6L20 8H7"/><circle cx="10" cy="20" r="1"/><circle cx="17" cy="20" r="1"/>',
  finance: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5c-.8-.7-1.9-1-3.3-1-1.8 0-3.2.8-3.2 2.2 0 3.4 6.5 1.6 6.5 5 0 1.4-1.4 2.3-3.4 2.3-1.4 0-2.8-.4-3.7-1.2M12 5v14"/>',
  report: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  approval: '<path d="M12 3 5 6v5c0 4.7 2.8 8.1 7 10 4.2-1.9 7-5.3 7-10V6l-7-3Z"/><path d="m9 12 2 2 4-4"/>',
  risk: '<path d="M12 3 2.8 20h18.4L12 3Z"/><path d="M12 9v5M12 17.5v.1"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  logout: '<path d="M10 4H5v16h5M14 8l4 4-4 4M18 12H9"/>'
};

const navIconKeys = {
  首页: 'home', 服务看板: 'board', 收银开单: 'receipt', 订单管理: 'order', 预约管理: 'calendar', 交班日结: 'shift',
  顾客档案: 'customer', 护理档案: 'care', 会员管理: 'customer', 会员卡: 'card', 回访提醒: 'bell', 经营提醒: 'bell',
  项目中心: 'project', 护理产品: 'product', 员工管理: 'employee', 排钟工位: 'station', 采购管理: 'purchase',
  收支管理: 'finance', 工资提成: 'finance', 营业报表: 'report', 审批中心: 'approval', 异常中心: 'risk', 系统设置: 'settings'
};

function uiIcon(name, className = '') {
  return `<svg class="ui-icon ${esc(className)}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || iconPaths.board}</svg>`;
}

const UI_STORAGE_KEYS = {
  navGroups: 'qmt_ui_nav_groups',
  compactSidebar: 'qmt_ui_sidebar_compact',
  panelFolds: 'qmt_ui_panel_folds',
  settingsTab: 'qmt_ui_settings_tab',
  ruleFolds: 'qmt_ui_rule_folds'
};

function readUiState(key, fallback = {}) {
  try { return JSON.parse(localStorage.getItem(scopedUiStorageKey(key)) || '') ?? fallback; }
  catch (_) { return fallback; }
}

function writeUiState(key, value) {
  try { localStorage.setItem(scopedUiStorageKey(key), JSON.stringify(value)); }
  catch (_) { /* 浏览器禁用本地存储时仍可正常操作 */ }
}

function scopedUiStorageKey(key) {
  const identity = state.user?.id || state.user?.username || state.user?.name || 'guest';
  return `${key}:${identity}`;
}

const NAV_SUMMARY_KEYS = {
  服务看板: 'activeTickets', 预约管理: 'appointments', 经营提醒: 'reminders',
  护理产品: 'lowStock', 审批中心: 'approvals', 异常中心: 'risks'
};

function applyNavigationSummary(summary = {}) {
  Object.entries(NAV_SUMMARY_KEYS).forEach(([page, key]) => {
    const badge = document.querySelector(`[data-nav-badge="${page}"]`);
    if (!badge) return;
    const count = Math.max(0, Number(summary[key] || 0));
    badge.textContent = count > 99 ? '99+' : String(count);
    badge.hidden = count < 1;
    badge.title = count ? `${page}有${count}项需要关注` : '';
  });
}

async function refreshNavigationSummary(force = false) {
  applyNavigationSummary(state.navSummary);
  if (!force && Date.now() - Number(state.navSummaryAt || 0) < 30000) return;
  try {
    state.navSummary = await api('/v33/ui-summary');
    state.navSummaryAt = Date.now();
    applyNavigationSummary(state.navSummary);
  } catch (_) { /* 旧数据库升级过程中不阻断正常页面 */ }
}

function currentMenuGroup() {
  return menuGroups.find(group => group.items.includes(state.page))?.title || '经营';
}

function menuGroupOpen(title) {
  const saved = readUiState(UI_STORAGE_KEYS.navGroups);
  if (title === currentMenuGroup()) return true;
  if (Object.prototype.hasOwnProperty.call(saved, title)) return Boolean(saved[title]);
  return false;
}

function makePanelCollapsible(panel, stateKey, defaultCollapsed = true) {
  if (!panel || panel.dataset.foldReady === 'true') return;
  const head = panel.querySelector(':scope > .panel-head');
  if (!head) return;
  const body = document.createElement('div');
  body.className = 'panel-fold-body';
  [...panel.children].filter(node => node !== head).forEach(node => body.appendChild(node));
  panel.appendChild(body);

  const saved = readUiState(UI_STORAGE_KEYS.panelFolds);
  const collapsed = Object.prototype.hasOwnProperty.call(saved, stateKey) ? Boolean(saved[stateKey]) : defaultCollapsed;
  const toggle = document.createElement('button');
  toggle.type = 'button';
  toggle.className = 'panel-fold-button ghost';
  toggle.setAttribute('aria-label', '展开或收起本区域');
  toggle.innerHTML = '<span>收起</span><i>⌃</i>';
  head.appendChild(toggle);

  const apply = value => {
    panel.classList.toggle('is-folded', value);
    toggle.setAttribute('aria-expanded', String(!value));
    toggle.querySelector('span').textContent = value ? '展开' : '收起';
    toggle.querySelector('i').textContent = value ? '⌄' : '⌃';
  };
  apply(collapsed);
  toggle.addEventListener('click', event => {
    event.stopPropagation();
    const next = !panel.classList.contains('is-folded');
    apply(next);
    const latest = readUiState(UI_STORAGE_KEYS.panelFolds);
    latest[stateKey] = next;
    writeUiState(UI_STORAGE_KEYS.panelFolds, latest);
  });
  head.addEventListener('dblclick', event => {
    if (event.target.closest('button, input, select, a')) return;
    toggle.click();
  });
}

const roleMenus = {
  管理员: menuGroups.flatMap(group => group.items),
  店长: menuGroups.flatMap(group => group.items),
  前台: ['首页', '服务看板', '收银开单', '订单管理', '预约管理', '交班日结', '顾客档案', '护理档案',
    '会员管理', '会员卡', '回访提醒', '经营提醒', '排钟工位', '审批中心'],
  技师: ['首页', '服务看板', '预约管理', '顾客档案', '护理档案', '回访提醒', '经营提醒', '排钟工位']
};

function loadUser() {
  try {
    return JSON.parse(localStorage.getItem('qmt_user') || 'null');
  } catch (_) {
    localStorage.removeItem('qmt_user');
    return null;
  }
}

function $(id) {
  return document.getElementById(id);
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
}

function money(value) {
  return `¥${Number(value || 0).toFixed(2)}`;
}

function shortDate(value) {
  if (!value) return '-';
  return String(value).replace('T', ' ').slice(0, 16);
}

function today() {
  const date = new Date();
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function monthStart() {
  return `${today().slice(0, 7)}-01`;
}

function input(id, placeholder, type = 'text', value = '', extra = '') {
  return `<input id="${esc(id)}" type="${esc(type)}" placeholder="${esc(placeholder)}" value="${esc(value)}" ${extra}>`;
}

function select(id, rows, label = 'name', selected = '', firstOption = '') {
  const first = firstOption ? `<option value="">${esc(firstOption)}</option>` : '';
  return `<select id="${esc(id)}">${first}${rows.map(row => {
    const value = typeof row === 'object' ? row.id : row;
    const text = typeof row === 'object' ? row[label] : row;
    return `<option value="${esc(value)}" ${String(value) === String(selected) ? 'selected' : ''}>${esc(text)}</option>`;
  }).join('')}</select>`;
}

function field(label, control, hint = '') {
  return `<label class="field"><span>${esc(label)}</span>${control}${hint ? `<small>${esc(hint)}</small>` : ''}</label>`;
}

function empty(text) {
  return `<div class="empty"><b>暂无数据</b><span>${esc(text)}</span></div>`;
}

function statusTag(value) {
  const text = String(value ?? '-');
  const danger = /取消|退款|停用|爽约|报损|未付款/.test(text);
  const success = /正常|完成|启用|在职|已入库|已支付/.test(text);
  return `<span class="tag ${danger ? 'red' : success ? 'green' : ''}">${esc(text)}</span>`;
}

async function api(path, options = {}) {
  const headers = {
    ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
    ...(options.headers || {})
  };
  if (state.user?.token) headers.Authorization = `Bearer ${state.user.token}`;

  let response;
  try {
    response = await fetch(API + path, { ...options, headers });
  } catch (_) {
    throw new Error('系统服务未启动，请关闭后重新打开齐沐堂系统');
  }

  let payload;
  try {
    payload = await response.json();
  } catch (_) {
    throw new Error(`系统返回异常（HTTP ${response.status}）`);
  }

  if (response.status === 401) {
    localStorage.removeItem('qmt_user');
    state.user = null;
    showLogin();
    throw new Error('登录已失效，请重新登录');
  }
  if (!payload.success) throw new Error(payload.message || '操作失败');
  return payload.data;
}

function toast(text, bad = false) {
  const node = document.createElement('div');
  node.className = `toast ${bad ? 'error' : ''}`;
  node.textContent = text;
  document.body.appendChild(node);
  setTimeout(() => node.remove(), 3000);
  if (!bad && state.user) {
    state.navSummaryAt = 0;
    setTimeout(() => refreshNavigationSummary(true), 250);
  }
}

function showError(error) {
  toast(error?.message || String(error), true);
}

async function queryCustomers(keyword = '', pageSize = 100) {
  const data = await api(`/customers/page?q=${encodeURIComponent(keyword)}&page=1&pageSize=${Math.max(10, Math.min(100, pageSize))}`);
  return data.rows || [];
}

function customerOptionHtml(rows, blankLabel = '请选择顾客') {
  return `<option value="">${esc(rows.length ? blankLabel : '没有匹配顾客')}</option>` + rows.map(row =>
    `<option value="${row.id}">${esc(row.name)}${row.phone ? ` · ${esc(row.phone)}` : ''}</option>`).join('');
}

function bindCustomerLookup(inputId, buttonId, selectId, options = {}) {
  const search = async () => {
    const rows = await queryCustomers($(inputId).value.trim(), options.pageSize || 100);
    $(selectId).innerHTML = customerOptionHtml(rows, options.blankLabel || '请选择顾客');
    if (typeof options.onResults === 'function') options.onResults(rows);
    $(selectId).dispatchEvent(new Event('change'));
  };
  $(buttonId)?.addEventListener('click', () => search().catch(showError));
  $(inputId)?.addEventListener('keydown', event => {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    search().catch(showError);
  });
  return search;
}

function openGlobalSearch(initialValue = '') {
  if (!state.user) return;
  document.querySelector('.global-search-mask')?.remove();
  const mask = document.createElement('div');
  mask.className = 'modal-mask global-search-mask';
  mask.innerHTML = `<section class="global-search-panel">
    <header><div><b>全局搜索</b><span>顾客姓名、手机号、会员号或订单号</span></div><button type="button" class="icon-button search-close" aria-label="关闭">×</button></header>
    <div class="global-search-box"><span>⌕</span><input id="global-search-input" value="${esc(initialValue)}" placeholder="输入至少2个字符，按 Enter 搜索"><small>Enter</small></div>
    <div id="global-search-results" class="global-search-results"><div class="search-welcome"><b>快速找到经营资料</b><span>按 F3 可随时打开全局搜索</span></div></div>
  </section>`;
  document.body.appendChild(mask);
  const inputNode = $('global-search-input');
  const resultsNode = $('global-search-results');
  const close = () => mask.remove();
  const go = (page, value) => {
    state.searchSeed = { page, value };
    state.page = page;
    close();
    render();
  };
  const run = async () => {
    const keyword = inputNode.value.trim();
    if (keyword.length < 2) {
      resultsNode.innerHTML = '<div class="search-welcome"><b>请输入至少2个字符</b><span>例如顾客姓名、手机号后4位或订单号</span></div>';
      return;
    }
    resultsNode.innerHTML = '<div class="loading"><span></span>正在搜索…</div>';
    try {
      const data = await api(`/search?q=${encodeURIComponent(keyword)}`);
      const customers = data.customers || [];
      const orders = (roleMenus[state.user.role] || []).includes('订单管理') ? (data.orders || []) : [];
      resultsNode.innerHTML = `${customers.length ? `<div class="search-section"><h4>顾客 <small>${customers.length}</small></h4>${customers.map(row => `
        <button type="button" class="search-result" data-search-customer="${esc(row.phone || row.name)}"><span class="search-avatar">${esc((row.name || '客').slice(0, 1))}</span><span><b>${esc(row.name)}</b><small>${esc(row.phone)} · ${esc(row.member_no || '普通顾客')}</small></span><strong>${money(Number(row.balance_principal) + Number(row.balance_gift))}</strong></button>`).join('')}</div>` : ''}
        ${orders.length ? `<div class="search-section"><h4>订单 <small>${orders.length}</small></h4>${orders.map(row => `
        <button type="button" class="search-result" data-search-order="${esc(row.order_no)}"><span class="search-order-mark">订</span><span><b>${esc(row.order_no)}</b><small>${esc(row.customer_name || '散客')} · ${esc(shortDate(row.created_at))}</small></span><strong>${money(row.received)}</strong></button>`).join('')}</div>` : ''}
        ${!customers.length && !orders.length ? '<div class="search-welcome"><b>没有找到匹配资料</b><span>请检查姓名、手机号或订单号</span></div>' : ''}`;
      resultsNode.querySelectorAll('[data-search-customer]').forEach(button => button.addEventListener('click', () => go('顾客档案', button.dataset.searchCustomer)));
      resultsNode.querySelectorAll('[data-search-order]').forEach(button => button.addEventListener('click', () => go('订单管理', button.dataset.searchOrder)));
    } catch (error) {
      resultsNode.innerHTML = `<div class="search-welcome error-panel"><b>搜索失败</b><span>${esc(error.message)}</span></div>`;
    }
  };
  mask.querySelector('.search-close').addEventListener('click', close);
  mask.addEventListener('click', event => { if (event.target === mask) close(); });
  inputNode.addEventListener('keydown', event => {
    if (event.key === 'Enter') run();
    if (event.key === 'Escape') close();
  });
  inputNode.focus();
  if (initialValue.trim().length >= 2) run();
}

function modal(title, body, onSave, options = {}) {
  const mask = document.createElement('div');
  mask.className = 'modal-mask';
  const cancel = options.closable === false ? '' : '<button type="button" class="ghost modal-cancel">取消</button>';
  const close = options.closable === false ? '' : '<button type="button" class="icon-button modal-close" aria-label="关闭">×</button>';
  mask.innerHTML = `<div class="modal ${options.wide ? 'modal-wide' : ''}">
    <div class="modal-head"><h3>${esc(title)}</h3>${close}</div>
    <div class="modal-body">${body}</div>
    <div class="modal-foot">${cancel}<button type="button" class="modal-save">${esc(options.saveText || '保存')}</button></div>
  </div>`;
  document.body.appendChild(mask);
  const closeModal = () => mask.remove();
  mask.querySelector('.modal-close')?.addEventListener('click', closeModal);
  mask.querySelector('.modal-cancel')?.addEventListener('click', closeModal);
  mask.querySelector('.modal-save').addEventListener('click', async event => {
    const button = event.currentTarget;
    button.disabled = true;
    button.textContent = '正在保存…';
    try {
      await onSave(mask);
      if (options.autoClose !== false) closeModal();
    } catch (error) {
      showError(error);
    } finally {
      if (document.body.contains(button)) {
        button.disabled = false;
        button.textContent = options.saveText || '保存';
      }
    }
  });
  return mask;
}

function confirmAction(message) {
  return window.confirm(message);
}

function downloadCsv(filename, columns, rows) {
  const quote = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
  const text = '\ufeff' + [columns.map(column => quote(column.label)).join(','),
    ...rows.map(row => columns.map(column => quote(
      typeof column.value === 'function' ? column.value(row) : row[column.value]
    )).join(','))].join('\r\n');
  const url = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

function showLogin() {
  const brandName = state.branding.system_name || '齐沐堂门店管理系统';
  const brandLogo = state.branding.brand_logo || '/qimutang-logo.png';
  document.title = brandName;
  root.innerHTML = `<div class="login-screen">
    <section class="login-intro">
      <div class="login-edition"><i></i> 安全 · 稳定 · 高效</div>
      <img class="login-logo" src="${esc(brandLogo)}" alt="${esc(brandName)}标志" onerror="this.src='/qimutang-logo.png'">
      <h1>${esc(brandName)}</h1>
      <p>门店经营、顾客护理、会员库存和财务数据，一套系统统一管理。</p>
      <ul><li>门店数据自主存储</li><li>每日自动备份</li><li>账号权限与操作留痕</li></ul>
    </section>
    <section class="login-card">
      <div class="mobile-brand"><img src="${esc(brandLogo)}" alt="${esc(brandName)}标志" onerror="this.src='/qimutang-logo.png'"><b>${esc(brandName)}</b></div>
      <div class="login-heading"><span>WELCOME BACK</span><h2>登录门店系统</h2><p>请输入账号和密码继续工作</p></div>
      ${field('登录账号', input('login-username', '请输入账号', 'text', 'admin', 'autocomplete="username"'))}
      ${field('登录密码', input('login-password', '请输入密码', 'password', '', 'autocomplete="current-password"'))}
      <button id="login-button" class="wide">登录</button>
      <small class="login-tip">首次运行账号：admin　密码：123456</small>
    </section>
  </div>`;

  const submit = async () => {
    const button = $('login-button');
    button.disabled = true;
    button.textContent = '正在登录…';
    try {
      const username = $('login-username').value.trim();
      const password = $('login-password').value;
      state.user = await api('/auth/login', {
        method: 'POST', body: JSON.stringify({ username, password })
      });
      if (state.user.firstLogin) await forcePasswordChange(password);
      localStorage.setItem('qmt_user', JSON.stringify(state.user));
      state.page = '首页';
      await render();
    } catch (error) {
      showError(error);
      state.user = null;
    } finally {
      if ($('login-button')) {
        button.disabled = false;
        button.textContent = '登录';
      }
    }
  };

  $('login-button').addEventListener('click', submit);
  $('login-password').addEventListener('keydown', event => {
    if (event.key === 'Enter') submit();
  });
}

function forcePasswordChange(oldPassword) {
  return new Promise(resolve => {
    const gate = modal('首次登录，请先修改密码', `
      <div class="notice">为了保护门店营业数据，初始密码不能继续使用。</div>
      ${field('新密码', input('first-password', '至少8位，含字母和数字', 'password'))}
      ${field('再次输入', input('first-password-confirm', '再次输入新密码', 'password'))}
    `, async () => {
      const password = $('first-password').value;
      if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) throw new Error('新密码至少8位，并同时包含字母和数字');
      if (password !== $('first-password-confirm').value) throw new Error('两次输入的密码不一致');
      if (password === oldPassword) throw new Error('新密码不能和初始密码相同');
      await api('/auth/change-password', {
        method: 'POST', body: JSON.stringify({ oldPassword, newPassword: password })
      });
      state.user.firstLogin = false;
      toast('密码修改成功');
      resolve();
    }, { closable: false, saveText: '修改密码并进入系统' });
    gate.querySelector('#first-password')?.focus();
  });
}

function renderShell() {
  const allowed = roleMenus[state.user.role] || [];
  const brandName = state.branding.system_name || '齐沐堂门店管理系统';
  const brandLogo = state.branding.brand_logo || '/qimutang-logo.png';
  const compactSidebar = readUiState(UI_STORAGE_KEYS.compactSidebar, false) === true;
  document.body.classList.toggle('side-compact', compactSidebar);
  document.title = `${state.page} - ${brandName}`;
  root.innerHTML = `<aside class="side">
    <div class="brand"><img src="${esc(brandLogo)}" alt="${esc(brandName)}标志" onerror="this.src='/qimutang-logo.png'"><div><b>${esc(brandName)}</b><small>门店经营管理系统</small></div><button type="button" id="side-collapse" class="side-collapse" aria-label="${compactSidebar ? '展开侧栏' : '收起侧栏'}" title="${compactSidebar ? '展开侧栏' : '收起侧栏'}">${compactSidebar ? '›' : '‹'}</button></div>
    ${allowed.includes('收银开单') ? `<button type="button" class="side-order" id="side-quick-order"><span>${uiIcon('plus')}</span><b>快速开单</b><small>F2</small></button>` : ''}
    <nav>${menuGroups.map(group => {
      const items = group.items.filter(name => allowed.includes(name));
      if (!items.length) return '';
      const open = menuGroupOpen(group.title);
      return `<div class="nav-group ${open ? 'is-open' : 'is-folded'}" data-nav-group="${esc(group.title)}">
        <button type="button" class="nav-group-toggle" aria-expanded="${open}" title="${esc(group.title)}">
          <span class="nav-group-initial">${esc(group.title.slice(0, 1))}</span><span class="nav-group-title">${esc(group.title)}</span><i>${open ? '⌃' : '⌄'}</i>
        </button>
        <div class="nav-group-items">${items.map(name =>
          `<button type="button" class="nav ${state.page === name ? 'active' : ''}" data-page="${esc(name)}" title="${esc(name)}"><span class="nav-mark">${uiIcon(navIconKeys[name])}</span><span class="nav-label">${esc(name)}</span><span class="nav-badge" data-nav-badge="${esc(name)}" hidden></span></button>`
        ).join('')}</div></div>`;
    }).join('')}</nav>
    <div class="side-foot"><span class="status-dot"></span><b>数据服务运行正常</b><small>版本 3.3.3 · MySQL</small></div>
  </aside>
  <main class="main">
    <header class="topbar">
      <div class="top-title"><button id="menu-toggle" class="icon-button menu-toggle">☰</button><div><span class="page-eyebrow">门店经营 / ${esc(state.page)}</span><h2>${esc(state.page)}</h2><p>${new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' })}</p></div></div>
      <div class="account"><button type="button" id="top-global-search" class="global-search-trigger"><span>${uiIcon('search')}</span><b>搜索顾客、订单</b><small>F3</small></button>${allowed.includes('收银开单') && state.page !== '收银开单' ? `<button id="top-quick-order" class="top-order">${uiIcon('plus')} 开单</button>` : ''}<div class="account-profile"><span class="account-avatar">${esc((state.user.name || state.user.username || '用').slice(0, 1))}</span><span><b>${esc(state.user.name)}</b><small>${esc(state.user.role)}</small></span></div><button id="logout-button" class="ghost logout-button" title="退出登录">${uiIcon('logout')}<span>退出</span></button></div>
    </header>
    <section id="content"><div class="loading"><span></span>正在加载…</div></section>
  </main>`;

  document.querySelectorAll('[data-page]').forEach(button => {
    button.addEventListener('click', async () => {
      state.page = button.dataset.page;
      document.body.classList.remove('menu-open');
      await render();
    });
  });
  $('logout-button').addEventListener('click', () => {
    localStorage.removeItem('qmt_user');
    state.user = null;
    showLogin();
  });
  $('menu-toggle').addEventListener('click', () => document.body.classList.toggle('menu-open'));
  $('side-collapse')?.addEventListener('click', () => {
    const next = !document.body.classList.contains('side-compact');
    writeUiState(UI_STORAGE_KEYS.compactSidebar, next);
    document.body.classList.toggle('side-compact', next);
    const control = $('side-collapse');
    control.textContent = next ? '›' : '‹';
    control.title = next ? '展开侧栏' : '收起侧栏';
    control.setAttribute('aria-label', control.title);
  });
  document.querySelectorAll('[data-nav-group]').forEach(group => {
    const toggle = group.querySelector('.nav-group-toggle');
    toggle.addEventListener('click', () => {
      const open = !group.classList.contains('is-open');
      group.classList.toggle('is-open', open);
      group.classList.toggle('is-folded', !open);
      toggle.setAttribute('aria-expanded', String(open));
      toggle.querySelector('i').textContent = open ? '⌃' : '⌄';
      const saved = readUiState(UI_STORAGE_KEYS.navGroups);
      saved[group.dataset.navGroup] = open;
      writeUiState(UI_STORAGE_KEYS.navGroups, saved);
    });
  });
  $('top-global-search')?.addEventListener('click', () => openGlobalSearch());
  const goOrder = async () => { state.page = '收银开单'; document.body.classList.remove('menu-open'); await render(); };
  $('side-quick-order')?.addEventListener('click', goOrder);
  $('top-quick-order')?.addEventListener('click', goOrder);
  refreshNavigationSummary();
}

async function render() {
  if (!state.user) return showLogin();
  const allowed = roleMenus[state.user.role] || [];
  if (!allowed.includes(state.page)) state.page = '首页';
  renderShell();
  try {
    const page = pages[state.page] || pages['首页'];
    await page();
  } catch (error) {
    const content = $('content');
    if (content) content.innerHTML = `<div class="panel error-panel"><h3>页面加载失败</h3><p>${esc(error.message)}</p><button onclick="render()">重新加载</button></div>`;
  }
}

async function bootstrap() {
  document.addEventListener('keydown', event => {
    if (state.user && (event.key === 'F3' || (event.ctrlKey && event.key.toLowerCase() === 'k'))) {
      event.preventDefault(); openGlobalSearch(); return;
    }
    if (event.key === 'F2' && state.user && (roleMenus[state.user.role] || []).includes('收银开单')) {
      event.preventDefault(); state.page = '收银开单'; render();
    }
  });
  try { state.branding = {...state.branding, ...(await api('/public/branding'))}; } catch (_) { /* 使用默认品牌 */ }
  state.user ? render() : showLogin();
}
