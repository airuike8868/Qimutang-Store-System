async function dashboardPage() {
  const [base, extendedResult] = await Promise.all([
    api('/dashboard'),
    api('/dashboard/extended')
      .then(data => ({ data }))
      .catch(error => ({ error }))
  ]);
  const extended = extendedResult.data || {
    monthSales: 0, monthExpenses: 0, memberBalance: 0,
    lowStock: 0, followupsDue: 0, careDue: 0
  };
  const content = $('content');
  content.innerHTML = `
    ${extendedResult.error ? `<div class="notice compact"><b>部分经营统计暂未加载</b><span>${esc(extendedResult.error.message)}，其他功能仍可正常使用。</span></div>` : ''}
    <section class="dashboard-hero">
      <div><span class="dashboard-kicker">TODAY OVERVIEW</span><h3>${new Date().getHours() < 12 ? '早上好' : new Date().getHours() < 18 ? '下午好' : '晚上好'}，${esc(state.user.name)}</h3><p>今天的门店经营情况已为你汇总，重要事项请及时处理。</p></div>
      <div class="dashboard-hero-actions"><button class="ghost" data-go="营业报表">${uiIcon('report')} 查看报表</button><button data-go="收银开单">${uiIcon('plus')} 快速开单</button></div>
    </section>
    <div class="metric-grid six">
      <div class="metric primary"><i>${uiIcon('finance')}</i><span>今日营业额</span><b>${money(base.todaySales)}</b><small>按实收减退款</small></div>
      <div class="metric"><i>${uiIcon('receipt')}</i><span>今日订单</span><b>${base.todayOrders || 0}</b><small>已完成开单</small></div>
      <div class="metric"><i>${uiIcon('customer')}</i><span>今日到店</span><b>${base.todayCustomers || 0}</b><small>登记顾客</small></div>
      <div class="metric"><i>${uiIcon('report')}</i><span>本月营业额</span><b>${money(extended.monthSales)}</b><small>本月累计净收入</small></div>
      <div class="metric"><i>${uiIcon('card')}</i><span>会员余额</span><b>${money(extended.memberBalance)}</b><small>本金与赠送金合计</small></div>
      <div class="metric"><i>${uiIcon('purchase')}</i><span>本月支出</span><b>${money(extended.monthExpenses)}</b><small>已登记经营支出</small></div>
    </div>
    <div class="attention-grid">
      <button class="attention-stock" data-go="护理产品"><i>${uiIcon('product')}</i><span><b>${extended.lowStock || 0}</b><small>项低库存商品</small></span><em>立即处理 →</em></button>
      <button class="attention-follow" data-go="回访提醒"><i>${uiIcon('bell')}</i><span><b>${extended.followupsDue || 0}</b><small>项回访已到期</small></span><em>查看任务 →</em></button>
      <button class="attention-care" data-go="护理档案"><i>${uiIcon('care')}</i><span><b>${extended.careDue || 0}</b><small>项护理需关注</small></span><em>进入档案 →</em></button>
    </div>
    <div class="grid2">
      <div class="panel">
        <div class="panel-head"><div><h3>今日预约</h3><p>及时更新到店和完成状态</p></div><button data-go="预约管理" class="ghost">查看全部</button></div>
        ${base.appointments?.length ? `<div class="table-wrap"><table><thead><tr><th>时间</th><th>顾客</th><th>状态</th></tr></thead><tbody>${base.appointments.map(row => `
          <tr><td>${esc(shortDate(row.start_at).slice(11))}</td><td>${esc(row.customer || '散客')}</td><td>${statusTag(row.status)}</td></tr>
        `).join('')}</tbody></table></div>` : empty('今日暂无预约')}
      </div>
      <div class="panel">
        <div class="panel-head"><div><h3>快捷操作</h3><p>门店高频操作</p></div></div>
        <div class="quick-grid">
          ${[
            ['收银开单', 'receipt'], ['新增顾客', 'customer'], ['会员充值', 'card'],
            ['新增预约', 'calendar'], ['护理档案', 'care'], ['登记支出', 'finance']
          ].map(([name, icon]) => `<button data-quick="${name}"><i>${uiIcon(icon)}</i><span>${name}</span></button>`).join('')}
        </div>
        <div class="notice compact"><b>经营提示</b><span>每天打烊前核对订单、收款和支出，系统数据才有参考价值。</span></div>
      </div>
    </div>`;

  content.querySelectorAll('[data-go]').forEach(button => button.addEventListener('click', () => {
    state.page = button.dataset.go;
    render();
  }));
  content.querySelectorAll('[data-quick]').forEach(button => button.addEventListener('click', () => {
    const mapping = {
      收银开单: '收银开单', 新增顾客: '顾客档案', 会员充值: '会员管理',
      新增预约: '预约管理', 护理档案: '护理档案', 登记支出: '收支管理'
    };
    state.page = mapping[button.dataset.quick];
    render();
  }));
}

async function checkoutPage() {
  const [customers, services, employees] = await Promise.all([
    api('/customers'), api('/services'), api('/employees').catch(() => [])
  ]);
  const content = $('content');
  const activeServices = services.filter(service => Number(service.status) === 1);
  content.innerHTML = `
    <div class="checkout-layout">
      <div class="panel">
        <div class="panel-head"><div><h3>选择服务项目</h3><p>点击项目加入本次结账</p></div></div>
        <div class="service-grid">${activeServices.map(service => `
          <button class="service-card" data-service="${service.id}">
            <small>${esc(service.category)}</small><b>${esc(service.name)}</b>
            <span>${service.duration || 0} 分钟</span><strong>${money(service.list_price)}</strong>
          </button>`).join('')}</div>
      </div>
      <div class="panel checkout-box">
        <div class="panel-head"><div><h3>本次结账</h3><p>支持微信、现金和会员余额组合支付</p></div></div>
        ${field('顾客', select('order-customer', customers, 'name', '', '散客（不留档）'))}
        <div id="member-balance" class="member-hint"></div>
        <div id="cart-box"></div>
        ${field('服务技师', select('order-technician', employees, 'name', '', '暂不指定'))}
        <div class="pay-builder">
          ${select('payment-method', ['微信', '支付宝', '现金', '银行卡', '美团', '抖音', '会员余额'])}
          ${input('payment-amount', '支付金额', 'number', '', 'min="0" step="0.01"')}
          <button id="add-payment" type="button">加入支付</button>
        </div>
        <div id="payment-box"></div>
        ${field('订单备注', '<textarea id="order-remark" placeholder="可填写顾客要求、团购券号等"></textarea>')}
        <button id="submit-order" class="wide">确认收款并完成开单</button>
      </div>
    </div>`;

  const total = () => state.cart.reduce((sum, item) => sum + Number(item.price), 0);
  const paid = () => state.payments.reduce((sum, item) => sum + Number(item.amount), 0);
  const canChangePrice = ['管理员', '店长'].includes(state.user.role);

  const draw = () => {
    const cartBox = $('cart-box');
    cartBox.innerHTML = state.cart.length ? `
      <div class="cart-list">${state.cart.map((item, index) => `
        <div class="cart-item"><div><b>${esc(item.name)}</b><small>${item.duration || 0}分钟</small></div>
          ${canChangePrice ? `<input class="price-input" data-price-index="${index}" type="number" min="0" step="0.01" value="${Number(item.price).toFixed(2)}">` : `<strong>${money(item.price)}</strong>`}
          <button class="link danger" data-remove-item="${index}">删除</button></div>`).join('')}</div>
      <div class="cart-total"><span>项目合计</span><b>${money(total())}</b></div>` : empty('请先选择服务项目');

    const paymentBox = $('payment-box');
    paymentBox.innerHTML = state.payments.length ? `
      <div class="payment-list">${state.payments.map((item, index) => `
        <div class="cart-item"><span>${esc(item.method)}</span><strong>${money(item.amount)}</strong><button class="link danger" data-remove-payment="${index}">删除</button></div>`).join('')}</div>
      <div class="payment-total"><span>已付 ${money(paid())}</span><b>待付 ${money(Math.max(0, total() - paid()))}</b></div>` : '<p class="form-tip">可分多次加入不同付款方式。</p>';
    $('payment-amount').value = Math.max(0, total() - paid()).toFixed(2);

    cartBox.querySelectorAll('[data-remove-item]').forEach(button => button.addEventListener('click', () => {
      state.cart.splice(Number(button.dataset.removeItem), 1);
      if (paid() > total()) state.payments = [];
      draw();
    }));
    cartBox.querySelectorAll('[data-price-index]').forEach(control => control.addEventListener('change', () => {
      const value = Number(control.value);
      if (value < 0 || !Number.isFinite(value)) return showError(new Error('项目金额不正确'));
      state.cart[Number(control.dataset.priceIndex)].price = value;
      state.payments = [];
      draw();
    }));
    paymentBox.querySelectorAll('[data-remove-payment]').forEach(button => button.addEventListener('click', () => {
      state.payments.splice(Number(button.dataset.removePayment), 1);
      draw();
    }));
  };

  content.querySelectorAll('[data-service]').forEach(button => button.addEventListener('click', () => {
    const service = activeServices.find(item => String(item.id) === button.dataset.service);
    state.cart.push({
      serviceId: service.id, name: service.name, duration: service.duration,
      price: Number(service.list_price), commissionType: service.commission_type,
      commissionValue: Number(service.commission_value || 0)
    });
    draw();
  }));

  $('order-customer').addEventListener('change', () => {
    const customer = customers.find(item => String(item.id) === $('order-customer').value);
    $('member-balance').innerHTML = customer
      ? `会员余额：<b>${money(Number(customer.balance_principal) + Number(customer.balance_gift))}</b>（本金 ${money(customer.balance_principal)} / 赠送 ${money(customer.balance_gift)}）`
      : '当前按散客开单，不累计会员档案。';
  });
  $('order-customer').dispatchEvent(new Event('change'));

  $('add-payment').addEventListener('click', () => {
    const amount = Number($('payment-amount').value);
    if (!(amount > 0)) return showError(new Error('请输入支付金额'));
    if (paid() + amount > total() + 0.001) return showError(new Error('支付金额不能超过项目合计'));
    if ($('payment-method').value === '会员余额' && !$('order-customer').value) {
      return showError(new Error('散客不能使用会员余额支付'));
    }
    state.payments.push({ method: $('payment-method').value, amount });
    draw();
  });

  $('submit-order').addEventListener('click', async () => {
    if (!state.cart.length) return showError(new Error('请选择服务项目'));
    if (Math.abs(paid() - total()) > 0.001) return showError(new Error('支付合计必须等于项目合计'));
    const button = $('submit-order');
    button.disabled = true;
    button.textContent = '正在完成开单…';
    try {
      const technician = employees.find(item => String(item.id) === $('order-technician').value);
      const result = await api('/orders', {
        method: 'POST',
        body: JSON.stringify({
          customerId: $('order-customer').value || null,
          remark: $('order-remark').value,
          items: state.cart.map(item => ({
            ...item,
            technicianId: technician?.id || null,
            technicianName: technician?.name || '',
            commission: item.commissionType === 'PERCENT'
              ? Number((Number(item.price) * item.commissionValue / 100).toFixed(2))
              : item.commissionValue
          })),
          payments: state.payments
        })
      });
      state.cart = [];
      state.payments = [];
      toast(`开单成功：${result.orderNo}`);
      state.page = '订单管理';
      await render();
    } catch (error) {
      showError(error);
      button.disabled = false;
      button.textContent = '确认收款并完成开单';
    }
  });
  draw();
}

async function ordersPage() {
  let rows = await api('/orders');
  const content = $('content');
  const drawRows = data => data.length ? data.map(row => `
    <tr><td><button class="link" data-order-detail="${row.id}">${esc(row.order_no)}</button></td>
      <td>${esc(row.customer_name || '散客')}<small>${esc(row.phone || '')}</small></td>
      <td><b>${money(row.received)}</b></td><td>${statusTag(row.status)}</td><td>${esc(shortDate(row.created_at))}</td>
      <td class="actions"><button class="ghost small" data-order-detail="${row.id}">详情</button>
      ${['管理员', '店长'].includes(state.user.role) && !['已退款', '已取消'].includes(row.status)
        ? `<button class="ghost small danger" data-refund="${row.id}" data-max="${row.received}">退款</button>` : ''}</td></tr>
  `).join('') : `<tr><td colspan="6">${empty('没有符合条件的订单')}</td></tr>`;
  content.innerHTML = `
    <div class="toolbar">${input('order-keyword', '订单号 / 姓名 / 手机号')}<button id="search-order">查询</button><button id="export-order" class="ghost">导出 Excel</button></div>
    <div class="panel"><div class="table-wrap"><table><thead><tr><th>订单号</th><th>顾客</th><th>实收</th><th>状态</th><th>时间</th><th>操作</th></tr></thead><tbody id="order-rows">${drawRows(rows)}</tbody></table></div></div>`;

  const bind = () => {
    $('order-rows').querySelectorAll('[data-order-detail]').forEach(button => button.addEventListener('click', () => orderDetail(Number(button.dataset.orderDetail))));
    $('order-rows').querySelectorAll('[data-refund]').forEach(button => button.addEventListener('click', () => refundOrder(Number(button.dataset.refund), Number(button.dataset.max))));
  };
  bind();
  $('search-order').addEventListener('click', async () => {
    try {
      rows = await api(`/orders?q=${encodeURIComponent($('order-keyword').value.trim())}`);
      $('order-rows').innerHTML = drawRows(rows);
      bind();
    } catch (error) { showError(error); }
  });
  $('export-order').addEventListener('click', () => downloadCsv(`齐沐堂订单_${today()}.csv`, [
    { label: '订单号', value: 'order_no' }, { label: '顾客', value: row => row.customer_name || '散客' },
    { label: '手机号', value: 'phone' }, { label: '实收', value: 'received' },
    { label: '状态', value: 'status' }, { label: '时间', value: 'created_at' }
  ], rows));
}

async function orderDetail(id) {
  const data = await api(`/orders/${id}`);
  modal(`订单详情 · ${data.order.order_no}`, `
    <div class="detail-cards"><div><span>订单状态</span>${statusTag(data.order.status)}</div><div><span>项目合计</span><b>${money(data.order.total)}</b></div><div><span>实收金额</span><b>${money(data.order.received)}</b></div></div>
    <h4>服务项目</h4><div class="table-wrap"><table><thead><tr><th>项目</th><th>技师</th><th>金额</th><th>提成</th></tr></thead><tbody>${data.items.map(item => `<tr><td>${esc(item.service_name)}</td><td>${esc(item.technician_name || '未指定')}</td><td>${money(item.received)}</td><td>${money(item.commission)}</td></tr>`).join('')}</tbody></table></div>
    <h4>付款明细</h4><div class="table-wrap"><table><thead><tr><th>方式</th><th>金额</th><th>时间</th></tr></thead><tbody>${data.payments.map(payment => `<tr><td>${esc(payment.method)}</td><td>${money(payment.amount)}</td><td>${esc(shortDate(payment.created_at))}</td></tr>`).join('')}</tbody></table></div>
  `, async () => {}, { saveText: '关闭', wide: true });
}

function refundOrder(id, maximum) {
  modal('订单退款', `
    <div class="notice warning">退款会按原支付方式冲回，并同步冲减顾客消费与未结提成。最多可退 ${money(maximum)}。</div>
    ${field('退款金额', input('refund-amount', '请输入退款金额', 'number', maximum, `min="0.01" max="${maximum}" step="0.01"`))}
    ${field('退款原因', '<textarea id="refund-reason" placeholder="必须写明退款原因"></textarea>')}
  `, async () => {
    const amount = Number($('refund-amount').value);
    const reason = $('refund-reason').value.trim();
    if (!(amount > 0) || amount > maximum) throw new Error('退款金额不正确');
    if (reason.length < 2) throw new Error('请填写退款原因');
    await api(`/orders/${id}/refund`, { method: 'POST', body: JSON.stringify({ amount, reason }) });
    toast('退款成功，账目已自动冲回');
    await ordersPage();
  }, { saveText: '确认退款' });
}

async function customersPage() {
  const initialKeyword = state.searchSeed?.page === '顾客档案' ? state.searchSeed.value : '';
  if (state.searchSeed?.page === '顾客档案') state.searchSeed = null;
  let keyword=initialKeyword,page=1,pageData=await api(`/customers/page?q=${encodeURIComponent(keyword)}&page=1&pageSize=50`),rows=pageData.rows;
  const content = $('content');
  const rowHtml = data => data.length ? data.map(row => `
    <tr><td><button class="link customer-name" data-profile="${row.id}">${esc(row.name)}</button><small>${esc(row.member_no)}</small></td>
      <td>${esc(row.phone)}</td><td>${esc(row.source || '-')}</td><td>${row.visit_count || 0}</td>
      <td>${money(row.total_spent)}</td><td><b>${money(Number(row.balance_principal) + Number(row.balance_gift))}</b></td>
      <td class="actions"><button class="ghost small" data-profile="${row.id}">档案</button><button class="ghost small" data-edit-customer="${row.id}">编辑</button></td></tr>`).join('')
    : `<tr><td colspan="7">${empty('还没有顾客档案')}</td></tr>`;
  content.innerHTML = `
    <div class="toolbar">${input('customer-keyword', '姓名 / 手机号 / 会员号', 'text', initialKeyword)}<button id="search-customer">查询</button><button id="new-customer">新增顾客</button><button id="export-customer" class="ghost">导出 Excel</button></div>
    <div class="panel"><div class="panel-head"><div><h3>顾客档案</h3><p>共 <span id="customer-total">${pageData.total}</span> 位顾客，每页50位</p></div></div><div class="table-wrap"><table><thead><tr><th>顾客</th><th>手机</th><th>来源</th><th>到店次数</th><th>累计消费</th><th>会员余额</th><th>操作</th></tr></thead><tbody id="customer-rows">${rowHtml(rows)}</tbody></table></div><div id="customer-pages" class="pagination"></div></div>`;

  const bind = () => {
    $('customer-rows').querySelectorAll('[data-profile]').forEach(button => button.addEventListener('click', () => showCustomerProfile(Number(button.dataset.profile))));
    $('customer-rows').querySelectorAll('[data-edit-customer]').forEach(button => button.addEventListener('click', () => {
      const customer = rows.find(item => String(item.id) === button.dataset.editCustomer);
      customerForm(customer);
    }));
  };
  const drawPager=()=>{$('customer-pages').innerHTML=`<button id="customer-prev" class="ghost small" ${pageData.page<=1?'disabled':''}>上一页</button><span>第 ${pageData.page} / ${pageData.pages} 页</span><button id="customer-next" class="ghost small" ${pageData.page>=pageData.pages?'disabled':''}>下一页</button>`;$('customer-prev').addEventListener('click',()=>loadPage(page-1));$('customer-next').addEventListener('click',()=>loadPage(page+1));};
  const loadPage=async next=>{page=Math.max(1,next);pageData=await api(`/customers/page?q=${encodeURIComponent(keyword)}&page=${page}&pageSize=50`);rows=pageData.rows;$('customer-rows').innerHTML=rowHtml(rows);$('customer-total').textContent=pageData.total;bind();drawPager();};
  bind();drawPager();
  $('search-customer').addEventListener('click', async () => {
    keyword=$('customer-keyword').value.trim();await loadPage(1);
  });
  $('new-customer').addEventListener('click', () => customerForm());
  $('export-customer').addEventListener('click', async () => {const exportRows=await api(`/customers?q=${encodeURIComponent(keyword)}`);downloadCsv(`齐沐堂顾客_${today()}.csv`, [
    { label: '姓名', value: 'name' }, { label: '手机号', value: 'phone' }, { label: '性别', value: 'gender' },
    { label: '来源', value: 'source' }, { label: '会员号', value: 'member_no' }, { label: '到店次数', value: 'visit_count' },
    { label: '累计消费', value: 'total_spent' }, { label: '本金余额', value: 'balance_principal' }, { label: '赠送余额', value: 'balance_gift' }
  ], exportRows);});
}

function customerForm(customer = null) {
  const editing = Boolean(customer);
  modal(editing ? '编辑顾客资料' : '新增顾客', `
    <div class="form-grid two">
      ${field('姓名 *', input('customer-name', '顾客姓名', 'text', customer?.name || ''))}
      ${field('手机号 *', input('customer-phone', '用于查找顾客', 'tel', customer?.phone || ''))}
      ${field('性别', select('customer-gender', ['未知', '男', '女'], 'name', customer?.gender || '未知'))}
      ${field('年龄', input('customer-age', '年龄', 'number', customer?.age || '', 'min="0" max="120"'))}
      ${field('生日', input('customer-birthday', '生日', 'date', customer?.birthday || ''))}
      ${field('顾客来源', select('customer-source', ['美团', '抖音', '路过', '老客介绍', '微信', '电话', '其他'], 'name', customer?.source || '美团'))}
    </div>
    ${field('地址', input('customer-address', '选填', 'text', customer?.address || ''))}
    ${field('备注', `<textarea id="customer-remark" placeholder="过敏、护理偏好、沟通注意事项等">${esc(customer?.remark || '')}</textarea>`)}
  `, async () => {
    const body = {
      name: $('customer-name').value.trim(), phone: $('customer-phone').value.trim(),
      gender: $('customer-gender').value, age: $('customer-age').value || null,
      birthday: $('customer-birthday').value || null, source: $('customer-source').value,
      address: $('customer-address').value.trim(), remark: $('customer-remark').value.trim()
    };
    if (!body.name || !body.phone) throw new Error('姓名和手机号不能为空');
    await api(editing ? `/customers/${customer.id}` : '/customers', {
      method: editing ? 'PUT' : 'POST', body: JSON.stringify(body)
    });
    toast(editing ? '顾客资料已更新' : '顾客新增成功');
    await customersPage();
  });
}

async function showCustomerProfile(id) {
  const data = await api(`/customers/${id}/profile`);
  const customer = data.customer;
  const balance = Number(customer.balance_principal) + Number(customer.balance_gift);
  modal(`${customer.name} · 360°档案`, `
    <div class="profile-head"><div class="avatar">${esc(customer.name.slice(0, 1))}</div><div><h3>${esc(customer.name)}</h3><p>${esc(customer.phone)}　${esc(customer.gender || '')}　会员号 ${esc(customer.member_no)}</p></div></div>
    <div class="detail-cards four"><div><span>累计消费</span><b>${money(customer.total_spent)}</b></div><div><span>到店次数</span><b>${customer.visit_count || 0}</b></div><div><span>会员余额</span><b>${money(balance)}</b></div><div><span>最近到店</span><b>${esc(shortDate(customer.last_visit).slice(0, 10))}</b></div></div>
    <div class="tabs-line"><b>最近订单</b></div>${data.orders.length ? `<div class="table-wrap"><table><thead><tr><th>订单号</th><th>金额</th><th>状态</th><th>时间</th></tr></thead><tbody>${data.orders.map(row => `<tr><td>${esc(row.order_no)}</td><td>${money(row.received)}</td><td>${statusTag(row.status)}</td><td>${esc(shortDate(row.created_at))}</td></tr>`).join('')}</tbody></table></div>` : empty('暂无订单')}
    <div class="tabs-line"><b>护理记录</b></div>${data.careRecords.length ? `<div class="table-wrap"><table><thead><tr><th>类型</th><th>阶段</th><th>护理日期</th><th>下次日期</th></tr></thead><tbody>${data.careRecords.map(row => `<tr><td>${esc(row.type)}</td><td>${esc(row.stage)}</td><td>${esc(shortDate(row.care_date).slice(0, 10))}</td><td>${esc(row.next_date || '-')}</td></tr>`).join('')}</tbody></table></div>` : empty('暂无护理记录')}
    <div class="tabs-line"><b>余额流水</b></div>${data.balanceLogs.length ? `<div class="table-wrap"><table><thead><tr><th>类型</th><th>变动</th><th>变动后</th><th>时间</th><th>备注</th></tr></thead><tbody>${data.balanceLogs.map(row => `<tr><td>${esc(row.type)}</td><td class="${Number(row.change_amount) < 0 ? 'negative' : 'positive'}">${Number(row.change_amount) > 0 ? '+' : ''}${money(row.change_amount).replace('¥', '')}</td><td>${money(row.after_amount)}</td><td>${esc(shortDate(row.created_at))}</td><td>${esc(row.remark || '')}</td></tr>`).join('')}</tbody></table></div>` : empty('暂无余额流水')}
  `, async () => {}, { saveText: '关闭', wide: true });
}

async function carePage() {
  const [customers, employees, reminders, records] = await Promise.all([
    api('/customers'), api('/employees').catch(() => []), api('/reminders/care?days=7'), api('/care-records')
  ]);
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar"><button id="new-care">新增护理档案</button></div>
    <div class="panel"><div class="panel-head"><div><h3>7日内护理提醒</h3><p>包含已到期和即将到期的顾客</p></div><span class="count-badge">${reminders.length}</span></div>
      ${reminders.length ? `<div class="table-wrap"><table><thead><tr><th>日期</th><th>顾客</th><th>手机</th><th>护理类型</th><th>阶段</th><th>负责人</th></tr></thead><tbody>${reminders.map(row => `<tr class="${String(row.next_date) < today() ? 'overdue' : ''}"><td>${esc(row.next_date)}</td><td>${esc(row.customer_name)}</td><td>${esc(row.phone)}</td><td>${esc(row.type)}</td><td>${esc(row.stage)}</td><td>${esc(row.technician_name || '未指定')}</td></tr>`).join('')}</tbody></table></div>` : empty('近期没有护理提醒')}
    </div>
    <div class="panel"><div class="panel-head"><div><h3>护理档案</h3><p>灰指甲、甲沟炎、嵌甲等护理过程</p></div></div>
      ${records.length ? `<div class="table-wrap"><table><thead><tr><th>日期</th><th>顾客</th><th>类型</th><th>部位</th><th>阶段</th><th>技师</th><th>护理前</th><th>护理后</th></tr></thead><tbody>${records.map(row => `<tr><td>${esc(shortDate(row.care_date).slice(0, 10))}</td><td>${esc(row.customer_name)}</td><td>${esc(row.type)}</td><td>${esc(`${row.foot || ''} ${row.toe || ''}`)}</td><td>${statusTag(row.stage)}</td><td>${esc(row.technician_name || '未指定')}</td><td>${row.before_photo ? `<a href="${esc(row.before_photo)}" target="_blank">查看照片</a>` : '-'}</td><td>${row.after_photo ? `<a href="${esc(row.after_photo)}" target="_blank">查看照片</a>` : '-'}</td></tr>`).join('')}</tbody></table></div>` : empty('还没有护理档案')}
    </div>`;

  $('new-care').addEventListener('click', () => {
    if (!customers.length) return showError(new Error('请先新增顾客'));
    modal('新增护理档案', `
      <div class="form-grid two">
        ${field('顾客 *', select('care-customer', customers))}
        ${field('护理类型 *', select('care-type', ['灰指甲', '甲沟炎', '嵌甲', '鸡眼', '脚垫', '跖疣护理', '脚气护理', '普通修脚', '其他']))}
        ${field('脚别', select('care-foot', ['左脚', '右脚', '双脚']))}
        ${field('脚趾 / 部位', input('care-toe', '例如：大拇趾右侧'))}
        ${field('当前阶段', select('care-stage', ['初次', '改善期', '稳定期', '日常维护', '完成']))}
        ${field('负责人', select('care-technician', employees, 'name', '', '暂不指定'))}
        ${field('下次护理日期', input('care-next', '下次护理日期', 'date'))}
      </div>
      ${field('情况与护理方案', '<textarea id="care-description" placeholder="记录当前情况、处理内容、注意事项和下次计划"></textarea>')}
      <div class="form-grid two">
        ${field('护理前照片', '<input id="care-before" type="file" accept="image/jpeg,image/png">')}
        ${field('护理后照片', '<input id="care-after" type="file" accept="image/jpeg,image/png">')}
      </div>
    `, async () => {
      const upload = async file => {
        if (!file) return null;
        const form = new FormData();
        form.append('file', file);
        return api('/upload', { method: 'POST', body: form });
      };
      const beforePhoto = await upload($('care-before').files[0]);
      const afterPhoto = await upload($('care-after').files[0]);
      const description = $('care-description').value.trim();
      await api('/care', { method: 'POST', body: JSON.stringify({
        customerId: $('care-customer').value, type: $('care-type').value,
        foot: $('care-foot').value, toe: $('care-toe').value.trim(), stage: $('care-stage').value,
        technicianId: $('care-technician').value || null, nextDate: $('care-next').value || null,
        description, plan: description, beforePhoto, afterPhoto
      }) });
      toast('护理档案已保存');
      await carePage();
    }, { wide: true });
  });
}

async function appointmentsPage() {
  const selectedDate = window.qmtAppointmentDate || today();
  const [rows, customers, services, employees] = await Promise.all([
    api(`/appointments?date=${selectedDate}`), api('/customers'), api('/services'), api('/employees').catch(() => [])
  ]);
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar">${input('appointment-date', '日期', 'date', selectedDate)}<button id="load-appointments">查询</button><button id="new-appointment">新增预约</button></div>
    <div class="panel"><div class="table-wrap"><table><thead><tr><th>预约时间</th><th>顾客</th><th>项目</th><th>技师</th><th>时长</th><th>状态</th></tr></thead><tbody>${rows.length ? rows.map(row => `<tr><td><b>${esc(shortDate(row.start_at).slice(11))}</b></td><td>${esc(row.customer_name)}<small>${esc(row.phone)}</small></td><td>${esc(row.service_name)}</td><td>${esc(row.technician_name || '未指定')}</td><td>${row.duration || 0}分钟</td><td><select class="status-select" data-appointment-status="${row.id}">${['待到店', '已到店', '已完成', '已取消', '爽约'].map(status => `<option ${status === row.status ? 'selected' : ''}>${status}</option>`).join('')}</select></td></tr>`).join('') : `<tr><td colspan="6">${empty('当天没有预约')}</td></tr>`}</tbody></table></div></div>`;

  $('load-appointments').addEventListener('click', () => {
    window.qmtAppointmentDate = $('appointment-date').value;
    appointmentsPage();
  });
  content.querySelectorAll('[data-appointment-status]').forEach(control => control.addEventListener('change', async () => {
    try {
      await api(`/appointments/${control.dataset.appointmentStatus}/status`, { method: 'PUT', body: JSON.stringify({ status: control.value }) });
      toast('预约状态已更新');
    } catch (error) { showError(error); appointmentsPage(); }
  }));
  $('new-appointment').addEventListener('click', () => {
    if (!customers.length) return showError(new Error('请先新增顾客'));
    modal('新增预约', `
      <div class="form-grid two">
        ${field('顾客 *', select('appointment-customer', customers))}
        ${field('服务项目 *', select('appointment-service', services.filter(item => Number(item.status) === 1)))}
        ${field('服务技师', select('appointment-employee', employees, 'name', '', '暂不指定'))}
        ${field('预约时间 *', input('appointment-time', '预约时间', 'datetime-local', `${selectedDate}T09:00`))}
        ${field('预计时长（分钟）', input('appointment-duration', '时长', 'number', '60', 'min="10" step="10"'))}
      </div>
      ${field('备注', '<textarea id="appointment-remark" placeholder="顾客要求、到店提醒等"></textarea>')}
    `, async () => {
      if (!$('appointment-time').value) throw new Error('请选择预约时间');
      await api('/appointments', { method: 'POST', body: JSON.stringify({
        customerId: $('appointment-customer').value, serviceId: $('appointment-service').value,
        technicianId: $('appointment-employee').value || null, startAt: $('appointment-time').value,
        duration: $('appointment-duration').value, remark: $('appointment-remark').value.trim()
      }) });
      window.qmtAppointmentDate = $('appointment-time').value.slice(0, 10);
      toast('预约创建成功');
      await appointmentsPage();
    });
  });
}

async function membersPage() {
  let keyword='',page=1,pageData=await api('/customers/page?page=1&pageSize=50'),customers=pageData.rows;
  const content = $('content');
  const rowsHtml = rows => rows.length ? rows.map(row => `
    <tr><td>${esc(row.name)}<small>${esc(row.member_no)}</small></td><td>${esc(row.member_level)}</td><td>${money(row.balance_principal)}</td><td>${money(row.balance_gift)}</td><td><b>${money(Number(row.balance_principal) + Number(row.balance_gift))}</b></td><td class="actions"><button class="small" data-recharge="${row.id}">充值</button><button class="ghost small" data-balance-log="${row.id}">流水</button>${['管理员', '店长'].includes(state.user.role) ? `<button class="ghost small" data-balance-adjust="${row.id}">调整</button>` : ''}</td></tr>`).join('') : `<tr><td colspan="6">${empty('还没有会员')}</td></tr>`;
  content.innerHTML = `
    <div class="toolbar">${input('member-keyword', '姓名 / 手机号')}<button id="search-member">筛选</button><button id="member-recharge">会员充值</button></div>
    <div class="panel"><div class="panel-head"><div><h3>会员余额</h3><p>本金和赠送金分账 · 共 <span id="member-total">${pageData.total}</span> 人</p></div></div><div class="table-wrap"><table><thead><tr><th>会员</th><th>等级</th><th>本金</th><th>赠送金</th><th>余额合计</th><th>操作</th></tr></thead><tbody id="member-rows">${rowsHtml(customers)}</tbody></table></div><div id="member-pages" class="pagination"></div></div>`;

  const bind = () => {
    $('member-rows').querySelectorAll('[data-recharge]').forEach(button => button.addEventListener('click', () => memberRecharge(customers, button.dataset.recharge)));
    $('member-rows').querySelectorAll('[data-balance-log]').forEach(button => button.addEventListener('click', () => memberBalanceLogs(Number(button.dataset.balanceLog))));
    $('member-rows').querySelectorAll('[data-balance-adjust]').forEach(button => button.addEventListener('click', () => memberBalanceAdjust(customers, button.dataset.balanceAdjust)));
  };
  const drawPager=()=>{$('member-pages').innerHTML=`<button id="member-prev" class="ghost small" ${pageData.page<=1?'disabled':''}>上一页</button><span>第 ${pageData.page} / ${pageData.pages} 页</span><button id="member-next" class="ghost small" ${pageData.page>=pageData.pages?'disabled':''}>下一页</button>`;$('member-prev').addEventListener('click',()=>loadPage(page-1));$('member-next').addEventListener('click',()=>loadPage(page+1));};
  const loadPage=async next=>{page=Math.max(1,next);pageData=await api(`/customers/page?q=${encodeURIComponent(keyword)}&page=${page}&pageSize=50`);customers=pageData.rows;$('member-rows').innerHTML=rowsHtml(customers);$('member-total').textContent=pageData.total;bind();drawPager();};
  bind();drawPager();
  $('search-member').addEventListener('click',async()=>{keyword=$('member-keyword').value.trim();await loadPage(1);});
  $('member-recharge').addEventListener('click',()=>memberRecharge(customers));
}

function memberRecharge(customers, selected = '') {
  if (!customers.length) return showError(new Error('请先新增顾客'));
  modal('会员充值', `
    ${field('会员 *', select('recharge-customer', customers, 'name', selected))}
    <div class="form-grid two">${field('充值本金 *', input('recharge-amount', '实际收款', 'number', '', 'min="0.01" step="0.01"'))}${field('赠送金额', input('recharge-gift', '赠送金', 'number', '0', 'min="0" step="0.01"'))}</div>
    ${field('备注', '<textarea id="recharge-remark" placeholder="付款方式、活动说明等"></textarea>')}
    <div class="notice warning">充值前请核对实际收款。系统不会自动向顾客发起支付。</div>
  `, async () => {
    const amount = Number($('recharge-amount').value);
    const gift = Number($('recharge-gift').value || 0);
    if (!(amount > 0) || gift < 0) throw new Error('充值金额不正确');
    if (!confirmAction(`确认实际收到 ${money(amount)}，赠送 ${money(gift)}？`)) throw new Error('已取消充值');
    const message = await api('/members/recharge', { method: 'POST', body: JSON.stringify({
      customerId: $('recharge-customer').value, amount, gift, remark: $('recharge-remark').value.trim()
    }) });
    toast(message);
    await membersPage();
  }, { saveText: '确认充值' });
}

async function memberBalanceLogs(customerId) {
  const data = await api(`/members/${customerId}/balance-logs`);
  modal('会员余额流水', data.length ? `<div class="table-wrap"><table><thead><tr><th>类型</th><th>变动前</th><th>变动</th><th>变动后</th><th>时间</th><th>备注</th></tr></thead><tbody>${data.map(row => `<tr><td>${esc(row.type)}</td><td>${money(row.before_amount)}</td><td class="${Number(row.change_amount) < 0 ? 'negative' : 'positive'}">${Number(row.change_amount) > 0 ? '+' : ''}${Number(row.change_amount).toFixed(2)}</td><td>${money(row.after_amount)}</td><td>${esc(shortDate(row.created_at))}</td><td>${esc(row.remark || '')}</td></tr>`).join('')}</tbody></table></div>` : empty('暂无余额流水'), async () => {}, { saveText: '关闭', wide: true });
}

function memberBalanceAdjust(customers, selected) {
  const customer = customers.find(row => String(row.id) === String(selected));
  modal(`余额调整 · ${customer?.name || ''}`, `
    <div class="notice warning">仅用于纠错、充值退款等特殊情况。正数增加，负数扣减；系统会永久记录操作人和原因。</div>
    <div class="form-grid two">${field('本金变动', input('adjust-principal', '例如 -100', 'number', '0', 'step="0.01"'))}${field('赠送金变动', input('adjust-gift', '例如 -20', 'number', '0', 'step="0.01"'))}</div>
    ${field('调整原因 *', '<textarea id="adjust-reason" placeholder="例如：充值录入错误，已原路退款"></textarea>')}
  `, async () => {
    const principalChange = Number($('adjust-principal').value || 0);
    const giftChange = Number($('adjust-gift').value || 0);
    const reason = $('adjust-reason').value.trim();
    if (!principalChange && !giftChange) throw new Error('请输入变动金额');
    if (reason.length < 2) throw new Error('请填写调整原因');
    if (!confirmAction(`确认调整 ${customer.name} 的余额？该操作会写入审计日志。`)) throw new Error('已取消调整');
    const message = await api('/members/adjust', { method: 'POST', body: JSON.stringify({ customerId: selected, principalChange, giftChange, reason }) });
    toast(message);
    await membersPage();
  }, { saveText: '确认调整' });
}

async function packagesPage() {
  const [rows, customers, services] = await Promise.all([api('/packages'), api('/customers'), api('/services')]);
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar"><button id="new-package">购买次卡</button></div>
    <div class="panel"><div class="table-wrap"><table><thead><tr><th>顾客</th><th>套餐</th><th>对应项目</th><th>总次数</th><th>已用</th><th>剩余</th><th>有效期</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows.length ? rows.map(row => {
      const remaining = Number(row.total_times) - Number(row.used_times);
      return `<tr><td>${esc(row.customer_name)}</td><td>${esc(row.name)}</td><td>${esc(row.service_name)}</td><td>${row.total_times}</td><td>${row.used_times}</td><td><b>${remaining}</b></td><td>${esc(row.expires_at || '长期')}</td><td>${statusTag(row.status)}</td><td>${row.status === '正常' ? `<button class="small" data-use-package="${row.id}" data-remaining="${remaining}">核销1次</button>` : '-'}</td></tr>`;
    }).join('') : `<tr><td colspan="9">${empty('还没有次卡套餐')}</td></tr>`}</tbody></table></div></div>`;

  content.querySelectorAll('[data-use-package]').forEach(button => button.addEventListener('click', async () => {
    if (!confirmAction(`确认核销1次？核销后剩余 ${Number(button.dataset.remaining) - 1} 次。`)) return;
    try {
      const message = await api(`/packages/${button.dataset.usePackage}/use`, { method: 'POST', body: '{}' });
      toast(message);
      await packagesPage();
    } catch (error) { showError(error); }
  }));
  $('new-package').addEventListener('click', () => {
    if (!customers.length) return showError(new Error('请先新增顾客'));
    modal('购买次卡', `
      ${field('顾客 *', select('package-customer', customers))}
      ${field('套餐名称 *', input('package-name', '例如：招牌修脚3次卡', 'text', '招牌修脚3次卡'))}
      <div class="form-grid two">${field('对应项目 *', select('package-service', services.filter(row => Number(row.status) === 1)))}${field('总次数 *', input('package-times', '次数', 'number', '3', 'min="1"'))}${field('有效期', input('package-expiry', '留空为长期', 'date'))}</div>
      <div class="notice">当前版本记录次卡次数与核销。销售收款请同时在“收银开单”登记，避免营业额漏记。</div>
    `, async () => {
      const times = Number($('package-times').value);
      if (!(times > 0)) throw new Error('套餐次数必须大于0');
      await api('/packages', { method: 'POST', body: JSON.stringify({
        customerId: $('package-customer').value, name: $('package-name').value.trim(),
        serviceId: $('package-service').value, totalTimes: times, expiresAt: $('package-expiry').value || null
      }) });
      toast('次卡购买成功');
      await packagesPage();
    });
  });
}

Object.assign(pages, {
  首页: dashboardPage,
  收银开单: checkoutPage,
  订单管理: ordersPage,
  顾客档案: customersPage,
  护理档案: carePage,
  预约管理: appointmentsPage,
  会员管理: membersPage,
  会员卡: packagesPage,
  次卡套餐: packagesPage
});
