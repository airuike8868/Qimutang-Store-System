package com.qimutang;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

@RestController
@RequestMapping("/api/v32")
class V32Api {
    private final JdbcTemplate db;
    private final ObjectMapper json;
    private final V23Api v23;
    private final SettingsService settings;

    V32Api(JdbcTemplate db, ObjectMapper json, V23Api v23, SettingsService settings) {
        this.db = db; this.json = json; this.v23 = v23; this.settings = settings;
    }

    private Map<String,Object> ok(Object data) { return Map.of("success", true, "data", data); }
    private Map<String,Object> fail(String message) { return Map.of("success", false, "message", message); }
    private String now() { return LocalDateTime.now().toString(); }
    private long uid(HttpServletRequest r) { Object v=r.getAttribute("userId"); if (!(v instanceof Number)) throw new IllegalArgumentException("登录已失效"); return ((Number)v).longValue(); }
    private String role(HttpServletRequest r) { return Objects.toString(r.getAttribute("role"), ""); }
    private void require(HttpServletRequest r, String... roles) { if (Arrays.stream(roles).noneMatch(role(r)::equals)) throw new IllegalArgumentException("当前账号没有此操作权限"); }
    private String text(Object v) { return Objects.toString(v, "").trim(); }
    private Long id(Object v) { if (v == null || text(v).isBlank()) return null; return Long.parseLong(text(v)); }
    private String stringify(Object value) { try { return json.writeValueAsString(value); } catch (Exception e) { throw new IllegalArgumentException("业务数据格式不正确"); } }
    private Map<String,Object> object(String value) { try { return json.readValue(value, new TypeReference<>() {}); } catch (Exception e) { throw new IllegalArgumentException("审批数据损坏，请重新提交"); } }
    private void log(HttpServletRequest r,String type,String content) { String n=now(); db.update("insert into audit_logs(user_id,type,content,ip,created_at,updated_at) values(?,?,?,?,?,?)",uid(r),type,content,r.getRemoteAddr(),n,n); }

    @PutMapping("/branding")
    Object saveBranding(@RequestBody Map<String,Object> body, HttpServletRequest request) {
        require(request, "管理员");
        String name=text(body.get("systemName")); String logo=text(body.get("logo"));
        if (name.length()<2 || name.length()>30) return fail("系统名称请输入2至30个字");
        if (!(logo.startsWith("/uploads/") || "/qimutang-logo.png".equals(logo))) return fail("Logo文件地址不正确");
        String n=now();
        DbCompat.upsertSetting(db,"system_name",name,"客户端显示名称",n);
        DbCompat.upsertSetting(db,"brand_logo",logo,"客户端品牌Logo",n);
        log(request,"品牌设置","系统名称改为："+name);
        return ok("系统名称和Logo已保存，所有客户端刷新后生效");
    }

    @PostMapping("/branding/reset")
    Object resetBranding(HttpServletRequest request) {
        require(request,"管理员"); String n=now();
        DbCompat.upsertSetting(db,"system_name","齐沐堂门店管理系统","客户端显示名称",n);
        DbCompat.upsertSetting(db,"brand_logo","/qimutang-logo.png","客户端品牌Logo",n);
        log(request,"品牌设置","恢复默认系统名称和经典Logo"); return ok("已恢复默认品牌");
    }

    @GetMapping("/tickets")
    Object tickets(@RequestParam(defaultValue="") String status, HttpServletRequest request) {
        require(request,"管理员","店长","前台","技师");
        String sql="select t.*,c.name customer_name,c.phone,e.name employee_name,w.name workstation_name,a.start_at appointment_time " +
                "from service_tickets t left join customers c on c.id=t.customer_id left join employees e on e.id=t.employee_id " +
                "left join workstations w on w.id=t.workstation_id left join appointments a on a.id=t.appointment_id where t.deleted=0";
        List<Map<String,Object>> rows=status.isBlank()?db.queryForList(sql+" order by t.id desc limit 300"):
                db.queryForList(sql+" and t.status=? order by t.id desc limit 300",status);
        rows.forEach(row -> row.put("items", parseList(text(row.get("items_json")))));
        return ok(rows);
    }

    @GetMapping("/tickets/{ticketId}")
    Object ticket(@PathVariable long ticketId, HttpServletRequest request) {
        require(request,"管理员","店长","前台","技师");
        List<Map<String,Object>> rows=db.queryForList("select t.*,c.name customer_name,c.phone,e.name employee_name,w.name workstation_name from service_tickets t left join customers c on c.id=t.customer_id left join employees e on e.id=t.employee_id left join workstations w on w.id=t.workstation_id where t.id=? and t.deleted=0",ticketId);
        if(rows.isEmpty()) return fail("服务单不存在"); Map<String,Object> row=new LinkedHashMap<>(rows.get(0)); row.put("items",parseList(text(row.get("items_json")))); return ok(row);
    }

    @PostMapping("/tickets")
    Object createTicket(@RequestBody Map<String,Object> body,HttpServletRequest request) {
        require(request,"管理员","店长","前台");
        if (!(body.get("items") instanceof List<?> items) || items.isEmpty()) return fail("请至少选择一个服务项目");
        Long customer=id(body.get("customerId")), employee=id(body.get("employeeId")), workstation=id(body.get("workstationId"));
        long ticketId=insertTicket(null,customer,employee,workstation,items,text(body.get("remark")),uid(request));
        log(request,"服务开单","新建服务单ID "+ticketId); return ok(Map.of("ticketId",ticketId,"message","服务单已创建，可先服务后结账"));
    }

    @PostMapping("/appointments/{appointmentId}/convert")
    @Transactional
    Object convertAppointment(@PathVariable long appointmentId,@RequestBody Map<String,Object> body,HttpServletRequest request) {
        require(request,"管理员","店长","前台");
        Map<String,Object> a;
        try { a=db.queryForMap("select * from appointments where id=? and deleted=0",appointmentId); }
        catch(Exception e){ return fail("预约不存在"); }
        if(a.get("ticket_id")!=null) return ok(Map.of("ticketId",a.get("ticket_id"),"duplicate",true));
        List<Map<String,Object>> items=new ArrayList<>();
        Map<String,Object> item=new LinkedHashMap<>(); item.put("type","SERVICE"); item.put("id",a.get("service_id")); item.put("quantity",1); item.put("employeeId",a.get("technician_id")); items.add(item);
        Long workstation=id(body.get("workstationId"));
        long ticketId=insertTicket(appointmentId,id(a.get("customer_id")),id(a.get("technician_id")),workstation,items,text(a.get("remark")),uid(request));
        String n=now(); db.update("update appointments set ticket_id=?,workstation_id=?,converted_at=?,status='已到店',updated_at=? where id=?",ticketId,workstation,n,n,appointmentId);
        log(request,"预约转单","预约ID "+appointmentId+"一键转服务单 "+ticketId); return ok(Map.of("ticketId",ticketId,"message","预约已转为服务单"));
    }

    @PutMapping("/tickets/{ticketId}/start") @Transactional
    Object startTicket(@PathVariable long ticketId,HttpServletRequest request){
        require(request,"管理员","店长","前台","技师"); Map<String,Object> t=findTicket(ticketId);
        if(!List.of("待服务","已暂存").contains(text(t.get("status")))) return fail("当前服务单不能开始服务");
        String n=now(); db.update("update service_tickets set status='服务中',started_at=?,updated_at=? where id=?",n,n,ticketId);
        syncBusy(t,ticketId,n,uid(request)); log(request,"服务流程","服务单"+t.get("ticket_no")+"开始服务"); return ok("已开始服务");
    }

    @PutMapping("/tickets/{ticketId}/finish") @Transactional
    Object finishTicket(@PathVariable long ticketId,HttpServletRequest request){
        require(request,"管理员","店长","前台","技师"); Map<String,Object> t=findTicket(ticketId);
        if(!"服务中".equals(text(t.get("status")))) return fail("只有服务中的单据才能结束服务");
        String n=now(); db.update("update service_tickets set status='待结账',finished_at=?,updated_at=? where id=?",n,n,ticketId);
        releaseBusy(t,n,uid(request),true); log(request,"服务流程","服务单"+t.get("ticket_no")+"完成，等待结账"); return ok("服务已完成，进入待结账");
    }

    @PutMapping("/tickets/{ticketId}/settled") @Transactional
    Object settleTicket(@PathVariable long ticketId,@RequestBody Map<String,Object> body,HttpServletRequest request){
        require(request,"管理员","店长","前台"); long orderId=Long.parseLong(text(body.get("orderId"))); Map<String,Object> t=findTicket(ticketId);
        if(!List.of("待服务","服务中","待结账").contains(text(t.get("status")))) return fail("服务单状态不能结账");
        String n=now(); db.update("update service_tickets set status='已结账',order_id=?,settled_at=?,updated_at=? where id=?",orderId,n,n,ticketId);
        db.update("update orders set source_ticket_id=?,updated_at=? where id=?",ticketId,n,orderId); releaseBusy(t,n,uid(request),false);
        log(request,"服务结账","服务单"+t.get("ticket_no")+"关联订单ID "+orderId); return ok("服务单已结账");
    }

    @GetMapping("/workstations") Object workstations(HttpServletRequest request){require(request,"管理员","店长","前台","技师");return ok(db.queryForList("select w.*,t.ticket_no,c.name customer_name from workstations w left join service_tickets t on t.id=w.current_ticket_id left join customers c on c.id=t.customer_id where w.deleted=0 order by w.sort_order,w.id"));}
    @PostMapping("/workstations") Object addWorkstation(@RequestBody Map<String,Object>b,HttpServletRequest r){require(r,"管理员","店长");String name=text(b.get("name"));if(name.length()<2)return fail("请填写工位名称");String n=now();db.update("insert into workstations(name,workstation_type,sort_order,status,created_at,updated_at,deleted) values(?,?,?,'空闲',?,?,0)",name,text(b.getOrDefault("type","其他")),b.getOrDefault("sortOrder",0),n,n);log(r,"工位管理","新增工位："+name);return ok("工位已新增");}
    @PutMapping("/workstations/{workstationId}/clean") Object clean(@PathVariable long workstationId,HttpServletRequest r){require(r,"管理员","店长","前台","技师");db.update("update workstations set status='空闲',current_ticket_id=null,updated_at=? where id=?",now(),workstationId);return ok("工位已恢复空闲");}

    @GetMapping("/employee-states") Object employeeStates(HttpServletRequest r){require(r,"管理员","店长","前台","技师");String n=now();for(Map<String,Object>e:db.queryForList("select id from employees where deleted=0 and status='在职'")){Integer c=db.queryForObject("select count(*) from employee_states where employee_id=? and deleted=0",Integer.class,e.get("id"));if(c==0)db.update("insert into employee_states(employee_id,work_status,queue_type,queue_no,created_at,updated_at,deleted) values(?,'候钟','轮钟',0,?,?,0)",e.get("id"),n,n);}return ok(db.queryForList("select s.*,e.name employee_name,e.position,w.name workstation_name,t.ticket_no from employee_states s join employees e on e.id=s.employee_id left join workstations w on w.id=s.workstation_id left join service_tickets t on t.id=s.current_ticket_id where s.deleted=0 and e.deleted=0 and e.status='在职' order by s.queue_no,s.id"));}
    @PutMapping("/employee-states/{employeeId}") Object updateEmployeeState(@PathVariable long employeeId,@RequestBody Map<String,Object>b,HttpServletRequest r){require(r,"管理员","店长","前台");String status=text(b.get("status"));if(!List.of("候钟","服务中","休息","下班").contains(status))return fail("员工状态不正确");String type=text(b.getOrDefault("queueType","轮钟"));if(!List.of("轮钟","点钟").contains(type))return fail("排钟类型不正确");String n=now();int c=db.update("update employee_states set work_status=?,queue_type=?,queue_no=?,updated_by=?,updated_at=? where employee_id=? and deleted=0",status,type,b.getOrDefault("queueNo",0),uid(r),n,employeeId);if(c==0)db.update("insert into employee_states(employee_id,work_status,queue_type,queue_no,updated_by,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,0)",employeeId,status,type,b.getOrDefault("queueNo",0),uid(r),n,n);log(r,"员工排钟","员工ID "+employeeId+"改为"+type+"/"+status);return ok("员工状态已更新");}

    @PostMapping("/approvals")
    Object requestApproval(@RequestBody Map<String,Object>b,HttpServletRequest r){
        require(r,"管理员","店长","前台");String type=text(b.get("actionType"));if(!List.of("退款","反结账","改价","解锁账期","删除护理照片","库存调整","余额调整").contains(type))return fail("审批类型不正确");
        String reason=text(b.get("reason"));if(reason.length()<2)return fail("请填写申请原因");Long orderId=id(b.get("orderId")),ticketId=id(b.get("ticketId"));if("改价".equals(type)&&ticketId==null)return fail("改价审批必须关联服务单");if(List.of("退款","反结账").contains(type)&&orderId==null)return fail("该审批必须关联原订单");
        String n=now();db.update("insert into operation_approvals(action_type,order_id,ticket_id,payload_json,reason,status,requested_by,created_at,updated_at,deleted) values(?,?,?,?,?,'待审批',?,?,?,0)",type,orderId,ticketId,stringify(b.getOrDefault("payload",Map.of())),reason,uid(r),n,n);long approvalId=DbCompat.lastInsertId(db);log(r,"审批申请",type+"申请#"+approvalId+"："+reason);return ok(Map.of("approvalId",approvalId,"message","审批申请已提交"));
    }
    @GetMapping("/approvals") Object approvals(@RequestParam(defaultValue="")String status,HttpServletRequest r){require(r,"管理员","店长","前台");String sql="select a.*,u.name requester_name,d.name approver_name,o.order_no,t.ticket_no from operation_approvals a left join users u on u.id=a.requested_by left join users d on d.id=a.approved_by left join orders o on o.id=a.order_id left join service_tickets t on t.id=a.ticket_id where a.deleted=0";return ok(status.isBlank()?db.queryForList(sql+" order by a.id desc limit 300"):db.queryForList(sql+" and a.status=? order by a.id desc limit 300",status));}
    @PutMapping("/approvals/{approvalId}/reject") Object reject(@PathVariable long approvalId,@RequestBody Map<String,Object>b,HttpServletRequest r){require(r,"管理员","店长");String remark=text(b.get("remark"));if(remark.length()<2)return fail("请填写驳回原因");int c=db.update("update operation_approvals set status='已驳回',rejected_by=?,decision_remark=?,updated_at=? where id=? and status='待审批' and deleted=0",uid(r),remark,now(),approvalId);if(c==0)return fail("审批单不存在或已处理");log(r,"审批处理","驳回审批#"+approvalId+"："+remark);return ok("审批已驳回");}

    @PutMapping("/approvals/{approvalId}/approve") @Transactional
    Object approve(@PathVariable long approvalId,@RequestBody Map<String,Object>b,HttpServletRequest r){
        require(r,"管理员","店长");Map<String,Object>a;try{a=db.queryForMap("select * from operation_approvals where id=? and status='待审批' and deleted=0",approvalId);}catch(Exception e){return fail("审批单不存在或已处理");}
        String type=text(a.get("action_type"));Map<String,Object>payload=object(text(a.get("payload_json")));Object execution="审批通过";
        if("退款".equals(type)){execution=v23.refundItems(((Number)a.get("order_id")).longValue(),payload,r);if(!Boolean.TRUE.equals(((Map<?,?>)execution).get("success")))return execution;}
        if("反结账".equals(type)){long orderId=((Number)a.get("order_id")).longValue();List<Map<String,Object>> items=db.queryForList("select oi.id orderItemId,oi.quantity,oi.received amount,case when oi.item_type='PRODUCT' then 1 else 0 end restock from order_items oi where oi.order_id=? and oi.deleted=0",orderId);Map<String,Object>refund=new LinkedHashMap<>();refund.put("clientRequestId","REVERSE-"+approvalId);refund.put("items",items);refund.put("reason","反结账："+text(a.get("reason")));refund.put("externalRefundConfirmed",Boolean.parseBoolean(text(payload.getOrDefault("externalRefundConfirmed",false))));execution=v23.refundItems(orderId,refund,r);if(!Boolean.TRUE.equals(((Map<?,?>)execution).get("success")))return execution;String n=now();db.update("update orders set status='已反结账',reversed_at=?,reversed_by=?,reverse_reason=?,approval_id=?,updated_at=? where id=?",n,uid(r),a.get("reason"),approvalId,n,orderId);}
        String n=now();db.update("update operation_approvals set status='已通过',approved_by=?,decision_remark=?,executed_at=?,updated_at=? where id=?",uid(r),text(b.get("remark")),n,n,approvalId);if("改价".equals(type)){Object approvedItems=payload.get("items");if(approvedItems instanceof List<?>)db.update("update service_tickets set items_json=?,price_approval_id=?,updated_at=? where id=?",stringify(approvedItems),approvalId,n,a.get("ticket_id"));else db.update("update service_tickets set price_approval_id=?,updated_at=? where id=?",approvalId,n,a.get("ticket_id"));}log(r,"审批处理","通过并执行"+type+"审批#"+approvalId);return ok(execution);
    }

    @GetMapping("/risks") Object risks(HttpServletRequest r){require(r,"管理员","店长");refreshRisks();return ok(db.queryForList("select e.*,u.name handler_name from risk_events e left join users u on u.id=e.handled_by where e.deleted=0 order by case e.status when '待处理' then 0 else 1 end,e.detected_at desc limit 300"));}
    @PutMapping("/risks/{riskId}/handle") Object handleRisk(@PathVariable long riskId,@RequestBody Map<String,Object>b,HttpServletRequest r){require(r,"管理员","店长");String remark=text(b.get("remark"));if(remark.length()<2)return fail("请填写处理结果");String n=now();db.update("update risk_events set status='已处理',handled_by=?,handled_at=?,remark=?,updated_at=? where id=?",uid(r),n,remark,n,riskId);log(r,"异常处理","处理异常#"+riskId+"："+remark);return ok("异常已处理并留痕");}

    @GetMapping("/reminders") Object reminders(HttpServletRequest r){require(r,"管理员","店长","前台","技师");String dormant=LocalDate.now().minusDays(settings.integer("dormant_customer_days",60)).toString(),expiry=LocalDate.now().plusDays(settings.integer("card_expiry_notice_days",30)).toString(),today=LocalDate.now().toString();Map<String,Object>out=new LinkedHashMap<>();out.put("dormant",db.queryForList("select id,name,phone,last_visit,visit_count,total_spent from customers where deleted=0 and (last_visit is null or substr(last_visit,1,10)<=?) order by total_spent desc limit 200",dormant));out.put("expiringCards",db.queryForList("select p.*,c.name customer_name,c.phone from packages p join customers c on c.id=p.customer_id where p.deleted=0 and p.status='正常' and (coalesce(p.card_mode,'COUNT')='TERM' or p.total_times>p.used_times) and p.expires_at is not null and p.expires_at<>'' and substr(p.expires_at,1,10)<=? order by p.expires_at limit 200",expiry));out.put("overdueFollowups",db.queryForList("select f.*,c.name customer_name,c.phone,e.name employee_name from followups f join customers c on c.id=f.customer_id left join employees e on e.id=f.employee_id where f.deleted=0 and f.status='待回访' and substr(f.plan_date,1,10)<=? order by f.plan_date limit 300",today));return ok(out);}
    @PostMapping("/reminders/followup") Object reminderFollowup(@RequestBody Map<String,Object>b,HttpServletRequest r){require(r,"管理员","店长","前台","技师");long customerId=Long.parseLong(text(b.get("customerId")));String sourceKey=text(b.get("sourceKey"));if(!sourceKey.isBlank()&&db.queryForObject("select count(*) from followups where source_key=? and deleted=0 and status='待回访'",Integer.class,sourceKey)>0)return ok("该提醒已生成待回访任务");String n=now();db.update("insert into followups(customer_id,plan_date,employee_id,method,status,remark,source_type,source_id,source_key,created_at,updated_at,deleted) values(?,?,?,'电话','待回访',?,?,?,?,?,?,0)",customerId,b.getOrDefault("planDate",LocalDate.now().toString()),b.get("employeeId"),text(b.get("remark")),text(b.get("sourceType")),b.get("sourceId"),sourceKey,n,n);log(r,"经营提醒","为顾客ID "+customerId+"创建回访任务");return ok("待回访任务已创建");}

    private long insertTicket(Long appointmentId,Long customerId,Long employeeId,Long workstationId,Object items,String remark,long userId){String n=now(),no="FW"+System.currentTimeMillis();db.update("insert into service_tickets(ticket_no,appointment_id,customer_id,employee_id,workstation_id,items_json,status,remark,created_by,created_at,updated_at,deleted) values(?,?,?,?,?,?,'待服务',?,?,?,?,0)",no,appointmentId,customerId,employeeId,workstationId,stringify(items),remark,userId,n,n);return DbCompat.lastInsertId(db);}
    private Map<String,Object> findTicket(long ticketId){try{return db.queryForMap("select * from service_tickets where id=? and deleted=0",ticketId);}catch(Exception e){throw new IllegalArgumentException("服务单不存在");}}
    private List<Map<String,Object>> parseList(String value){try{return json.readValue(value,new TypeReference<>(){});}catch(Exception e){return new ArrayList<>();}}
    private void syncBusy(Map<String,Object>t,long ticketId,String n,long userId){if(t.get("workstation_id")!=null)db.update("update workstations set status='使用中',current_ticket_id=?,updated_at=? where id=?",ticketId,n,t.get("workstation_id"));if(t.get("employee_id")!=null){int c=db.update("update employee_states set work_status='服务中',workstation_id=?,current_ticket_id=?,updated_by=?,updated_at=? where employee_id=? and deleted=0",t.get("workstation_id"),ticketId,userId,n,t.get("employee_id"));if(c==0)db.update("insert into employee_states(employee_id,work_status,queue_type,queue_no,workstation_id,current_ticket_id,updated_by,created_at,updated_at,deleted) values(?,'服务中','轮钟',0,?,?,?,?,?,0)",t.get("employee_id"),t.get("workstation_id"),ticketId,userId,n,n);}}
    private void releaseBusy(Map<String,Object>t,String n,long userId,boolean cleaning){if(t.get("workstation_id")!=null)db.update("update workstations set status=?,current_ticket_id=null,updated_at=? where id=?",cleaning?"待清洁":"空闲",n,t.get("workstation_id"));if(t.get("employee_id")!=null)db.update("update employee_states set work_status='候钟',workstation_id=null,current_ticket_id=null,updated_by=?,updated_at=? where employee_id=?",userId,n,t.get("employee_id"));}
    private void refreshRisks(){String seven=LocalDateTime.now().minusDays(7).toString();int refundCount=settings.integer("frequent_refund_count",2);for(Map<String,Object>row:db.queryForList("select order_id,count(*) cnt,sum(amount) amount from refunds where deleted=0 and created_at>=? group by order_id having count(*)>=?",seven,refundCount))addRisk("REFUND-"+row.get("order_id")+"-"+LocalDate.now(),"频繁退款","高","订单",id(row.get("order_id")),"同一订单频繁退款","7日内退款"+row.get("cnt")+"次，合计"+row.get("amount"));for(Map<String,Object>row:db.queryForList("select id,order_no,price_change_reason,created_at from orders where deleted=0 and discount>0 and created_at>=?",seven))addRisk("PRICE-"+row.get("id"),"异常改价","中","订单",id(row.get("id")),"订单存在人工改价",row.get("order_no")+"；"+text(row.get("price_change_reason")));for(Map<String,Object>row:db.queryForList("select id,name,quantity,min_quantity from inventory where deleted=0 and quantity<=min_quantity"))addRisk("STOCK-"+row.get("id")+"-"+row.get("quantity"),"库存异常",new BigDecimal(text(row.get("quantity"))).signum()<0?"高":"中","库存",id(row.get("id")),"库存低于预警线",row.get("name")+" 当前"+row.get("quantity")+"，预警"+row.get("min_quantity"));LocalTime start=LocalTime.parse(settings.get("night_start","23:00")),end=LocalTime.parse(settings.get("night_end","06:00"));for(Map<String,Object>row:db.queryForList("select id,type,content,created_at from audit_logs where created_at>=? order by id desc limit 500",seven)){try{LocalTime time=LocalDateTime.parse(text(row.get("created_at"))).toLocalTime();boolean night=start.isAfter(end)?time.isAfter(start)||time.isBefore(end):!time.isBefore(start)&&time.isBefore(end);if(night)addRisk("NIGHT-"+row.get("id"),"深夜操作","中","日志",id(row.get("id")),"非营业时段关键操作",row.get("type")+"："+row.get("content")+"（"+row.get("created_at")+"）");}catch(Exception ignored){}}}
    private void addRisk(String key,String type,String severity,String relatedType,Long relatedId,String title,String detail){Integer count=db.queryForObject("select count(*) from risk_events where event_key=? and deleted=0",Integer.class,key);if(count!=null&&count>0)return;String n=now();db.update("insert into risk_events(event_key,event_type,severity,related_type,related_id,title,detail,status,detected_at,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,'待处理',?,?,?,0)",key,type,severity,relatedType,relatedId,title,detail,n,n,n);}
}

@RestController
class PublicBrandingApi {
    private final JdbcTemplate db;
    PublicBrandingApi(JdbcTemplate db){this.db=db;}
    @GetMapping("/api/public/branding") Object branding(){Map<String,String>out=new LinkedHashMap<>();for(Map<String,Object>r:db.queryForList(DbCompat.isMySql(db)?"select `key`,value from settings where deleted=0 and `key` in ('system_name','brand_logo','store_name')":"select key,value from settings where deleted=0 and key in ('system_name','brand_logo','store_name')"))out.put(String.valueOf(r.get("key")),Objects.toString(r.get("value"),""));out.putIfAbsent("system_name","齐沐堂门店管理系统");out.putIfAbsent("brand_logo","/qimutang-logo.png");return Map.of("success",true,"data",out);}
}
