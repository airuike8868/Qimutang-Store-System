package com.qimutang;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ConnectionCallback;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;

/**
 * Small database compatibility layer used by the local SQLite edition and the MySQL 8 edition.
 * Business SQL should stay portable; only unavoidable dialect differences live here.
 */
final class DbCompat {
    private DbCompat() {}

    static boolean isMySql(JdbcTemplate db) {
        try {
            return Boolean.TRUE.equals(db.execute((ConnectionCallback<Boolean>) connection -> {
                String name = connection.getMetaData().getDatabaseProductName();
                return name != null && name.toLowerCase(Locale.ROOT).contains("mysql");
            }));
        } catch (Exception ignored) {
            return false;
        }
    }

    static long lastInsertId(JdbcTemplate db) {
        String sql = isMySql(db) ? "select last_insert_id()" : "select last_insert_rowid()";
        Long id = db.queryForObject(sql, Long.class);
        if (id == null) throw new IllegalStateException("无法读取新增记录ID");
        return id;
    }

    static void ensureColumn(JdbcTemplate db, String table, String column, String definition) {
        if (columnExists(db, table, column)) return;
        db.execute("alter table " + table + " add column " + column + " " + mysqlType(definition, isMySql(db)));
    }

    static boolean columnExists(JdbcTemplate db, String table, String column) {
        try {
            return Boolean.TRUE.equals(db.execute((ConnectionCallback<Boolean>) connection -> {
                DatabaseMetaData meta = connection.getMetaData();
                try (ResultSet rs = meta.getColumns(connection.getCatalog(), null, table, column)) {
                    if (rs.next()) return true;
                }
                try (ResultSet rs = meta.getColumns(connection.getCatalog(), null,
                        table.toUpperCase(Locale.ROOT), column.toUpperCase(Locale.ROOT))) {
                    return rs.next();
                }
            }));
        } catch (Exception e) {
            throw new IllegalStateException("读取数据库字段失败: " + table + "." + column, e);
        }
    }

    static boolean indexExists(JdbcTemplate db, String table, String indexName) {
        try {
            return Boolean.TRUE.equals(db.execute((ConnectionCallback<Boolean>) connection -> {
                DatabaseMetaData meta = connection.getMetaData();
                try (ResultSet rs = meta.getIndexInfo(connection.getCatalog(), null, table, false, false)) {
                    while (rs.next()) {
                        String name = rs.getString("INDEX_NAME");
                        if (indexName.equalsIgnoreCase(name)) return true;
                    }
                }
                return false;
            }));
        } catch (Exception e) {
            throw new IllegalStateException("读取数据库索引失败: " + indexName, e);
        }
    }

    static void createIndexIfMissing(JdbcTemplate db, String table, String indexName, String columns, boolean unique) {
        if (indexExists(db, table, indexName)) return;
        db.execute("create " + (unique ? "unique " : "") + "index " + indexName + " on " + table + "(" + columns + ")");
    }

    static void upsertSetting(JdbcTemplate db, String key, String value, String description, String now) {
        if (isMySql(db)) {
            db.update("insert into settings(`key`,value,description,created_at,updated_at,deleted) values(?,?,?,?,?,0) " +
                            "on duplicate key update value=values(value),description=values(description),updated_at=values(updated_at),deleted=0",
                    key, value, description, now, now);
        } else {
            db.update("insert into settings(key,value,description,created_at,updated_at,deleted) values(?,?,?,?,?,0) " +
                            "on conflict(key) do update set value=excluded.value,description=excluded.description,updated_at=excluded.updated_at,deleted=0",
                    key, value, description, now, now);
        }
    }

    static void insertSettingIfMissing(JdbcTemplate db, String key, String value, String description, String now) {
        if (isMySql(db)) {
            db.update("insert ignore into settings(`key`,value,description,created_at,updated_at,deleted) values(?,?,?,?,?,0)",
                    key, value, description, now, now);
        } else {
            db.update("insert or ignore into settings(key,value,description,created_at,updated_at,deleted) values(?,?,?,?,?,0)",
                    key, value, description, now, now);
        }
    }

    static void insertCategoryIfMissing(JdbcTemplate db, String type, String name, int sort, String now) {
        if (isMySql(db)) {
            db.update("insert ignore into categories(type,name,sort_order,created_at,updated_at) values(?,?,?,?,?)",
                    type, name, sort, now, now);
        } else {
            db.update("insert or ignore into categories(type,name,sort_order,created_at,updated_at) values(?,?,?,?,?)",
                    type, name, sort, now, now);
        }
    }

    static String mysqlType(String definition, boolean mysql) {
        if (!mysql) return definition;
        String out = definition;
        out = out.replaceAll("(?i)\\binteger\\b", "bigint");
        out = out.replaceAll("(?i)\\bdecimal\\b", "decimal(18,2)");
        out = out.replaceAll("(?i)\\btext\\s+not\\s+null\\s+default\\s+'([^']*)'", "varchar(255) not null default '$1'");
        out = out.replaceAll("(?i)\\btext default '([^']*)'", "varchar(255) default '$1'");
        if (out.trim().equalsIgnoreCase("text")) out = "varchar(255)";
        return out;
    }

    static String mysqlDdl(String sql) {
        String out = sql.replace("integer primary key autoincrement", "bigint primary key auto_increment");
        out = out.replaceAll("(?i)\\bdecimal\\b(?!\\s*\\()", "decimal(18,2)");
        out = out.replaceAll("(?i)\\bkey\\s+text\\s+unique\\b", "`key` varchar(191) unique");
        out = out.replaceAll("(?i)\\btext\\s+unique\\s+not\\s+null\\b", "varchar(191) unique not null");
        out = out.replaceAll("(?i)\\btext\\s+unique\\b", "varchar(191) unique");
        out = out.replaceAll("(?i)\\btext\\s+not\\s+null\\s+default\\s+'([^']*)'", "varchar(255) not null default '$1'");
        out = out.replaceAll("(?i)\\btext\\s+default\\s+'([^']*)'", "varchar(255) default '$1'");
        return out;
    }
}
