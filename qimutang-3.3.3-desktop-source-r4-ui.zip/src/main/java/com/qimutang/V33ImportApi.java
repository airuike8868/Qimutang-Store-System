package com.qimutang;

import jakarta.servlet.http.HttpServletRequest;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

@RestController
@RequestMapping("/api/v33/import")
class V33ImportApi {
    private final JdbcTemplate db;
    V33ImportApi(JdbcTemplate db){this.db=db;}
    private Map<String,Object>ok(Object v){return Map.of("success",true,"data",v);}private Map<String,Object>fail(String v){return Map.of("success",false,"message",v);}
    private String text(Object v){return Objects.toString(v,"").trim();}private long uid(HttpServletRequest r){return((Number)r.getAttribute("userId")).longValue();}
    private void require(HttpServletRequest r){String role=Objects.toString(r.getAttribute("role"),"");if(!List.of("管理员","店长").contains(role))throw new IllegalArgumentException("当前账号没有数据导入权限");}

    @PostMapping("/preview")
    Object preview(@RequestParam String type,@RequestParam("file")MultipartFile file,HttpServletRequest r)throws Exception{
        require(r);String selected=type.toLowerCase(Locale.ROOT);if(!List.of("customers","services","inventory").contains(selected))return fail("导入类型不正确");if(file.isEmpty()||file.getSize()>10L*1024*1024)return fail("请选择不超过10MB的Excel或CSV文件");
        List<Map<String,String>>rows=parse(file);if(rows.size()>5000)return fail("单次最多导入5000行，请拆分文件");List<Map<String,Object>>preview=new ArrayList<>();int errors=0;for(int i=0;i<rows.size();i++){Map<String,String>row=rows.get(i);List<String>rowErrors=validate(selected,row);if(!rowErrors.isEmpty())errors++;Map<String,Object>item=new LinkedHashMap<>();item.put("rowNumber",i+2);item.put("values",row);item.put("errors",rowErrors);preview.add(item);}return ok(Map.of("type",selected,"fileName",Objects.toString(file.getOriginalFilename(),""),"totalRows",rows.size(),"errorRows",errors,"rows",preview));
    }

    @PostMapping("/commit")
    @Transactional
    Object commit(@RequestBody Map<String,Object>body,HttpServletRequest r)throws Exception{
        require(r);String type=text(body.get("type")).toLowerCase(Locale.ROOT);if(!List.of("customers","services","inventory").contains(type))return fail("导入类型不正确");Object raw=body.get("rows");if(!(raw instanceof List<?>rows)||rows.isEmpty())return fail("没有可导入的数据");if(rows.size()>5000)return fail("单次最多导入5000行");int success=0,failed=0;List<String>errors=new ArrayList<>();String n=LocalDateTime.now().toString();
        for(int i=0;i<rows.size();i++){
            Object item=rows.get(i);Map<?,?>values=null;
            if(item instanceof Map<?,?>itemMap){Object nested=itemMap.get("values");values=nested instanceof Map<?,?>nestedMap?nestedMap:itemMap;}
            if(values==null){failed++;errors.add("第"+(i+2)+"行格式不正确");continue;}Map<String,String>row=new LinkedHashMap<>();values.forEach((k,v)->row.put(text(k),text(v)));List<String>problems=validate(type,row);if(!problems.isEmpty()){failed++;errors.add("第"+(i+2)+"行："+String.join("、",problems));continue;}
            try{if("customers".equals(type))insertCustomer(row,n);else if("services".equals(type))insertService(row,n);else insertInventory(row,n);success++;}catch(Exception e){failed++;errors.add("第"+(i+2)+"行：数据重复或格式不正确");}
        }
        db.update("insert into import_jobs(import_type,file_name,total_rows,success_rows,failed_rows,error_json,status,operator_id,created_at,updated_at,deleted) values(?,?,?,?,?,?,?, ?,?,?,0)",type,text(body.get("fileName")),rows.size(),success,failed,String.join("\n",errors),failed==0?"全部成功":"部分成功",uid(r),n,n);
        db.update("insert into audit_logs(user_id,type,content,ip,created_at,updated_at) values(?,?,?,?,?,?)",uid(r),"数据导入",type+"：成功"+success+"行，失败"+failed+"行",r.getRemoteAddr(),n,n);return ok(Map.of("successRows",success,"failedRows",failed,"errors",errors.stream().limit(100).toList()));
    }

    private List<Map<String,String>>parse(MultipartFile file)throws Exception{String name=Objects.toString(file.getOriginalFilename(),"").toLowerCase(Locale.ROOT);return name.endsWith(".csv")?parseCsv(file.getBytes()):parseXlsx(file.getBytes());}
    private List<Map<String,String>>parseXlsx(byte[]bytes)throws Exception{List<Map<String,String>>out=new ArrayList<>();DataFormatter formatter=new DataFormatter(Locale.CHINA);try(Workbook workbook=WorkbookFactory.create(new ByteArrayInputStream(bytes))){Sheet sheet=workbook.getSheetAt(0);if(sheet.getPhysicalNumberOfRows()==0)return out;Row header=sheet.getRow(sheet.getFirstRowNum());List<String>headers=new ArrayList<>();for(Cell cell:header)headers.add(formatter.formatCellValue(cell).trim());for(int index=header.getRowNum()+1;index<=sheet.getLastRowNum();index++){Row row=sheet.getRow(index);if(row==null)continue;Map<String,String>item=new LinkedHashMap<>();boolean any=false;for(int c=0;c<headers.size();c++){Cell cell=row.getCell(c,Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);String value=cell==null?"":formatter.formatCellValue(cell).trim();if(!value.isBlank())any=true;item.put(headers.get(c),value);}if(any)out.add(item);}}return out;}
    private List<Map<String,String>>parseCsv(byte[]bytes){String content=new String(bytes,StandardCharsets.UTF_8);if(content.startsWith("\uFEFF"))content=content.substring(1);String[]lines=content.split("\\R");if(lines.length==0)return List.of();List<String>headers=csvLine(lines[0]);List<Map<String,String>>out=new ArrayList<>();for(int i=1;i<lines.length;i++){if(lines[i].isBlank())continue;List<String>values=csvLine(lines[i]);Map<String,String>row=new LinkedHashMap<>();for(int c=0;c<headers.size();c++)row.put(headers.get(c).trim(),c<values.size()?values.get(c).trim():"");out.add(row);}return out;}
    private List<String>csvLine(String line){List<String>out=new ArrayList<>();StringBuilder current=new StringBuilder();boolean quoted=false;for(int i=0;i<line.length();i++){char ch=line.charAt(i);if(ch=='"'){if(quoted&&i+1<line.length()&&line.charAt(i+1)=='"'){current.append('"');i++;}else quoted=!quoted;}else if(ch==','&&!quoted){out.add(current.toString());current.setLength(0);}else current.append(ch);}out.add(current.toString());return out;}
    private List<String>validate(String type,Map<String,String>row){List<String>errors=new ArrayList<>();if("customers".equals(type)){if(value(row,"姓名","name").isBlank())errors.add("姓名不能为空");String phone=value(row,"手机号","phone");if(!phone.matches("[0-9+ -]{6,20}"))errors.add("手机号格式不正确");}else if("services".equals(type)){if(value(row,"项目名称","name").isBlank())errors.add("项目名称不能为空");if(!number(value(row,"门市价","list_price")))errors.add("门市价格式不正确");}else{if(value(row,"产品名称","name").isBlank())errors.add("产品名称不能为空");if(!number(value(row,"库存数量","quantity")))errors.add("库存数量格式不正确");}return errors;}
    private String value(Map<String,String>row,String...keys){for(String key:keys)if(row.containsKey(key))return text(row.get(key));return"";}private boolean number(String value){try{new java.math.BigDecimal(value);return true;}catch(Exception e){return false;}}
    private void insertCustomer(Map<String,String>row,String n){String phone=value(row,"手机号","phone");if(db.queryForObject("select count(*) from customers where phone=? and deleted=0",Integer.class,phone)>0)throw new IllegalArgumentException();db.update("insert into customers(name,phone,gender,source,address,member_no,first_visit,last_visit,remark,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,?,0)",value(row,"姓名","name"),phone,value(row,"性别","gender"),value(row,"来源","source"),value(row,"地址","address"),"QM"+System.currentTimeMillis()+new java.util.Random().nextInt(100),n,n,value(row,"备注","remark"),n,n);}
    private void insertService(Map<String,String>row,String n){String name=value(row,"项目名称","name"),category=value(row,"分类","category");java.math.BigDecimal price=new java.math.BigDecimal(value(row,"门市价","list_price"));String member=value(row,"会员价","member_price");java.math.BigDecimal memberPrice=member.isBlank()?price:new java.math.BigDecimal(member);int duration;try{duration=Integer.parseInt(value(row,"时长","duration"));}catch(Exception e){duration=60;}db.update("insert into services(name,category,duration,list_price,member_price,commission_type,commission_value,status,group_buy,remark,created_at,updated_at,deleted) values(?,?,?,?,?,'FIXED',0,1,0,?,?,?,0)",name,category.isBlank()?"其他":category,duration,price,memberPrice,value(row,"备注","remark"),n,n);}
    private void insertInventory(Map<String,String>row,String n){String name=value(row,"产品名称","name"),category=value(row,"分类","category"),unit=value(row,"单位","unit");java.math.BigDecimal quantity=new java.math.BigDecimal(value(row,"库存数量","quantity"));java.math.BigDecimal cost=decimalOrZero(value(row,"成本价","cost_price"));java.math.BigDecimal retail=decimalOrZero(value(row,"零售价","retail_price"));db.update("insert into inventory(name,category,quantity,unit,cost_price,min_quantity,supplier,barcode,retail_price,member_price,retail_enabled,product_type,created_at,updated_at,deleted) values(?,?,?,?,?,5,?,?,?, ?,?,'护理产品',?,?,0)",name,category.isBlank()?"其他":category,quantity,unit.isBlank()?"件":unit,cost,value(row,"供应商","supplier"),value(row,"条码","barcode"),retail,retail,retail.signum()>0?1:0,n,n);}
    private java.math.BigDecimal decimalOrZero(String value){return value.isBlank()?java.math.BigDecimal.ZERO:new java.math.BigDecimal(value);}
}
