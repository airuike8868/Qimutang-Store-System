package com.qimutang;

import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.DependsOn;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

/** 3.3.3 齐沐堂收费表：服务、护理产品和会员卡的幂等初始化模板。 */
@Component
@DependsOn("v33Migration")
class V333CatalogMigration {
    private final JdbcTemplate db;

    V333CatalogMigration(JdbcTemplate db) { this.db = db; }

    @PostConstruct
    void migrate() {
        seedCategories();
        upgradeOriginalDefaults();
        seedServices();
        seedProducts();
        seedCardTemplates();
        DbCompat.upsertSetting(db, "app_version", "3.3.3", "系统版本", LocalDateTime.now().toString());
    }

    private void seedCategories() {
        String now = LocalDateTime.now().toString();
        DbCompat.insertCategoryIfMissing(db, "SERVICE", "基础修脚", 10, now);
        DbCompat.insertCategoryIfMissing(db, "SERVICE", "灰甲护理", 20, now);
        DbCompat.insertCategoryIfMissing(db, "SERVICE", "甲沟炎护理", 30, now);
        DbCompat.insertCategoryIfMissing(db, "SERVICE", "嵌甲矫正", 40, now);
        DbCompat.insertCategoryIfMissing(db, "SERVICE", "脚钉/鸡眼/跖疣护理", 50, now);
        DbCompat.insertCategoryIfMissing(db, "PRODUCT", "皮肤护理", 10, now);
        DbCompat.insertCategoryIfMissing(db, "PRODUCT", "抑菌护理", 20, now);
        DbCompat.insertCategoryIfMissing(db, "PRODUCT", "矫正器具", 30, now);
        DbCompat.insertCategoryIfMissing(db, "PRODUCT", "鞋袜护理", 40, now);
        DbCompat.insertCategoryIfMissing(db, "PRODUCT", "清洁护理", 50, now);
    }

    private void upgradeOriginalDefaults() {
        updateDefault("招牌修脚", "招牌修脚", "修脚", "59.9", "基础修脚", "49.9", "35", 40, "次", false, 0);
        updateDefault("轻度单侧甲沟炎护理", "初期甲沟炎护理（单侧）", "甲沟炎", "130", "甲沟炎护理", "129", "65", 45, "单侧", true, 7);
        updateDefault("单侧嵌甲护理", "嵌甲精修", "嵌甲", "70", "基础修脚", "69.9", "45", 40, "单侧", true, 7);
    }

    private void updateDefault(String oldName, String newName, String oldCategory, String oldPrice,
                               String category, String price, String memberPrice, int duration,
                               String unit, boolean care, int followupDays) {
        if (!oldName.equals(newName) && exists("services", newName)) return;
        long categoryId = categoryId("SERVICE", category);
        db.update("update services set name=?,category=?,category_id=?,duration=?,list_price=?,member_price=?," +
                        "service_type=?,unit=?,care_record_required=?,photo_required=0,followup_days=?,updated_at=? " +
                        "where name=? and category=? and list_price=? and deleted=0",
                newName, category, categoryId, duration, bd(price), bd(memberPrice), care ? "护理服务" : "普通服务",
                unit, care ? 1 : 0, followupDays, LocalDateTime.now().toString(), oldName, oldCategory, bd(oldPrice));
    }

    private void seedServices() {
        service("招牌修脚", "基础修脚", 40, "49.9", "35", "次", false, 0, "基础修脚护理");
        service("匠心修脚", "基础修脚", 50, "69.9", "45", "次", false, 0, "精细修脚护理");
        service("灰甲精修", "灰甲护理", 60, "89.9", "55", "次", true, 30, "灰甲、厚甲精细修护");
        service("嵌甲精修", "基础修脚", 40, "69.9", "45", "单侧", true, 7, "嵌甲甲缘精细修护");

        service("初期甲沟炎护理（单侧）", "甲沟炎护理", 45, "129", "65", "单侧", true, 7, "初期甲沟炎护理");
        service("中期甲沟炎护理（单侧）", "甲沟炎护理", 60, "200", "100", "单侧", true, 7, "中期甲沟炎护理");
        service("重度甲沟炎护理（基础）", "甲沟炎护理", 75, "300", "150", "单侧", true, 7, "重度护理基础档，开单前确认实际情况");
        service("重度甲沟炎护理（复杂）", "甲沟炎护理", 90, "500", "250", "单侧", true, 7, "重度护理复杂档，开单前确认实际情况");
        service("甲沟炎舒缓护理", "甲沟炎护理", 30, "39", "39", "次", true, 7, "辅助舒缓护理");

        service("嵌甲单次矫正（单侧）", "嵌甲矫正", 60, "350", "350", "单侧", true, 14, "单次嵌甲矫正服务");
        service("嵌甲轻度矫正套餐（单侧）", "嵌甲矫正", 60, "1580", "1580", "套", true, 14, "疗程方案需根据实际情况确认");
        service("嵌甲中度矫正套餐（单侧）", "嵌甲矫正", 75, "1980", "1980", "套", true, 14, "疗程方案需根据实际情况确认");
        service("嵌甲重度矫正套餐（单侧）", "嵌甲矫正", 90, "2480", "2480", "套", true, 14, "疗程方案需根据实际情况确认");
        service("嵌甲综合矫正套餐（单侧起）", "嵌甲矫正", 90, "2980", "2980", "套", true, 14, "2980元/侧起，开单前确认方案");

        service("脚钉/鸡眼/跖疣单个护理（＜0.5cm）", "脚钉/鸡眼/跖疣护理", 40, "300", "300", "个", true, 14, "单个护理，直径小于0.5cm");
        service("脚钉/鸡眼/跖疣单个护理（0.5–1cm）", "脚钉/鸡眼/跖疣护理", 50, "600", "600", "个", true, 14, "单个护理，直径0.5至1cm");
        service("脚钉/鸡眼/跖疣单个护理（＞1cm）", "脚钉/鸡眼/跖疣护理", 60, "800", "800", "个", true, 14, "单个护理，直径大于1cm");
        service("群发性护理（范围≤3×3cm）", "脚钉/鸡眼/跖疣护理", 60, "1000", "1000", "次", true, 14, "群发范围不超过3×3cm");
        service("群发性护理（3×3至5×5cm）", "脚钉/鸡眼/跖疣护理", 75, "2000", "2000", "次", true, 14, "群发范围大于3×3cm且不超过5×5cm");
        service("群发性护理（5×5至10×10cm）", "脚钉/鸡眼/跖疣护理", 90, "3000", "3000", "次", true, 14, "群发范围大于5×5cm且不超过10×10cm");
        service("群发性护理（范围＞10×10cm）", "脚钉/鸡眼/跖疣护理", 120, "5000", "5000", "次", true, 14, "群发范围大于10×10cm");
    }

    private void service(String name, String category, int duration, String price, String memberPrice,
                         String unit, boolean care, int followupDays, String remark) {
        if (exists("services", name)) return;
        String now = LocalDateTime.now().toString();
        db.update("insert into services(name,category,category_id,duration,list_price,member_price,commission_type," +
                        "commission_value,status,service_type,unit,min_price,care_record_required,photo_required," +
                        "followup_days,remark,created_at,updated_at,deleted) values(?,?,?,?,?,?,'FIXED',0,1,?,?,?,?,0,?,?,?, ?,0)",
                name, category, categoryId("SERVICE", category), duration, bd(price), bd(memberPrice),
                name.contains("套餐") ? "组合套餐" : (care ? "护理服务" : "普通服务"), unit, BigDecimal.ZERO,
                care ? 1 : 0, followupDays, remark, now, now);
    }

    private void seedProducts() {
        product("鲁夫堂皮肤抑菌组合", "皮肤护理", "278", "盒");
        product("鲁夫堂草本抑菌膏", "皮肤护理", "118", "盒");
        product("皮肤抑菌液（蓝标）", "抑菌护理", "480", "盒");
        product("皮肤抑菌液（绿标）", "抑菌护理", "360", "盒");
        product("鲁夫堂抑菌液喷剂", "抑菌护理", "100", "盒");
        product("鲁夫堂菌克止痒膏", "皮肤护理", "89", "盒");
        product("手足固定器私人专属", "矫正器具", "1198", "套");
        product("手足固定器体验装", "矫正器具", "598", "套");
        product("手足固定器", "矫正器具", "350", "个");
        product("百清鞋袜喷剂", "鞋袜护理", "89", "盒");
        product("抑菌凝胶", "抑菌护理", "198", "盒");
        product("臭氧抑菌精油", "抑菌护理", "198", "盒");
        product("魔术笔", "皮肤护理", "138", "盒");
        product("抑菌散", "抑菌护理", "120", "盒");
        product("山参液", "皮肤护理", "39", "袋");
        product("泡泡净", "清洁护理", "128", "盒");
    }

    private void product(String name, String category, String price, String unit) {
        if (exists("inventory", name)) return;
        String now = LocalDateTime.now().toString();
        db.update("insert into inventory(name,category,category_id,quantity,unit,cost_price,min_quantity,supplier," +
                        "barcode,retail_price,member_price,retail_enabled,product_type,commission_type,commission_value," +
                        "created_at,updated_at,deleted) values(?,?,?,0,?,0,5,'鲁夫堂',null,?,?,1,'护理产品','FIXED',0,?,?,0)",
                name, category, categoryId("PRODUCT", category), unit, bd(price), bd(price), now, now);
    }

    private void seedCardTemplates() {
        card("灰甲季度护理卡", "时效卡", "灰甲精修", 0, "200", 90, "TERM", 1, "季度内护理及跟踪服务");
        card("灰甲年度护理卡", "时效卡", "灰甲精修", 0, "688", 365, "TERM", 1, "年度内护理及跟踪服务");
        card("嵌甲矫正服务卡（5次）", "次卡", "嵌甲单次矫正（单侧）", 5, "145", 0, "COUNT", 1, "双脚同时矫正每次核销1次服务费");
        card("嵌甲矫正服务卡（10次）", "次卡", "嵌甲单次矫正（单侧）", 10, "290", 0, "COUNT", 1, "双脚同时矫正每次核销1次服务费");
    }

    private void card(String name, String type, String serviceName, int times, String price, int days,
                      String mode, int dailyLimit, String remark) {
        if (exists("package_templates", name)) return;
        Long serviceId = serviceId(serviceName);
        String now = LocalDateTime.now().toString();
        db.update("insert into package_templates(name,template_type,service_id,total_times,price,valid_days,status," +
                        "remark,card_mode,daily_limit,created_at,updated_at,deleted) values(?,?,?,?,?,?,1,?,?,?,?,?,0)",
                name, type, serviceId, times, bd(price), days, remark, mode, dailyLimit, now, now);
    }

    private boolean exists(String table, String name) {
        Integer count = db.queryForObject("select count(*) from " + table + " where name=? and deleted=0", Integer.class, name);
        return count != null && count > 0;
    }

    private long categoryId(String type, String name) {
        Map<String, Object> row = db.queryForMap("select id from categories where type=? and name=? and deleted=0 order by id limit 1", type, name);
        return ((Number) row.get("id")).longValue();
    }

    private Long serviceId(String name) {
        var rows = db.queryForList("select id from services where name=? and deleted=0 order by id limit 1", name);
        return rows.isEmpty() ? null : ((Number) rows.get(0).get("id")).longValue();
    }

    private BigDecimal bd(String value) { return new BigDecimal(value); }
}
