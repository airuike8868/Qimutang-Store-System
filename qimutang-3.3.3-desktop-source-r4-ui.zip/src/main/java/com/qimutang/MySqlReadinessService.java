package com.qimutang;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.stereotype.Service;

import java.sql.DatabaseMetaData;
import java.util.*;

/** MySQL production-readiness checks used before accepting real store data. */
@Service
class MySqlReadinessService {
    private final JdbcTemplate db;
    private static final List<String> CORE_TABLES = List.of(
            "users","employees","customers","services","orders","order_items","payments",
            "refunds","commissions","inventory","inventory_logs","balance_logs","care_cases",
            "followups","appointments","finance_records","audit_logs"
    );

    MySqlReadinessService(JdbcTemplate db) { this.db = db; }

    Map<String,Object> check() throws Exception {
        Map<String,Object> r = new LinkedHashMap<>();
        boolean mysql = DbCompat.isMySql(db);
        r.put("database", mysql ? "mysql" : "sqlite");
        r.put("readyForMysqlProduction", false);
        if (!mysql) {
            r.put("message", "当前仍是 SQLite 模式；请用 mysql profile 启动后再执行正式验收");
            return r;
        }

        Map<String,Object> meta = db.execute((ConnectionCallback<Map<String,Object>>) c -> {
            DatabaseMetaData m = c.getMetaData();
            Map<String,Object> x = new LinkedHashMap<>();
            x.put("product", m.getDatabaseProductName());
            x.put("version", m.getDatabaseProductVersion());
            x.put("url", maskUrl(m.getURL()));
            x.put("autoCommit", c.getAutoCommit());
            return x;
        });
        r.put("connection", meta);
        r.put("serverVersion", db.queryForObject("select version()", String.class));
        r.put("characterSet", db.queryForMap("select @@character_set_database as database_charset, @@collation_database as database_collation"));

        List<Map<String,Object>> tables = new ArrayList<>();
        boolean allPresent = true;
        for (String table : CORE_TABLES) {
            Integer exists = db.queryForObject("select count(*) from information_schema.tables where table_schema=database() and table_name=?", Integer.class, table);
            boolean present = exists != null && exists > 0;
            allPresent &= present;
            long count = present ? Optional.ofNullable(db.queryForObject("select count(*) from " + table, Long.class)).orElse(0L) : -1L;
            tables.add(Map.of("table", table, "present", present, "rows", count));
        }
        r.put("coreTables", tables);
        r.put("allCoreTablesPresent", allPresent);

        Map<String,Object> money = new LinkedHashMap<>();
        for (String spec : List.of("orders.received","order_items.received","payments.amount","refunds.amount","commissions.amount","finance_records.amount")) {
            String[] p = spec.split("\\.");
            List<Map<String,Object>> col = db.queryForList(
                    "select data_type,numeric_precision,numeric_scale from information_schema.columns where table_schema=database() and table_name=? and column_name=?",
                    p[0], p[1]);
            money.put(spec, col.isEmpty() ? Map.of("present",false) : col.get(0));
        }
        r.put("moneyColumns", money);

        boolean charsetOk = String.valueOf(((Map<?,?>)r.get("characterSet")).get("database_charset")).toLowerCase(Locale.ROOT).startsWith("utf8mb4");
        r.put("utf8mb4", charsetOk);
        r.put("readyForMysqlProduction", allPresent && charsetOk);
        r.put("message", allPresent && charsetOk ? "MySQL基础验收通过；仍需完成业务回归测试后再正式收银" : "MySQL基础验收未通过，请先修复表结构或字符集");
        return r;
    }

    Map<String,Object> migrationCounts() {
        if (!DbCompat.isMySql(db)) throw new IllegalArgumentException("当前不是 MySQL 模式");
        Map<String,Object> r = new LinkedHashMap<>();
        for (String table : CORE_TABLES) {
            try { r.put(table, db.queryForObject("select count(*) from " + table, Long.class)); }
            catch (Exception e) { r.put(table, -1); }
        }
        return r;
    }

    private static String maskUrl(String url) {
        if (url == null) return "";
        return url.replaceAll("(?i)(password=)[^&;]+", "$1***");
    }
}
