package com.qimutang;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/v25")
class V25Api {
    private final JdbcTemplate db;

    V25Api(JdbcTemplate db) { this.db = db; }

    private Map<String,Object> ok(Object data) {
        Map<String,Object> r = new LinkedHashMap<>();
        r.put("success", true); r.put("data", data); return r;
    }
    private Map<String,Object> fail(String message) { return Map.of("success", false, "message", message); }
    private String text(Object value) { return Objects.toString(value, "").trim(); }
    private String role(HttpServletRequest request) { return String.valueOf(request.getAttribute("role")); }
    private long uid(HttpServletRequest request) {
        Object value = request.getAttribute("userId");
        if (!(value instanceof Number)) throw new IllegalArgumentException("登录已失效，请重新登录");
        return ((Number)value).longValue();
    }
    private void require(HttpServletRequest request, String... roles) {
        String current = role(request);
        if (Arrays.stream(roles).noneMatch(current::equals)) throw new IllegalArgumentException("当前账号没有此操作权限");
    }
    private BigDecimal decimal(Object value, String label) {
        try {
            return new BigDecimal(String.valueOf(value == null || "".equals(value) ? 0 : value)).setScale(2, RoundingMode.HALF_UP);
        } catch (Exception e) { throw new IllegalArgumentException(label + "格式不正确"); }
    }
    private Long nullableLong(Object value) {
        if (value == null || text(value).isBlank()) return null;
        try { return Long.parseLong(text(value)); }
        catch (Exception e) { throw new IllegalArgumentException("编号格式不正确"); }
    }
    private void log(HttpServletRequest request, String type, String content) {
        String now = LocalDateTime.now().toString();
        db.update("insert into audit_logs(user_id,type,content,ip,created_at,updated_at) values(?,?,?,?,?,?)",
                uid(request), type, content, request.getRemoteAddr(), now, now);
    }

    @GetMapping("/package-templates")
    Object packageTemplates(HttpServletRequest request) {
        require(request, "管理员", "店长", "前台");
        boolean canManage = List.of("管理员", "店长").contains(role(request));
        String statusSql = canManage ? "" : " and pt.status=1";
        return ok(db.queryForList(
                "select pt.*,s.name service_name,s.category service_category from package_templates pt " +
                "left join services s on s.id=pt.service_id " +
                "where pt.deleted=0" + statusSql + " order by pt.status desc,pt.id desc"));
    }

    @PostMapping("/package-templates")
    Object createPackageTemplate(@RequestBody Map<String,Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长");
        return savePackageTemplate(null, body, request);
    }

    @PutMapping("/package-templates/{id}")
    Object updatePackageTemplate(@PathVariable long id, @RequestBody Map<String,Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长");
        return savePackageTemplate(id, body, request);
    }

    private Object savePackageTemplate(Long id, Map<String,Object> body, HttpServletRequest request) {
        String name = text(body.get("name"));
        String templateType = text(body.getOrDefault("templateType", "次卡"));
        String cardMode = text(body.getOrDefault("cardMode", "COUNT")).toUpperCase(Locale.ROOT);
        if (!Set.of("次卡", "时效卡", "组合套餐").contains(templateType) || !Set.of("COUNT", "TERM").contains(cardMode)) return fail("卡项类型不正确");
        if (name.isBlank() || name.length() > 60) return fail("请输入1至60个字的卡项名称");
        Long serviceId = nullableLong(body.get("serviceId"));
        if (serviceId != null) {
            Integer serviceCount = db.queryForObject("select count(*) from services where id=? and deleted=0 and status=1", Integer.class, serviceId);
            if (serviceCount == null || serviceCount == 0) return fail("对应服务项目不存在或已下架");
        }

        int totalTimes, validDays, dailyLimit;
        try {
            totalTimes = Integer.parseInt(text(body.getOrDefault("totalTimes", 1)));
            validDays = Integer.parseInt(text(body.getOrDefault("validDays", 0)));
            dailyLimit = Integer.parseInt(text(body.getOrDefault("dailyLimit", 1)));
        } catch (Exception e) { return fail("次数或有效期格式不正确"); }
        if (("COUNT".equals(cardMode) && (totalTimes < 1 || totalTimes > 999)) || ("TERM".equals(cardMode) && totalTimes != 0)) return fail("计次卡次数请输入1至999；时效卡应设为不限总次数");
        if (validDays < 0 || validDays > 3650) return fail("有效期请输入0至3650天");
        if ("TERM".equals(cardMode) && validDays < 1) return fail("时效卡必须设置有效天数");
        if (dailyLimit < 1 || dailyLimit > 99) return fail("每日使用上限请输入1至99次");
        BigDecimal price = decimal(body.get("price"), "售价");
        if (price.signum() <= 0) return fail("售价必须大于0");
        boolean status = Boolean.parseBoolean(String.valueOf(body.getOrDefault("status", true)));
        String now = LocalDateTime.now().toString();
        try {
            if (id == null) {
                db.update("insert into package_templates(name,template_type,service_id,total_times,price,valid_days,status,remark,card_mode,daily_limit,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,?,?,?,0)",
                        name, templateType, serviceId, totalTimes, price, validDays, status ? 1 : 0, text(body.get("remark")), cardMode, dailyLimit, now, now);
                log(request, "项目中心", "新增卡项模板：" + name);
            } else {
                Integer count = db.queryForObject("select count(*) from package_templates where id=? and deleted=0", Integer.class, id);
                if (count == null || count == 0) return fail("卡项模板不存在");
                db.update("update package_templates set name=?,template_type=?,service_id=?,total_times=?,price=?,valid_days=?,status=?,remark=?,card_mode=?,daily_limit=?,updated_at=? where id=?",
                        name, templateType, serviceId, totalTimes, price, validDays, status ? 1 : 0, text(body.get("remark")), cardMode, dailyLimit, now, id);
                log(request, "项目中心", "修改卡项模板：" + name + "，状态：" + (status ? "上架" : "停用"));
            }
        } catch (Exception e) { return fail("卡项名称已存在，请换一个名称"); }
        return ok("卡项模板已保存");
    }
}
