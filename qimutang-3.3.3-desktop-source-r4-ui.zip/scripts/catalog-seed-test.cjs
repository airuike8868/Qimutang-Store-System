#!/usr/bin/env node
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const migration=fs.readFileSync(path.join(root,'src/main/java/com/qimutang/V333CatalogMigration.java'),'utf8');
const ui=fs.readFileSync(path.join(root,'src/main/resources/static/v23-pages.js'),'utf8');
const failures=[];
const expect=(condition,message)=>{if(!condition)failures.push(message);};

const services=[
  '招牌修脚','匠心修脚','灰甲精修','嵌甲精修','初期甲沟炎护理（单侧）','中期甲沟炎护理（单侧）',
  '重度甲沟炎护理（基础）','重度甲沟炎护理（复杂）','甲沟炎舒缓护理','嵌甲单次矫正（单侧）',
  '嵌甲轻度矫正套餐（单侧）','嵌甲中度矫正套餐（单侧）','嵌甲重度矫正套餐（单侧）',
  '嵌甲综合矫正套餐（单侧起）','脚钉/鸡眼/跖疣单个护理（＜0.5cm）',
  '脚钉/鸡眼/跖疣单个护理（0.5–1cm）','脚钉/鸡眼/跖疣单个护理（＞1cm）',
  '群发性护理（范围≤3×3cm）','群发性护理（3×3至5×5cm）','群发性护理（5×5至10×10cm）',
  '群发性护理（范围＞10×10cm）'
];
const products=[
  '鲁夫堂皮肤抑菌组合','鲁夫堂草本抑菌膏','皮肤抑菌液（蓝标）','皮肤抑菌液（绿标）','鲁夫堂抑菌液喷剂',
  '鲁夫堂菌克止痒膏','手足固定器私人专属','手足固定器体验装','手足固定器','百清鞋袜喷剂','抑菌凝胶',
  '臭氧抑菌精油','魔术笔','抑菌散','山参液','泡泡净'
];
const cards=['灰甲季度护理卡','灰甲年度护理卡','嵌甲矫正服务卡（5次）','嵌甲矫正服务卡（10次）'];

services.forEach(name=>expect(migration.includes(`service("${name}"`),`缺少服务：${name}`));
products.forEach(name=>expect(migration.includes(`product("${name}"`),`缺少产品：${name}`));
cards.forEach(name=>expect(migration.includes(`card("${name}"`),`缺少会员卡：${name}`));
['200','300','500'].forEach(amount=>expect(ui.includes(`data-v23-recharge-preset="${amount}"`),`缺少${amount}元储值快捷按钮`));
expect(!migration.includes('消炎护理'),'项目名称仍包含医疗化“消炎护理”');
expect((migration.match(/\n\s*service\("/g)||[]).length===21,'服务模板数量不是21');
expect((migration.match(/\n\s*product\("/g)||[]).length===16,'产品模板数量不是16');
expect((migration.match(/\n\s*card\("/g)||[]).length===4,'会员卡模板数量不是4');
expect(migration.includes('"3.3.3"'),'升级后的数据库版本不是3.3.3');

if(failures.length){console.error(JSON.stringify({status:'failed',failures},null,2));process.exit(1);}
console.log(JSON.stringify({status:'passed',services:services.length,products:products.length,cards:cards.length,rechargePresets:3},null,2));
