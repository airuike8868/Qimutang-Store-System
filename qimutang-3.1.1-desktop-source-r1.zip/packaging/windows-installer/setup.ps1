[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

Add-Type -AssemblyName System.Windows.Forms

function Show-Info([string]$message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message,
        '齐沐堂门店管理系统',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Show-Error([string]$message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message,
        '齐沐堂门店管理系统安装失败',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Stop-InstalledApplication([string]$javawPath, [string]$dataRoot) {
    $running = @(Get-Process -Name 'javaw' -ErrorAction SilentlyContinue | Where-Object {
        try {
            $_.Path -and ([IO.Path]::GetFullPath($_.Path) -ieq [IO.Path]::GetFullPath($javawPath))
        } catch {
            $false
        }
    })
    if ($running.Count -eq 0) { return }

    New-Item -ItemType Directory -Force -Path $dataRoot | Out-Null
    New-Item -ItemType Directory -Force -Path $configRoot | Out-Null
    Set-Content -LiteralPath (Join-Path $dataRoot 'shutdown.request') -Value 'installer' -Encoding Ascii
    for ($attempt = 0; $attempt -lt 40; $attempt++) {
        Start-Sleep -Milliseconds 250
        $remaining = @($running | Where-Object { Get-Process -Id $_.Id -ErrorAction SilentlyContinue })
        if ($remaining.Count -eq 0) { return }
    }

    $choice = [System.Windows.Forms.MessageBox]::Show(
        '旧版程序未能自动退出。请确认当前没有正在收银或备份，是否强制关闭后继续安装？',
        '齐沐堂门店管理系统',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    if ($choice -ne [System.Windows.Forms.DialogResult]::Yes) {
        throw '安装已取消。请先从右下角齐沐堂托盘图标中选择“退出系统”，再重新安装。'
    }
    $running | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 800
}

function New-AppShortcut(
    [object]$shell,
    [string]$shortcutPath,
    [string]$javawPath,
    [string]$jarPath,
    [string]$installRoot,
    [string]$iconPath
) {
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $javawPath
    $shortcut.Arguments = "-Dfile.encoding=UTF-8 -jar `"$jarPath`""
    $shortcut.WorkingDirectory = $installRoot
    $shortcut.IconLocation = "$iconPath,0"
    $shortcut.Description = '齐沐堂单店本地门店管理系统'
    $shortcut.Save()
}

try {
    $payloadRoot = Join-Path $PSScriptRoot 'QimutangStore'
    $installParent = Join-Path $env:LOCALAPPDATA 'Programs'
    $installRoot = Join-Path $installParent 'QimutangStore'
    $stageRoot = "$installRoot.new-$PID"
    $oldRoot = "$installRoot.old-$(Get-Date -Format 'yyyyMMddHHmmss')"
    $dataRoot = Join-Path $env:USERPROFILE 'QimutangData\data'
    $configRoot = Join-Path $env:USERPROFILE 'QimutangData\config'
    $mysqlEnvFile = Join-Path $configRoot 'mysql.env'
    $existingJavaw = Join-Path $installRoot 'runtime\bin\javaw.exe'

    if (-not (Test-Path (Join-Path $payloadRoot 'runtime\bin\javaw.exe'))) {
        throw '安装包缺少内置 Java 17 运行环境，请重新下载安装包。'
    }
    if (-not (Test-Path (Join-Path $payloadRoot 'app\qimutang.jar'))) {
        throw '安装包缺少齐沐堂主程序，请重新下载安装包。'
    }

    Stop-InstalledApplication $existingJavaw $dataRoot
    New-Item -ItemType Directory -Force -Path $installParent | Out-Null
    New-Item -ItemType Directory -Force -Path $dataRoot | Out-Null
    New-Item -ItemType Directory -Force -Path $configRoot | Out-Null
    New-Item -ItemType Directory -Force -Path (Join-Path $dataRoot 'uploads\customer') | Out-Null
    New-Item -ItemType Directory -Force -Path (Join-Path $dataRoot 'backup') | Out-Null

    if (Test-Path $stageRoot) {
        Remove-Item -LiteralPath $stageRoot -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $stageRoot | Out-Null
    Copy-Item -Path (Join-Path $payloadRoot '*') -Destination $stageRoot -Recurse -Force

    $legacyData = Join-Path $installRoot 'data'
    if ((Test-Path $legacyData) -and -not (Test-Path (Join-Path $dataRoot 'qimutang.db'))) {
        Copy-Item -Path (Join-Path $legacyData '*') -Destination $dataRoot -Recurse -Force
    }

    if (Test-Path $installRoot) {
        Move-Item -LiteralPath $installRoot -Destination $oldRoot
    }
    try {
        Move-Item -LiteralPath $stageRoot -Destination $installRoot
    } catch {
        if ((Test-Path $oldRoot) -and -not (Test-Path $installRoot)) {
            Move-Item -LiteralPath $oldRoot -Destination $installRoot
        }
        throw
    }

    $javaw = Join-Path $installRoot 'runtime\bin\javaw.exe'
    $jar = Join-Path $installRoot 'app\qimutang.jar'
    $launcher = Join-Path $installRoot 'start-qimutang.cmd'
    $icon = Join-Path $installRoot 'qimutang.ico'
    $uninstaller = Join-Path $installRoot 'uninstall.ps1'

    $shell = New-Object -ComObject WScript.Shell
    $desktop = $shell.SpecialFolders.Item('Desktop')
    $startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\齐沐堂'
    New-Item -ItemType Directory -Force -Path $startMenu | Out-Null

    if (Test-Path $launcher) {
        foreach ($shortcutPath in @((Join-Path $desktop '齐沐堂门店管理系统.lnk'), (Join-Path $startMenu '齐沐堂门店管理系统.lnk'))) {
            $shortcut = $shell.CreateShortcut($shortcutPath)
            $shortcut.TargetPath = $launcher
            $shortcut.WorkingDirectory = $installRoot
            $shortcut.IconLocation = "$icon,0"
            $shortcut.Description = '齐沐堂门店管理系统 3.1.1 MySQL商业版'
            $shortcut.Save()
        }
    } else {
        New-AppShortcut $shell (Join-Path $desktop '齐沐堂门店管理系统.lnk') $javaw $jar $installRoot $icon
        New-AppShortcut $shell (Join-Path $startMenu '齐沐堂门店管理系统.lnk') $javaw $jar $installRoot $icon
    }

    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $uninstallShortcut = $shell.CreateShortcut((Join-Path $startMenu '卸载齐沐堂门店管理系统.lnk'))
    $uninstallShortcut.TargetPath = $powershell
    $uninstallShortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$uninstaller`""
    $uninstallShortcut.WorkingDirectory = $installRoot
    $uninstallShortcut.IconLocation = "$icon,0"
    $uninstallShortcut.Save()

    $uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\QimutangStore'
    New-Item -Path $uninstallKey -Force | Out-Null
    $estimatedSize = [int](((Get-ChildItem $installRoot -File -Recurse | Measure-Object Length -Sum).Sum) / 1KB)
    New-ItemProperty -Path $uninstallKey -Name DisplayName -Value '齐沐堂门店管理系统' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name DisplayVersion -Value '3.1.1' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name Publisher -Value '齐沐堂' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name InstallLocation -Value $installRoot -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name DisplayIcon -Value "$icon,0" -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name UninstallString -Value "`"$powershell`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$uninstaller`"" -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name QuietUninstallString -Value "`"$powershell`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$uninstaller`"" -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name EstimatedSize -Value $estimatedSize -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name NoModify -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name NoRepair -Value 1 -PropertyType DWord -Force | Out-Null

    if (Test-Path $oldRoot) {
        Remove-Item -LiteralPath $oldRoot -Recurse -Force
    }

    Show-Info "安装完成。`r`n`r`n桌面已经创建“齐沐堂门店管理系统”图标，程序将自动启动。`r`n营业数据保存在：$dataRoot"
    if (Test-Path $launcher) { Start-Process -FilePath $launcher -WorkingDirectory $installRoot } else { Start-Process -FilePath $javaw -ArgumentList @('-Dfile.encoding=UTF-8', '-jar', "`"$jar`"") -WorkingDirectory $installRoot }
    exit 0
} catch {
    if ($stageRoot -and (Test-Path $stageRoot)) {
        Remove-Item -LiteralPath $stageRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    Show-Error $_.Exception.Message
    exit 1
}
