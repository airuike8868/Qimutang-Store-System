const { app, BrowserWindow, dialog, shell } = require('electron');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');

const EXPECTED_VERSION = '3.3.3';
const SMOKE_MODE = process.argv.includes('--smoke-test');
let mainWindow = null;
let backend = null;
let quitting = false;

app.disableHardwareAcceleration();
app.commandLine.appendSwitch('disable-features', 'RendererCodeIntegrity');
app.setAppUserModelId('com.qimutang.store.win7');

const singleInstance = app.requestSingleInstanceLock();
if (!singleInstance) app.quit();

function dataDir() {
  return path.join(app.getPath('home'), 'QimutangData', 'data');
}

function installPaths() {
  return {
    java: path.join(process.resourcesPath, 'runtime', 'bin', 'java.exe'),
    jar: path.join(process.resourcesPath, 'backend', 'qimutang.jar')
  };
}

function appendLog(message) {
  try {
    const logDir = path.join(dataDir(), 'logs');
    fs.mkdirSync(logDir, { recursive: true });
    fs.appendFileSync(path.join(logDir, 'win7-client.log'), `[${new Date().toISOString()}] ${message}\r\n`, 'utf8');
  } catch (_) {}
}

function readPort() {
  try {
    const value = Number(fs.readFileSync(path.join(dataDir(), 'server.port'), 'utf8').trim());
    if (value > 0 && value < 65536) return value;
  } catch (_) {}
  return 8080;
}

function health(port, timeout = 1200) {
  return new Promise(resolve => {
    const request = http.get({ hostname: '127.0.0.1', port, path: '/api/health', timeout }, response => {
      let body = '';
      response.setEncoding('utf8');
      response.on('data', chunk => { body += chunk; });
      response.on('end', () => {
        try {
          const json = JSON.parse(body);
          resolve(response.statusCode === 200 && json.success && json.data && json.data.version === EXPECTED_VERSION);
        } catch (_) { resolve(false); }
      });
    });
    request.on('timeout', () => { request.destroy(); resolve(false); });
    request.on('error', () => resolve(false));
  });
}

async function findServer() {
  const preferred = readPort();
  const ports = [preferred];
  for (let p = 8080; p < 8100; p++) if (!ports.includes(p)) ports.push(p);
  for (const port of ports) if (await health(port, 350)) return port;
  return null;
}

function startBackend() {
  const files = installPaths();
  if (!fs.existsSync(files.java)) throw new Error('客户端缺少内置 Java 运行环境。');
  if (!fs.existsSync(files.jar)) throw new Error('客户端缺少后台程序文件。');
  fs.mkdirSync(dataDir(), { recursive: true });
  const logDir = path.join(dataDir(), 'logs');
  fs.mkdirSync(logDir, { recursive: true });
  const stdout = fs.openSync(path.join(logDir, 'backend-console.log'), 'a');
  backend = spawn(files.java, [
    '-Dfile.encoding=UTF-8',
    '-Djava.awt.headless=true',
    '-Dqimutang.desktop=true',
    `-Dqimutang.data-dir=${dataDir()}`,
    '-jar', files.jar
  ], {
    cwd: process.resourcesPath,
    windowsHide: true,
    stdio: ['ignore', stdout, stdout]
  });
  backend.on('error', error => appendLog(`后台启动失败：${error.stack || error}`));
  backend.on('exit', code => appendLog(`后台已退出：${code}`));
  appendLog(`后台进程已启动：${backend.pid}`);
}

async function waitForServer(seconds) {
  for (let i = 0; i < seconds; i++) {
    const port = await findServer();
    if (port) return port;
    if (backend && backend.exitCode !== null) throw new Error(`本地服务意外退出（代码 ${backend.exitCode}）。`);
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  throw new Error('本地服务启动超时。请重新打开；若仍失败，请查看 QimutangData\\data\\logs。');
}

function allowedLocalUrl(value) {
  try {
    const target = new URL(value);
    return target.protocol === 'http:' && target.hostname === '127.0.0.1';
  } catch (_) { return false; }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    title: '齐沐堂门店管理系统 3.3.3',
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 720,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#f4f7fb',
    icon: path.join(process.resourcesPath, 'qimutang.ico'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      devTools: false,
      partition: 'persist:qimutang-win7-client-r1'
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'loading.html'));
  mainWindow.once('ready-to-show', () => { mainWindow.show(); mainWindow.maximize(); });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (allowedLocalUrl(url)) mainWindow.loadURL(url);
    else appendLog(`已阻止外部窗口：${url}`);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!allowedLocalUrl(url) && !url.startsWith('file:')) event.preventDefault();
  });
}

async function start() {
  try {
    if (!SMOKE_MODE) createWindow();
    let port = await findServer();
    if (!port) {
      startBackend();
      port = await waitForServer(360);
    }
    appendLog(`客户端连接成功：http://127.0.0.1:${port}`);
    if (SMOKE_MODE) {
      setTimeout(() => app.quit(), 300);
      return;
    }
    await mainWindow.loadURL(`http://127.0.0.1:${port}/`);
  } catch (error) {
    appendLog(error.stack || String(error));
    if (SMOKE_MODE) {
      app.exit(2);
      return;
    }
    dialog.showMessageBoxSync({ type: 'error', title: '齐沐堂门店管理系统', message: '启动失败', detail: error.message });
    shell.openPath(path.join(dataDir(), 'logs'));
    app.quit();
  }
}

app.on('second-instance', () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  }
});

app.on('before-quit', () => {
  quitting = true;
  if (backend && backend.exitCode === null) {
    try { backend.kill(); } catch (_) {}
  }
});

app.on('window-all-closed', () => { if (quitting || process.platform !== 'darwin') app.quit(); });
app.whenReady().then(start);
