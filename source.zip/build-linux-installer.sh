#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

mvn clean package
mkdir -p dist
jpackage \
  --type deb \
  --name qimutang \
  --app-version 2.0.0 \
  --vendor "Qimutang" \
  --description "Qimutang Store Management System" \
  --input target \
  --main-jar qimutang.jar \
  --dest dist \
  --java-options "-Dfile.encoding=UTF-8" \
  --linux-shortcut \
  --linux-menu-group "Office"

echo "Linux installation package generated in dist/."
