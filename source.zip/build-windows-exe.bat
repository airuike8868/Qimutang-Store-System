@echo off
setlocal EnableExtensions
chcp 65001 >nul
where java >nul 2>nul || (echo 未检测到 JDK 17。& if not defined CI pause & exit /b 1)
where mvn >nul 2>nul || (echo 未检测到 Maven 3.9+。& if not defined CI pause & exit /b 1)
where jpackage >nul 2>nul || (echo 当前 JDK 不包含 jpackage，请安装完整 JDK 17。& if not defined CI pause & exit /b 1)
echo [1/2] 正在编译齐沐堂门店管理系统 2.0...
call mvn clean package
if errorlevel 1 (
  echo 编译失败。请确认已安装 JDK 17 和 Maven，并且电脑可访问 Maven 中央仓库。
  if not defined CI pause
  exit /b 1
)
echo [2/2] 正在生成 Windows 安装程序...
if exist dist rmdir /s /q dist
jpackage --type exe --name "齐沐堂门店管理系统" --app-version 2.0.0 --vendor "齐沐堂" --description "齐沐堂本地门店管理系统" --input target --main-jar qimutang.jar --dest dist --java-options "-Dfile.encoding=UTF-8" --win-shortcut --win-menu --win-dir-chooser --win-per-user-install
if errorlevel 1 (
  echo EXE 打包失败。Windows 的 jpackage 生成 exe 需要安装 WiX Toolset 3.x，并确保其 bin 目录已加入 PATH。
  if not defined CI pause
  exit /b 1
)
echo.
echo 已生成安装程序：dist\齐沐堂门店管理系统-2.0.0.exe
if not defined CI pause
