#!/usr/bin/env python3
import json
import sys
import urllib.error
import urllib.request
from datetime import date


BASE = (sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:18080").rstrip("/")
TOKEN = None


def call(path, method="GET", body=None, auth=True):
    global TOKEN
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(BASE + "/api" + path, data=data, method=method)
    request.add_header("Content-Type", "application/json")
    if auth and TOKEN:
        request.add_header("Authorization", "Bearer " + TOKEN)
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        raise AssertionError(f"HTTP {error.code} {path}: {error.read().decode('utf-8')}") from error
    if not payload.get("success"):
        raise AssertionError(f"API failed {path}: {payload.get('message')}")
    return payload.get("data")


def expect(condition, message):
    if not condition:
        raise AssertionError(message)


def main():
    global TOKEN
    health = call("/health", auth=False)
    expect(health["status"] == "UP", "health endpoint is not ready")

    login = call("/auth/login", "POST", {"username": "admin", "password": "123456"}, auth=False)
    TOKEN = login["token"]
    if login.get("firstLogin"):
        call("/auth/change-password", "POST", {
            "oldPassword": "123456", "newPassword": "SmokePass2026!"
        })
    login = call("/auth/login", "POST", {
        "username": "admin", "password": "SmokePass2026!"
    }, auth=False)
    TOKEN = login["token"]

    stamp = date.today().strftime("%m%d")
    phone = "1390000" + stamp
    call("/customers", "POST", {
        "name": "测试顾客", "phone": phone, "gender": "女", "source": "测试",
        "remark": "自动化验收数据"
    })
    customer = next(row for row in call("/customers") if row["phone"] == phone)

    call("/employees", "POST", {
        "name": "测试技师", "phone": "1380000" + stamp, "position": "修脚师",
        "hireDate": date.today().isoformat(), "baseSalary": 2000, "status": "在职"
    })
    employee = next(row for row in call("/employees") if row["name"] == "测试技师")

    call("/inventory", "POST", {
        "name": "一次性测试刀片", "category": "耗材", "quantity": 0,
        "unit": "盒", "costPrice": 0, "minQuantity": 2, "supplier": ""
    })
    inventory = next(row for row in call("/inventory") if row["name"] == "一次性测试刀片")
    call("/suppliers", "POST", {
        "name": "测试供应商", "contact": "王先生", "phone": "13000000000"
    })
    supplier = next(row for row in call("/suppliers") if row["name"] == "测试供应商")
    purchase = call("/purchases", "POST", {
        "inventoryId": inventory["id"], "supplierId": supplier["id"],
        "quantity": 10, "unitCost": 12.5, "businessDate": date.today().isoformat(),
        "paymentMethod": "微信", "remark": "自动化采购测试"
    })
    expect(purchase["stock"] == 10, "purchase did not increase stock")

    call("/members/recharge", "POST", {
        "customerId": customer["id"], "amount": 500, "gift": 50, "remark": "验收充值"
    })
    services = call("/services")
    service = services[0]
    call(f"/services/{service['id']}", "PUT", {
        "name": service["name"], "category": service["category"],
        "duration": service["duration"], "listPrice": 59.9, "memberPrice": 49.9,
        "commissionType": "FIXED", "commissionValue": 20, "status": True,
        "remark": "自动化验收"
    })
    order = call("/orders", "POST", {
        "customerId": customer["id"],
        "items": [{
            "serviceId": service["id"], "name": service["name"], "price": 59.9,
            "technicianId": employee["id"], "technicianName": employee["name"],
            "commission": 20
        }],
        "payments": [{"method": "会员余额", "amount": 20}, {"method": "现金", "amount": 39.9}],
        "remark": "组合支付验收"
    })
    call(f"/orders/{order['orderId']}/refund", "POST", {
        "amount": 10, "reason": "自动化部分退款验收"
    })

    call("/members/adjust", "POST", {
        "customerId": customer["id"], "principalChange": 1,
        "giftChange": 0, "reason": "自动化余额调整验收"
    })
    call("/care", "POST", {
        "customerId": customer["id"], "type": "甲沟炎", "foot": "左脚",
        "toe": "大拇趾", "stage": "初次", "technicianId": employee["id"],
        "description": "测试护理记录", "plan": "一周后回访",
        "nextDate": date.today().isoformat()
    })
    call("/appointments", "POST", {
        "customerId": customer["id"], "serviceId": service["id"],
        "technicianId": employee["id"], "startAt": date.today().isoformat() + "T15:00",
        "duration": 60, "remark": "自动化预约"
    })
    call("/followups", "POST", {
        "customerId": customer["id"], "planDate": date.today().isoformat(),
        "employeeId": employee["id"], "method": "微信", "remark": "自动化回访"
    })

    payroll = call("/payroll?from=" + date.today().isoformat() + "&to=" + date.today().isoformat())
    employee_payroll = next(row for row in payroll if row["id"] == employee["id"])
    expect(float(employee_payroll["commission"]) > 0, "commission was not calculated")
    call("/payroll/settle", "POST", {
        "employeeId": employee["id"], "from": date.today().isoformat(),
        "to": date.today().isoformat(), "adjustment": 0,
        "paymentMethod": "银行卡", "remark": "自动化工资结算"
    })

    call("/users", "POST", {
        "username": "smoke_" + stamp, "name": "测试前台", "role": "前台", "password": "123456"
    })
    expect(any(row["username"] == "smoke_" + stamp for row in call("/users")), "user account was not created")
    report = call("/reports/summary?from=" + date.today().isoformat() + "&to=" + date.today().isoformat())
    expect(int(report["orders"]) >= 1, "order missing from report")
    expect(len(call("/inventory/" + str(inventory["id"]) + "/logs")) >= 1, "inventory log missing")
    expect(len(call("/members/" + str(customer["id"]) + "/balance-logs")) >= 3, "member balance logs missing")
    backup_name = call("/system/backup", "POST", {})
    expect(backup_name.endswith(".db"), "manual backup failed")
    print("SMOKE TEST PASSED")


if __name__ == "__main__":
    main()
