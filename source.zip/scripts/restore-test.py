#!/usr/bin/env python3
import json
import sys
import urllib.request


base = sys.argv[1].rstrip("/")
phase = sys.argv[2]
state_path = sys.argv[3]
token = None


def call(path, method="GET", body=None, auth=True):
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(base + "/api" + path, data=data, method=method)
    request.add_header("Content-Type", "application/json")
    if auth and token:
        request.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(request, timeout=10) as response:
        payload = json.loads(response.read().decode("utf-8"))
    if not payload.get("success"):
        raise AssertionError(payload.get("message"))
    return payload.get("data")


if phase == "prepare":
    login = call("/auth/login", "POST", {"username": "admin", "password": "123456"}, auth=False)
    token = login["token"]
    call("/auth/change-password", "POST", {"oldPassword": "123456", "newPassword": "RestorePass2026!"})
    call("/customers", "POST", {"name": "备份前顾客", "phone": "13911110001", "source": "验收"})
    backup = call("/system/backup", "POST", {})
    call("/customers", "POST", {"name": "备份后顾客", "phone": "13911110002", "source": "验收"})
    call("/system/restore", "POST", {"name": backup})
    with open(state_path, "w", encoding="utf-8") as output:
        json.dump({"backup": backup}, output, ensure_ascii=False)
    print("RESTORE PREPARED", backup)
elif phase == "verify":
    login = call("/auth/login", "POST", {"username": "admin", "password": "RestorePass2026!"}, auth=False)
    token = login["token"]
    customers = call("/customers")
    names = {row["name"] for row in customers}
    if "备份前顾客" not in names or "备份后顾客" in names:
        raise AssertionError("restored database content is incorrect")
    print("RESTORE TEST PASSED")
else:
    raise SystemExit("phase must be prepare or verify")
