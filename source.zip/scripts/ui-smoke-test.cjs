#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const baseUrl = process.argv[2] || 'http://127.0.0.1:18080';
const outputDir = path.resolve(process.argv[3] || 'build/ui-test');
fs.mkdirSync(outputDir, { recursive: true });

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 980 }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => {
    if (message.type() === 'error') errors.push(message.text());
  });

  await page.goto(baseUrl, { waitUntil: 'networkidle' });
  await page.locator('#login-username').fill('admin');
  await page.locator('#login-password').fill('123456');
  await page.locator('#login-button').click();
  await page.locator('#first-password').fill('UiSmoke2026!');
  await page.locator('#first-password-confirm').fill('UiSmoke2026!');
  await page.locator('.modal-save').click();
  await page.locator('.topbar').waitFor({ state: 'visible' });
  await page.screenshot({ path: path.join(outputDir, 'dashboard-desktop.png'), fullPage: true });

  const menus = [
    '收银开单', '订单管理', '预约管理', '顾客档案', '护理档案', '会员管理',
    '次卡套餐', '回访提醒', '项目管理', '员工管理', '库存管理', '采购管理',
    '收支管理', '工资提成', '营业报表', '系统设置'
  ];
  for (const menu of menus) {
    await page.locator(`[data-page="${menu}"]`).click();
    await page.waitForTimeout(120);
    await page.locator('#content .loading').waitFor({ state: 'detached', timeout: 10000 }).catch(() => {});
    if (await page.locator('.error-panel').count()) {
      errors.push(`${menu}: ${await page.locator('.error-panel').innerText()}`);
    }
  }

  await page.setViewportSize({ width: 390, height: 844 });
  await page.locator('[data-page="首页"]').click({ force: true });
  await page.waitForTimeout(200);
  await page.screenshot({ path: path.join(outputDir, 'dashboard-mobile.png'), fullPage: true });

  await browser.close();
  if (errors.length) {
    console.error(JSON.stringify({ status: 'failed', errors }, null, 2));
    process.exit(1);
  }
  console.log(JSON.stringify({ status: 'passed', menusChecked: menus.length + 1, outputDir }, null, 2));
})().catch(error => {
  console.error(error);
  process.exit(1);
});
