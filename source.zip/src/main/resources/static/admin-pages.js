async function servicesPage() {
  const rows = await api('/services');
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar"><button id="new-service">新增项目</button></div>
    <div class="panel"><div class="table-wrap"><table><thead><tr><th>项目</th><th>分类</th><th>时长</th><th>门市价</th><th>会员价</th><th>提成</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows.length ? rows.map(row => `<tr><td><b>${esc(row.name)}</b></td><td>${esc(row.category)}</td><td>${row.duration || 0}分钟</td><td>${money(row.list_price)}</td><td>${money(row.member_price)}</td><td>${row.commission_type === 'PERCENT' ? `${Number(row.commission_value)}%` : money(row.commission_value)}</td><td>${statusTag(Number(row.status) === 1 ? '上架' : '下架')}</td><td><button class="ghost small" data-edit-service="${row.id}">编辑</button></td></tr>`).join('') : `<tr><td colspan="8">${empty('还没有服务项目')}</td></tr>`}</tbody></table></div></div>`;
  $('new-service').addEventListener('click', () => serviceForm());
  content.querySelectorAll('[data-edit-service]').forEach(button => button.addEventListener('click', () => {
    serviceForm(rows.find(row => String(row.id) === button.dataset.editService));
  }));
}

function serviceForm(service = null) {
  const editing = Boolean(service);
  modal(editing ? '编辑服务项目' : '新增服务项目', `
    ${field('项目名称 *', input('service-name', '项目名称', 'text', service?.name || ''))}
    <div class="form-grid two">
      ${field('项目分类', select('service-category', ['修脚', '足疗', '足部护理', '灰指甲', '甲沟炎', '嵌甲', '推拿按摩', '肩颈', '头疗', '拔罐', 'SPA', '其他'], 'name', service?.category || '修脚'))}
      ${field('服务时长（分钟）', input('service-duration', '时长', 'number', service?.duration || '60', 'min="0"'))}
      ${field('门市价', input('service-list-price', '门市价', 'number', service?.list_price || '', 'min="0" step="0.01"'))}
      ${field('会员价', input('service-member-price', '会员价', 'number', service?.member_price || '', 'min="0" step="0.01"'))}
      ${field('提成方式', select('service-commission-type', [{id: 'FIXED', name: '固定金额'}, {id: 'PERCENT', name: '按项目金额百分比'}], 'name', service?.commission_type || 'FIXED'))}
      ${field('提成数值', input('service-commission-value', '金额或百分比', 'number', service?.commission_value || '0', 'min="0" step="0.01"'))}
      ${editing ? field('项目状态', select('service-status', [{id: 'true', name: '上架'}, {id: 'false', name: '下架'}], 'name', Number(service.status) === 1 ? 'true' : 'false')) : ''}
    </div>
    ${field('备注', `<textarea id="service-remark" placeholder="服务说明">${esc(service?.remark || '')}</textarea>`)}
  `, async () => {
    const listPrice = Number($('service-list-price').value || 0);
    const body = {
      name: $('service-name').value.trim(), category: $('service-category').value,
      duration: Number($('service-duration').value || 0), listPrice,
      memberPrice: $('service-member-price').value === '' ? listPrice : Number($('service-member-price').value), commissionType: $('service-commission-type').value,
      commissionValue: Number($('service-commission-value').value || 0),
      status: editing ? $('service-status').value === 'true' : true, remark: $('service-remark').value.trim()
    };
    if (!body.name) throw new Error('请输入项目名称');
    await api(editing ? `/services/${service.id}` : '/services', {
      method: editing ? 'PUT' : 'POST', body: JSON.stringify(body)
    });
    toast(editing ? '项目已更新' : '项目已新增');
    await servicesPage();
  });
}

async function employeesPage() {
  const rows = await api('/employees');
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar"><button id="new-employee">新增员工</button></div>
    <div class="panel"><div class="panel-head"><div><h3>员工资料</h3><p>登录账号请由管理员在系统设置中创建</p></div></div><div class="table-wrap"><table><thead><tr><th>姓名</th><th>手机</th><th>岗位</th><th>入职日期</th><th>底薪</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows.length ? rows.map(row => `<tr><td><b>${esc(row.name)}</b></td><td>${esc(row.phone || '-')}</td><td>${esc(row.position)}</td><td>${esc(row.hire_date || '-')}</td><td>${money(row.base_salary)}</td><td>${statusTag(row.status)}</td><td><button class="ghost small" data-edit-employee="${row.id}">编辑</button></td></tr>`).join('') : `<tr><td colspan="7">${empty('还没有员工资料')}</td></tr>`}</tbody></table></div></div>`;
  $('new-employee').addEventListener('click', () => employeeForm());
  content.querySelectorAll('[data-edit-employee]').forEach(button => button.addEventListener('click', () => employeeForm(rows.find(row => String(row.id) === button.dataset.editEmployee))));
}

function employeeForm(employee = null) {
  const editing = Boolean(employee);
  modal(editing ? '编辑员工' : '新增员工', `
    <div class="form-grid two">
      ${field('姓名 *', input('employee-name', '员工姓名', 'text', employee?.name || ''))}
      ${field('手机号', input('employee-phone', '手机号', 'tel', employee?.phone || ''))}
      ${field('岗位', select('employee-position', ['店长', '前台', '修脚师', '足疗师', '按摩师', '护理师', '其他'], 'name', employee?.position || '修脚师'))}
      ${field('入职日期', input('employee-hire-date', '入职日期', 'date', employee?.hire_date || today()))}
      ${field('月基础工资', input('employee-base-salary', '底薪', 'number', employee?.base_salary || '0', 'min="0" step="0.01"'))}
      ${editing ? field('在职状态', select('employee-status', ['在职', '离职', '停薪留职'], 'name', employee?.status || '在职')) : ''}
    </div>
    ${field('提成规则备注', `<textarea id="employee-rule" placeholder="例如：按项目固定提成，以项目管理中的设置为准">${esc(employee?.commission_rule || '')}</textarea>`)}
  `, async () => {
    const body = {
      name: $('employee-name').value.trim(), phone: $('employee-phone').value.trim(),
      position: $('employee-position').value, hireDate: $('employee-hire-date').value,
      baseSalary: Number($('employee-base-salary').value || 0),
      status: editing ? $('employee-status').value : '在职', commissionRule: $('employee-rule').value.trim()
    };
    if (!body.name) throw new Error('请输入员工姓名');
    await api(editing ? `/employees/${employee.id}` : '/employees', {
      method: editing ? 'PUT' : 'POST', body: JSON.stringify(body)
    });
    toast(editing ? '员工资料已更新' : '员工已新增');
    await employeesPage();
  });
}

async function inventoryPage() {
  const rows = await api('/inventory');
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar">${['管理员', '店长'].includes(state.user.role) ? '<button id="new-inventory">新增商品</button>' : ''}</div>
    <div class="panel"><div class="panel-head"><div><h3>库存台账</h3><p>低于最低库存的商品会优先显示</p></div><span class="count-badge danger-bg">${rows.filter(row => Number(row.low_stock) === 1).length} 项预警</span></div>
      <div class="table-wrap"><table><thead><tr><th>商品</th><th>分类</th><th>当前库存</th><th>最低库存</th><th>移动成本</th><th>供应商</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows.length ? rows.map(row => `<tr class="${Number(row.low_stock) === 1 ? 'low-stock' : ''}"><td><b>${esc(row.name)}</b></td><td>${esc(row.category || '-')}</td><td><b>${Number(row.quantity)} ${esc(row.unit)}</b></td><td>${Number(row.min_quantity)} ${esc(row.unit)}</td><td>${money(row.cost_price)}</td><td>${esc(row.supplier || '-')}</td><td>${Number(row.low_stock) === 1 ? statusTag('库存不足') : statusTag('正常')}</td><td class="actions"><button class="small" data-adjust-inventory="${row.id}">出入库</button><button class="ghost small" data-inventory-log="${row.id}">流水</button></td></tr>`).join('') : `<tr><td colspan="8">${empty('还没有库存商品')}</td></tr>`}</tbody></table></div>
    </div>`;
  $('new-inventory')?.addEventListener('click', () => inventoryForm());
  content.querySelectorAll('[data-adjust-inventory]').forEach(button => button.addEventListener('click', () => inventoryAdjust(rows.find(row => String(row.id) === button.dataset.adjustInventory))));
  content.querySelectorAll('[data-inventory-log]').forEach(button => button.addEventListener('click', () => inventoryLogs(Number(button.dataset.inventoryLog))));
}

function inventoryForm() {
  modal('新增库存商品', `
    <div class="form-grid two">
      ${field('商品名称 *', input('inventory-name', '耗材或零售商品'))}
      ${field('分类', input('inventory-category', '例如：一次性耗材'))}
      ${field('初始库存', input('inventory-quantity', '数量', 'number', '0', 'min="0" step="0.01"'))}
      ${field('单位', input('inventory-unit', '个 / 盒 / 瓶', 'text', '个'))}
      ${field('成本价', input('inventory-cost', '成本价', 'number', '0', 'min="0" step="0.01"'))}
      ${field('最低库存', input('inventory-min', '预警值', 'number', '5', 'min="0" step="0.01"'))}
    </div>
    ${field('供应商', input('inventory-supplier', '可先手工填写'))}
  `, async () => {
    if (!$('inventory-name').value.trim()) throw new Error('请输入商品名称');
    await api('/inventory', { method: 'POST', body: JSON.stringify({
      name: $('inventory-name').value.trim(), category: $('inventory-category').value.trim(),
      quantity: Number($('inventory-quantity').value || 0), unit: $('inventory-unit').value.trim(),
      costPrice: Number($('inventory-cost').value || 0), minQuantity: Number($('inventory-min').value || 0),
      supplier: $('inventory-supplier').value.trim()
    }) });
    toast('库存商品已新增');
    await inventoryPage();
  });
}

function inventoryAdjust(item) {
  modal(`库存调整 · ${item.name}`, `
    <div class="detail-cards"><div><span>当前库存</span><b>${Number(item.quantity)} ${esc(item.unit)}</b></div><div><span>最低库存</span><b>${Number(item.min_quantity)} ${esc(item.unit)}</b></div></div>
    ${field('调整类型', select('inventory-adjust-type', ['入库', '出库', '盘点', '报损']))}
    ${field('数量', input('inventory-adjust-quantity', '入库/出库填数量；盘点填实际库存', 'number', '', 'min="0" step="0.01"'))}
    ${field('原因 *', '<textarea id="inventory-adjust-reason" placeholder="例如：日常领用、破损报废、月末盘点"></textarea>')}
  `, async () => {
    const type = $('inventory-adjust-type').value;
    const entered = Number($('inventory-adjust-quantity').value);
    if (!(entered >= 0)) throw new Error('请输入正确数量');
    let change = entered;
    if (['出库', '报损'].includes(type)) change = -entered;
    if (type === '盘点') change = entered - Number(item.quantity);
    if (change === 0) throw new Error('库存没有发生变化');
    const reason = $('inventory-adjust-reason').value.trim();
    if (reason.length < 2) throw new Error('请填写调整原因');
    await api(`/inventory/${item.id}/adjust`, { method: 'POST', body: JSON.stringify({ type, changeQty: change, remark: reason }) });
    toast('库存已调整');
    await inventoryPage();
  });
}

async function inventoryLogs(id) {
  const rows = await api(`/inventory/${id}/logs`);
  modal('库存变动流水', rows.length ? `<div class="table-wrap"><table><thead><tr><th>类型</th><th>变动前</th><th>变动</th><th>变动后</th><th>经手人</th><th>时间</th><th>原因</th></tr></thead><tbody>${rows.map(row => `<tr><td>${esc(row.type)}</td><td>${Number(row.before_qty)}</td><td class="${Number(row.change_qty) < 0 ? 'negative' : 'positive'}">${Number(row.change_qty) > 0 ? '+' : ''}${Number(row.change_qty)}</td><td>${Number(row.after_qty)}</td><td>${esc(row.operator_name || '-')}</td><td>${esc(shortDate(row.created_at))}</td><td>${esc(row.remark || '')}</td></tr>`).join('')}</tbody></table></div>` : empty('暂无库存流水'), async () => {}, { saveText: '关闭', wide: true });
}

async function purchasesPage() {
  const month = window.qmtPurchaseMonth || today().slice(0, 7);
  const [rows, inventory, suppliers] = await Promise.all([
    api(`/purchases?month=${month}`), api('/inventory'), api('/suppliers')
  ]);
  const content = $('content');
  const total = rows.reduce((sum, row) => sum + Number(row.total_amount || 0), 0);
  content.innerHTML = `
    <div class="toolbar">${input('purchase-month', '月份', 'month', month)}<button id="load-purchases">查询</button><button id="new-purchase">采购入库</button><button id="new-supplier" class="ghost">新增供应商</button><button id="export-purchases" class="ghost">导出 Excel</button></div>
    <div class="metric-grid three"><div class="metric primary"><span>本月采购金额</span><b>${money(total)}</b></div><div class="metric"><span>采购笔数</span><b>${rows.length}</b></div><div class="metric"><span>供应商</span><b>${suppliers.length}</b></div></div>
    <div class="panel"><div class="table-wrap"><table><thead><tr><th>采购单号</th><th>日期</th><th>商品</th><th>供应商</th><th>数量</th><th>单价</th><th>金额</th><th>付款</th><th>状态</th></tr></thead><tbody>${rows.length ? rows.map(row => `<tr><td>${esc(row.purchase_no)}</td><td>${esc(row.business_date)}</td><td><b>${esc(row.inventory_name)}</b></td><td>${esc(row.supplier_name || '-')}</td><td>${Number(row.quantity)} ${esc(row.unit || '')}</td><td>${money(row.unit_cost)}</td><td><b>${money(row.total_amount)}</b></td><td>${esc(row.payment_method)}</td><td>${statusTag(row.status)}</td></tr>`).join('') : `<tr><td colspan="9">${empty('本月还没有采购记录')}</td></tr>`}</tbody></table></div></div>`;

  $('load-purchases').addEventListener('click', () => { window.qmtPurchaseMonth = $('purchase-month').value; purchasesPage(); });
  $('new-purchase').addEventListener('click', () => purchaseForm(inventory, suppliers));
  $('new-supplier').addEventListener('click', supplierForm);
  $('export-purchases').addEventListener('click', () => downloadCsv(`齐沐堂采购_${month}.csv`, [
    { label: '采购单号', value: 'purchase_no' }, { label: '日期', value: 'business_date' }, { label: '商品', value: 'inventory_name' },
    { label: '供应商', value: 'supplier_name' }, { label: '数量', value: 'quantity' }, { label: '单价', value: 'unit_cost' },
    { label: '总金额', value: 'total_amount' }, { label: '付款方式', value: 'payment_method' }, { label: '状态', value: 'status' }
  ], rows));
}

function purchaseForm(inventory, suppliers) {
  if (!inventory.length) return showError(new Error('请先在库存管理中新增商品'));
  modal('采购入库', `
    <div class="form-grid two">
      ${field('采购商品 *', select('purchase-inventory', inventory))}
      ${field('供应商', select('purchase-supplier', suppliers, 'name', '', '暂不指定'))}
      ${field('采购数量 *', input('purchase-quantity', '数量', 'number', '', 'min="0.01" step="0.01"'))}
      ${field('采购单价 *', input('purchase-unit-cost', '含税单价', 'number', '', 'min="0" step="0.01"'))}
      ${field('采购日期', input('purchase-date', '采购日期', 'date', today()))}
      ${field('付款方式', select('purchase-payment', ['微信', '支付宝', '现金', '银行卡', '未付款']))}
    </div>
    ${field('备注', '<textarea id="purchase-remark" placeholder="票据编号、到货情况等"></textarea>')}
    <div class="notice">保存后自动增加库存；已付款采购会同步记入“收支管理”的采购支出。</div>
  `, async () => {
    const quantity = Number($('purchase-quantity').value);
    const unitCost = Number($('purchase-unit-cost').value);
    if (!(quantity > 0) || !(unitCost >= 0)) throw new Error('采购数量或单价不正确');
    const result = await api('/purchases', { method: 'POST', body: JSON.stringify({
      inventoryId: $('purchase-inventory').value, supplierId: $('purchase-supplier').value || null,
      quantity, unitCost, businessDate: $('purchase-date').value,
      paymentMethod: $('purchase-payment').value, remark: $('purchase-remark').value.trim()
    }) });
    toast(`采购入库成功：${result.purchaseNo}`);
    await purchasesPage();
  });
}

function supplierForm() {
  modal('新增供应商', `
    ${field('供应商名称 *', input('supplier-name', '公司或个人名称'))}
    <div class="form-grid two">${field('联系人', input('supplier-contact', '联系人'))}${field('联系电话', input('supplier-phone', '联系电话', 'tel'))}</div>
    ${field('地址', input('supplier-address', '地址'))}
    ${field('备注', '<textarea id="supplier-remark" placeholder="供货品类、结算习惯等"></textarea>')}
  `, async () => {
    if (!$('supplier-name').value.trim()) throw new Error('请输入供应商名称');
    await api('/suppliers', { method: 'POST', body: JSON.stringify({
      name: $('supplier-name').value.trim(), contact: $('supplier-contact').value.trim(),
      phone: $('supplier-phone').value.trim(), address: $('supplier-address').value.trim(),
      remark: $('supplier-remark').value.trim()
    }) });
    toast('供应商已新增');
    await purchasesPage();
  });
}

async function financePage() {
  const month = window.qmtFinanceMonth || today().slice(0, 7);
  const rows = await api(`/finance?month=${month}`);
  const content = $('content');
  const income = rows.filter(row => row.direction === '收入').reduce((sum, row) => sum + Number(row.amount), 0);
  const expense = rows.filter(row => row.direction === '支出').reduce((sum, row) => sum + Number(row.amount), 0);
  content.innerHTML = `
    <div class="toolbar">${input('finance-month', '月份', 'month', month)}<button id="load-finance">查询</button><button id="new-finance">新增收支</button><button id="export-finance" class="ghost">导出 Excel</button></div>
    <div class="metric-grid three"><div class="metric"><span>其他收入</span><b>${money(income)}</b></div><div class="metric"><span>经营支出</span><b>${money(expense)}</b></div><div class="metric primary"><span>收支净额</span><b>${money(income - expense)}</b></div></div>
    <div class="panel"><div class="table-wrap"><table><thead><tr><th>日期</th><th>方向</th><th>分类</th><th>金额</th><th>方式</th><th>经手人</th><th>凭证</th><th>备注</th></tr></thead><tbody>${rows.length ? rows.map(row => `<tr><td>${esc(row.business_date)}</td><td>${statusTag(row.direction)}</td><td>${esc(row.category)}</td><td class="${row.direction === '支出' ? 'negative' : 'positive'}"><b>${row.direction === '支出' ? '-' : '+'}${money(row.amount)}</b></td><td>${esc(row.payment_method)}</td><td>${esc(row.operator_name || '-')}</td><td>${row.voucher_path ? `<a href="${esc(row.voucher_path)}" target="_blank">查看凭证</a>` : '-'}</td><td>${esc(row.remark || '')}</td></tr>`).join('') : `<tr><td colspan="8">${empty('本月还没有收支记录')}</td></tr>`}</tbody></table></div></div>`;
  $('load-finance').addEventListener('click', () => { window.qmtFinanceMonth = $('finance-month').value; financePage(); });
  $('new-finance').addEventListener('click', financeForm);
  $('export-finance').addEventListener('click', () => downloadCsv(`齐沐堂收支_${month}.csv`, [
    { label: '日期', value: 'business_date' }, { label: '方向', value: 'direction' }, { label: '分类', value: 'category' },
    { label: '金额', value: 'amount' }, { label: '付款方式', value: 'payment_method' }, { label: '经手人', value: 'operator_name' },
    { label: '备注', value: 'remark' }
  ], rows));
}

function financeForm() {
  modal('新增收支', `
    <div class="form-grid two">
      ${field('日期', input('finance-date', '日期', 'date', today()))}
      ${field('方向', select('finance-direction', ['支出', '收入']))}
      ${field('分类 *', select('finance-category', ['房租', '水电物业', '工资提成', '采购进货', '推广费', '平台服务费', '维修费', '办公费', '其他支出', '其他收入']))}
      ${field('金额 *', input('finance-amount', '金额', 'number', '', 'min="0.01" step="0.01"'))}
      ${field('收付款方式', select('finance-method', ['微信', '支付宝', '现金', '银行卡', '其他']))}
      ${field('凭证照片', '<input id="finance-voucher" type="file" accept="image/jpeg,image/png,image/webp">')}
    </div>
    ${field('备注', '<textarea id="finance-remark" placeholder="用途、收款方、票据编号等"></textarea>')}
  `, async () => {
    const amount = Number($('finance-amount').value);
    if (!(amount > 0)) throw new Error('金额必须大于0');
    let voucherPath = null;
    if ($('finance-voucher').files[0]) {
      const form = new FormData();
      form.append('file', $('finance-voucher').files[0]);
      voucherPath = await api('/upload', { method: 'POST', body: form });
    }
    await api('/finance', { method: 'POST', body: JSON.stringify({
      businessDate: $('finance-date').value, direction: $('finance-direction').value,
      category: $('finance-category').value, amount, paymentMethod: $('finance-method').value,
      voucherPath, remark: $('finance-remark').value.trim()
    }) });
    toast('收支记录已保存');
    await financePage();
  });
}

async function payrollPage() {
  const from = window.qmtPayrollFrom || monthStart();
  const to = window.qmtPayrollTo || today();
  const [rows, settlements] = await Promise.all([
    api(`/payroll?from=${from}&to=${to}`), api('/payroll/settlements')
  ]);
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar">${input('payroll-from', '开始日期', 'date', from)}${input('payroll-to', '结束日期', 'date', to)}<button id="load-payroll">查询</button><button id="export-payroll" class="ghost">导出 Excel</button></div>
    <div class="panel"><div class="panel-head"><div><h3>本期工资测算</h3><p>实发 = 基础工资 + 退款后净提成 + 调整金额</p></div></div><div class="table-wrap"><table><thead><tr><th>员工</th><th>岗位</th><th>基础工资</th><th>净提成</th><th>预计应发</th><th>状态</th><th>操作</th></tr></thead><tbody>${rows.length ? rows.map(row => `<tr><td><b>${esc(row.name)}</b></td><td>${esc(row.position)}</td><td>${money(row.base_salary)}</td><td>${money(row.commission)}</td><td><b>${money(row.payable)}</b></td><td>${Number(row.settled) ? statusTag('已结算') : statusTag('待结算')}</td><td>${state.user.role === '管理员' && !Number(row.settled) ? `<button class="small" data-settle-payroll="${row.id}">结算发放</button>` : '-'}</td></tr>`).join('') : `<tr><td colspan="7">${empty('还没有在职员工')}</td></tr>`}</tbody></table></div></div>
    <div class="panel"><div class="panel-head"><div><h3>历史结算记录</h3><p>结算后自动记入经营支出</p></div></div><div class="table-wrap"><table><thead><tr><th>员工</th><th>结算周期</th><th>底薪</th><th>提成</th><th>调整</th><th>实发</th><th>方式</th><th>结算时间</th></tr></thead><tbody>${settlements.length ? settlements.map(row => `<tr><td>${esc(row.employee_name)}</td><td>${esc(row.period_start)} 至 ${esc(row.period_end)}</td><td>${money(row.base_salary)}</td><td>${money(row.commission)}</td><td>${money(row.adjustment)}</td><td><b>${money(row.total)}</b></td><td>${esc(row.payment_method)}</td><td>${esc(shortDate(row.paid_at))}</td></tr>`).join('') : `<tr><td colspan="8">${empty('暂无工资结算记录')}</td></tr>`}</tbody></table></div></div>`;
  $('load-payroll').addEventListener('click', () => {
    window.qmtPayrollFrom = $('payroll-from').value; window.qmtPayrollTo = $('payroll-to').value; payrollPage();
  });
  content.querySelectorAll('[data-settle-payroll]').forEach(button => button.addEventListener('click', () => settlePayroll(rows.find(row => String(row.id) === button.dataset.settlePayroll), from, to)));
  $('export-payroll').addEventListener('click', () => downloadCsv(`齐沐堂工资_${from}_${to}.csv`, [
    { label: '员工', value: 'name' }, { label: '岗位', value: 'position' }, { label: '基础工资', value: 'base_salary' },
    { label: '净提成', value: 'commission' }, { label: '预计应发', value: 'payable' }, { label: '是否结算', value: row => Number(row.settled) ? '是' : '否' }
  ], rows));
}

function settlePayroll(employee, from, to) {
  modal(`工资结算 · ${employee.name}`, `
    <div class="detail-cards three"><div><span>基础工资</span><b>${money(employee.base_salary)}</b></div><div><span>净提成</span><b>${money(employee.commission)}</b></div><div><span>预计应发</span><b>${money(employee.payable)}</b></div></div>
    ${field('奖励 / 扣款调整', input('payroll-adjustment', '奖励填正数，扣款填负数', 'number', '0', 'step="0.01"'))}
    ${field('发放方式', select('payroll-method', ['银行卡', '微信', '支付宝', '现金']))}
    ${field('结算备注', '<textarea id="payroll-remark" placeholder="奖励、扣款及确认情况"></textarea>')}
    <div class="notice warning">确认后会生成工资结算记录和支出记录，同一员工同一周期不能重复结算。</div>
  `, async () => {
    if (!confirmAction(`确认结算 ${employee.name} 在 ${from} 至 ${to} 的工资？`)) throw new Error('已取消结算');
    const message = await api('/payroll/settle', { method: 'POST', body: JSON.stringify({
      employeeId: employee.id, from, to, adjustment: Number($('payroll-adjustment').value || 0),
      paymentMethod: $('payroll-method').value, remark: $('payroll-remark').value.trim()
    }) });
    toast(message);
    await payrollPage();
  }, { saveText: '确认结算' });
}

async function reportsPage() {
  const from = window.qmtReportFrom || monthStart();
  const to = window.qmtReportTo || today();
  const reportData = await api(`/reports/summary?from=${from}&to=${to}`);
  const content = $('content');
  const profit = Number(reportData.sales) - Number(reportData.expenses) - Number(reportData.commissions);
  const maxService = Math.max(1, ...reportData.services.map(row => Number(row.sales_amount || 0)));
  content.innerHTML = `
    <div class="toolbar">${input('report-from', '开始日期', 'date', from)}${input('report-to', '结束日期', 'date', to)}<button id="load-report">查询</button><button id="export-report" class="ghost">导出 Excel</button><button id="print-report" class="ghost">打印</button></div>
    <div class="metric-grid six"><div class="metric primary"><span>净营业额</span><b>${money(reportData.sales)}</b><small>实收减退款</small></div><div class="metric"><span>订单数</span><b>${reportData.orders}</b></div><div class="metric"><span>充值金额</span><b>${money(reportData.recharge)}</b></div><div class="metric"><span>经营支出</span><b>${money(reportData.expenses)}</b></div><div class="metric"><span>员工提成</span><b>${money(reportData.commissions)}</b></div><div class="metric ${profit < 0 ? 'danger-metric' : ''}"><span>经营贡献</span><b>${money(profit)}</b><small>未扣房租折旧等未登记成本</small></div></div>
    <div class="grid2">
      <div class="panel"><div class="panel-head"><div><h3>项目销售排行</h3><p>按服务销售金额排序</p></div></div>${reportData.services.length ? `<div class="bar-list">${reportData.services.slice(0, 10).map(row => `<div class="bar-row"><span>${esc(row.service_name)}</span><div><i style="width:${Math.max(3, Number(row.sales_amount) / maxService * 100)}%"></i></div><b>${money(row.sales_amount)}<small>${row.sales_count}次</small></b></div>`).join('')}</div>` : empty('所选日期暂无项目销售')}</div>
      <div class="panel"><div class="panel-head"><div><h3>员工服务排行</h3><p>业绩与提成分开统计</p></div></div>${reportData.employees.length ? `<div class="table-wrap"><table><thead><tr><th>员工</th><th>服务次数</th><th>业绩</th><th>提成</th></tr></thead><tbody>${reportData.employees.map(row => `<tr><td>${esc(row.technician_name || '未指定')}</td><td>${row.service_count}</td><td>${money(row.sales_amount)}</td><td>${money(row.commission_amount)}</td></tr>`).join('')}</tbody></table></div>` : empty('所选日期暂无员工服务数据')}</div>
    </div>
    <div class="panel"><div class="detail-cards four"><div><span>会员人数</span><b>${reportData.memberCount}</b></div><div><span>会员余额</span><b>${money(reportData.memberBalance)}</b></div><div><span>60天沉睡会员</span><b>${reportData.dormantMembers}</b></div><div><span>新增顾客</span><b>${reportData.newCustomers}</b></div></div><div class="notice compact">“经营贡献”只是净营业额减已登记支出和员工提成，不等于会计利润。房租、水电、折旧等必须完整登记后才有参考意义。</div></div>`;
  $('load-report').addEventListener('click', () => { window.qmtReportFrom = $('report-from').value; window.qmtReportTo = $('report-to').value; reportsPage(); });
  $('export-report').addEventListener('click', () => {
    const summary = [
      { item: '净营业额', value: reportData.sales }, { item: '订单数', value: reportData.orders }, { item: '退款', value: reportData.refunds },
      { item: '充值', value: reportData.recharge }, { item: '经营支出', value: reportData.expenses }, { item: '员工提成', value: reportData.commissions },
      { item: '经营贡献', value: profit }, { item: '新增顾客', value: reportData.newCustomers }, { item: '会员余额', value: reportData.memberBalance }
    ];
    downloadCsv(`齐沐堂经营报表_${from}_${to}.csv`, [{ label: '指标', value: 'item' }, { label: '数值', value: 'value' }], summary);
  });
  $('print-report').addEventListener('click', () => window.print());
}

async function followupsPage() {
  const [rows, customers, employees] = await Promise.all([
    api('/followups?status=待回访'), api('/customers'), api('/employees').catch(() => [])
  ]);
  const content = $('content');
  content.innerHTML = `
    <div class="toolbar"><button id="new-followup">新增回访任务</button></div>
    <div class="panel"><div class="panel-head"><div><h3>待回访</h3><p>到期任务会在首页提醒</p></div><span class="count-badge">${rows.length}</span></div><div class="table-wrap"><table><thead><tr><th>计划日期</th><th>顾客</th><th>手机</th><th>计划方式</th><th>负责人</th><th>备注</th><th>操作</th></tr></thead><tbody>${rows.length ? rows.map(row => `<tr class="${String(row.plan_date) < today() ? 'overdue' : ''}"><td>${esc(row.plan_date)}</td><td><b>${esc(row.customer_name)}</b></td><td>${esc(row.phone)}</td><td>${esc(row.method || '-')}</td><td>${esc(row.employee_name || '未指定')}</td><td>${esc(row.remark || '')}</td><td><button class="small" data-complete-followup="${row.id}">完成回访</button></td></tr>`).join('') : `<tr><td colspan="7">${empty('没有待回访任务')}</td></tr>`}</tbody></table></div></div>`;
  content.querySelectorAll('[data-complete-followup]').forEach(button => button.addEventListener('click', () => completeFollowup(Number(button.dataset.completeFollowup))));
  $('new-followup').addEventListener('click', () => {
    if (!customers.length) return showError(new Error('请先新增顾客'));
    modal('新增回访任务', `
      <div class="form-grid two">${field('顾客 *', select('followup-customer', customers))}${field('计划日期 *', input('followup-date', '计划日期', 'date', today()))}${field('负责人', select('followup-employee', employees, 'name', '', '暂不指定'))}${field('计划方式', select('followup-method', ['微信', '电话', '短信', '其他']))}</div>
      ${field('回访重点', '<textarea id="followup-remark" placeholder="例如：询问护理后是否仍有扎肉不适"></textarea>')}
    `, async () => {
      await api('/followups', { method: 'POST', body: JSON.stringify({
        customerId: $('followup-customer').value, planDate: $('followup-date').value,
        employeeId: $('followup-employee').value || null, method: $('followup-method').value,
        remark: $('followup-remark').value.trim()
      }) });
      toast('回访任务已创建');
      await followupsPage();
    });
  });
}

function completeFollowup(id) {
  modal('完成回访', `
    ${field('实际方式', select('followup-done-method', ['微信', '电话', '短信', '其他']))}
    ${field('回访结果 *', '<textarea id="followup-result" placeholder="记录顾客反馈、是否复约、需要注意的问题"></textarea>')}
  `, async () => {
    const result = $('followup-result').value.trim();
    if (result.length < 2) throw new Error('请填写回访结果');
    await api(`/followups/${id}/complete`, { method: 'PUT', body: JSON.stringify({ method: $('followup-done-method').value, result }) });
    toast('回访已完成');
    await followupsPage();
  });
}

async function settingsPage() {
  const [store, users, backups, logs] = await Promise.all([
    api('/settings/store'), api('/users'), api('/system/backups'), api('/audit-logs')
  ]);
  const content = $('content');
  content.innerHTML = `
    <div class="settings-grid">
      <div class="panel"><div class="panel-head"><div><h3>门店资料</h3><p>用于系统内显示和后续票据</p></div></div>
        ${field('门店名称', input('setting-store-name', '门店名称', 'text', store.store_name || '齐沐堂'))}
        ${field('联系电话', input('setting-store-phone', '联系电话', 'tel', store.store_phone || ''))}
        ${field('门店地址', input('setting-store-address', '门店地址', 'text', store.store_address || ''))}
        <button id="save-store-settings">保存门店资料</button>
      </div>
      <div class="panel"><div class="panel-head"><div><h3>数据备份</h3><p>系统每天自动备份，也可立即备份</p></div><button id="backup-now">立即备份</button></div>
        <div class="table-wrap"><table><thead><tr><th>备份文件</th><th>大小</th><th>时间</th><th>操作</th></tr></thead><tbody id="backup-rows">${backups.length ? backups.slice(0, 15).map(row => `<tr><td>${esc(row.name)}</td><td>${Math.ceil(Number(row.size) / 1024)} KB</td><td>${esc(shortDate(row.modifiedAt))}</td><td><button class="ghost small danger" data-restore="${esc(row.name)}">恢复</button></td></tr>`).join('') : `<tr><td colspan="4">${empty('暂无备份')}</td></tr>`}</tbody></table></div>
        <div class="notice warning compact">恢复会先备份当前数据库，并在系统重启时执行。护理照片需另外复制整个 QimutangData 文件夹。</div>
      </div>
    </div>
    <div class="panel"><div class="panel-head"><div><h3>登录账号与权限</h3><p>员工资料和登录账号分开管理</p></div><button id="new-user">新增账号</button></div>
      <div class="table-wrap"><table><thead><tr><th>账号</th><th>姓名</th><th>角色</th><th>首次改密</th><th>最近登录</th><th>状态</th><th>操作</th></tr></thead><tbody id="user-rows">${users.map(row => `<tr><td><b>${esc(row.username)}</b></td><td>${esc(row.name)}</td><td><select class="inline-select" data-user-role="${row.id}">${['管理员', '店长', '前台', '技师'].map(role => `<option ${role === row.role ? 'selected' : ''}>${role}</option>`).join('')}</select></td><td>${Number(row.first_login) ? '是' : '否'}</td><td>${esc(shortDate(row.last_login_at))}</td><td>${statusTag(Number(row.active) ? '启用' : '停用')}</td><td class="actions"><button class="ghost small" data-reset-password="${row.id}">重置密码</button><button class="ghost small ${Number(row.active) ? 'danger' : ''}" data-user-status="${row.id}" data-active="${Number(row.active) ? 'false' : 'true'}">${Number(row.active) ? '停用' : '启用'}</button></td></tr>`).join('')}</tbody></table></div>
    </div>
    <div class="panel"><div class="panel-head"><div><h3>最近操作日志</h3><p>登录、退款、余额调整、采购和工资等关键操作</p></div><button id="export-audit" class="ghost">导出日志</button></div>
      <div class="table-wrap"><table><thead><tr><th>时间</th><th>操作人</th><th>类型</th><th>内容</th><th>IP</th></tr></thead><tbody>${logs.slice(0, 200).map(row => `<tr><td>${esc(shortDate(row.created_at))}</td><td>${esc(row.user_name || '-')}</td><td>${esc(row.type)}</td><td>${esc(row.content)}</td><td>${esc(row.ip || '-')}</td></tr>`).join('')}</tbody></table></div>
    </div>`;

  $('save-store-settings').addEventListener('click', async () => {
    try {
      const message = await api('/settings/store', { method: 'PUT', body: JSON.stringify({
        store_name: $('setting-store-name').value.trim(), store_phone: $('setting-store-phone').value.trim(),
        store_address: $('setting-store-address').value.trim()
      }) });
      toast(message);
    } catch (error) { showError(error); }
  });
  $('backup-now').addEventListener('click', async () => {
    try { toast(`备份成功：${await api('/system/backup', { method: 'POST', body: '{}' })}`); await settingsPage(); }
    catch (error) { showError(error); }
  });
  content.querySelectorAll('[data-restore]').forEach(button => button.addEventListener('click', async () => {
    if (!confirmAction(`确认恢复 ${button.dataset.restore}？当前数据会先自动备份。`)) return;
    try { const message = await api('/system/restore', { method: 'POST', body: JSON.stringify({ name: button.dataset.restore }) }); window.alert(message); }
    catch (error) { showError(error); }
  }));
  $('new-user').addEventListener('click', userForm);
  content.querySelectorAll('[data-user-role]').forEach(control => control.addEventListener('change', async () => {
    try { toast(await api(`/users/${control.dataset.userRole}/role`, { method: 'PUT', body: JSON.stringify({ role: control.value }) })); }
    catch (error) { showError(error); await settingsPage(); }
  }));
  content.querySelectorAll('[data-user-status]').forEach(button => button.addEventListener('click', async () => {
    if (!confirmAction(`确认${button.textContent}这个登录账号？`)) return;
    try { toast(await api(`/users/${button.dataset.userStatus}/status`, { method: 'PUT', body: JSON.stringify({ active: button.dataset.active === 'true' }) })); await settingsPage(); }
    catch (error) { showError(error); }
  }));
  content.querySelectorAll('[data-reset-password]').forEach(button => button.addEventListener('click', () => resetUserPassword(button.dataset.resetPassword)));
  $('export-audit').addEventListener('click', () => downloadCsv(`齐沐堂操作日志_${today()}.csv`, [
    { label: '时间', value: 'created_at' }, { label: '操作人', value: 'user_name' }, { label: '类型', value: 'type' },
    { label: '内容', value: 'content' }, { label: 'IP', value: 'ip' }
  ], logs));
}

function userForm() {
  modal('新增登录账号', `
    <div class="form-grid two">
      ${field('登录账号 *', input('user-username', '3-30位字母数字下划线'))}
      ${field('员工姓名 *', input('user-name', '显示姓名'))}
      ${field('角色', select('user-role', ['管理员', '店长', '前台', '技师']))}
      ${field('初始密码 *', input('user-password', '至少6位', 'password', '123456'))}
    </div>
    <div class="notice">新账号第一次登录时必须修改初始密码。管理员可查看全部数据和修改账号权限，请谨慎分配。</div>
  `, async () => {
    const message = await api('/users', { method: 'POST', body: JSON.stringify({
      username: $('user-username').value.trim(), name: $('user-name').value.trim(),
      role: $('user-role').value, password: $('user-password').value
    }) });
    toast(message);
    await settingsPage();
  });
}

function resetUserPassword(id) {
  modal('重置账号密码', `
    ${field('新初始密码', input('reset-user-password', '至少6位', 'password', '123456'))}
    <div class="notice warning">重置后，该账号下次登录必须再次修改密码。</div>
  `, async () => {
    const password = $('reset-user-password').value;
    if (password.length < 6) throw new Error('密码不能少于6位');
    const message = await api(`/users/${id}/reset-password`, { method: 'POST', body: JSON.stringify({ password }) });
    toast(message);
    await settingsPage();
  }, { saveText: '确认重置' });
}

Object.assign(pages, {
  项目管理: servicesPage,
  员工管理: employeesPage,
  库存管理: inventoryPage,
  采购管理: purchasesPage,
  收支管理: financePage,
  工资提成: payrollPage,
  营业报表: reportsPage,
  回访提醒: followupsPage,
  系统设置: settingsPage
});

bootstrap();
