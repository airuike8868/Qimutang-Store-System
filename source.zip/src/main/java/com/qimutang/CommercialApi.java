package com.qimutang;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@RestController
@RequestMapping("/api")
@CrossOrigin
class CommercialApi {
    private static final List<String> ROLES = List.of("管理员", "店长", "前台", "技师");
    private final JdbcTemplate db;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    CommercialApi(JdbcTemplate db) {
        this.db = db;
    }

    private String now() {
        return LocalDateTime.now().toString();
    }

    private Map<String, Object> ok(Object data) {
        return Map.of("success", true, "data", data);
    }

    private Map<String, Object> fail(String message) {
        return Map.of("success", false, "message", message);
    }

    private long uid(HttpServletRequest request) {
        Object value = request.getAttribute("userId");
        return value instanceof Number ? ((Number) value).longValue() : 0;
    }

    private void require(HttpServletRequest request, String... roles) {
        String role = String.valueOf(request.getAttribute("role"));
        if (Arrays.stream(roles).noneMatch(role::equals)) {
            throw new IllegalArgumentException("当前账号没有此操作权限");
        }
    }

    private BigDecimal decimal(Object value, String label) {
        try {
            return new BigDecimal(String.valueOf(value == null || String.valueOf(value).isBlank() ? 0 : value));
        } catch (Exception e) {
            throw new IllegalArgumentException(label + "格式不正确");
        }
    }

    private Long nullableLong(Object value) {
        if (value == null || String.valueOf(value).isBlank() || "null".equals(String.valueOf(value))) return null;
        try {
            return Long.parseLong(String.valueOf(value));
        } catch (Exception e) {
            throw new IllegalArgumentException("编号格式不正确");
        }
    }

    private void log(HttpServletRequest request, String type, String content) {
        String time = now();
        db.update("insert into audit_logs(user_id,type,content,ip,created_at,updated_at) values(?,?,?,?,?,?)",
                uid(request), type, content, request.getRemoteAddr(), time, time);
    }

    @GetMapping("/health")
    Object health() {
        return ok(Map.of("status", "UP", "version", "2.0.0"));
    }

    @GetMapping("/dashboard/extended")
    Object dashboardExtended() {
        String month = LocalDate.now().toString().substring(0, 7);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("monthSales", db.queryForObject(
                "select coalesce((select sum(received) from orders where deleted=0 and status!='已取消' and created_at like ?),0)-coalesce((select sum(amount) from refunds where deleted=0 and created_at like ?),0)",
                BigDecimal.class, month + "%", month + "%"));
        result.put("monthExpenses", db.queryForObject(
                "select coalesce(sum(amount),0) from finance_records where deleted=0 and direction='支出' and business_date like ?",
                BigDecimal.class, month + "%"));
        result.put("memberBalance", db.queryForObject(
                "select coalesce(sum(balance_principal+balance_gift),0) from customers where deleted=0",
                BigDecimal.class));
        result.put("lowStock", db.queryForObject(
                "select count(*) from inventory where deleted=0 and quantity<=min_quantity",
                Integer.class));
        result.put("followupsDue", db.queryForObject(
                "select count(*) from followups where deleted=0 and status='待回访' and date(plan_date)<=date('now')",
                Integer.class));
        result.put("careDue", db.queryForObject(
                "select count(*) from care_records where deleted=0 and next_date is not null and date(next_date)<=date('now','+7 day')",
                Integer.class));
        return ok(result);
    }

    @GetMapping("/users")
    Object users(HttpServletRequest request) {
        require(request, "管理员");
        return ok(db.queryForList(
                "select id,username,name,role,first_login,last_login_at,created_at,case when deleted=0 then 1 else 0 end active from users order by id"));
    }

    @PostMapping("/users")
    Object addUser(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员");
        String username = String.valueOf(body.getOrDefault("username", "")).trim();
        String name = String.valueOf(body.getOrDefault("name", "")).trim();
        String role = String.valueOf(body.getOrDefault("role", ""));
        String password = String.valueOf(body.getOrDefault("password", ""));
        if (!username.matches("[A-Za-z0-9_]{3,30}")) return fail("账号只能使用3至30位字母、数字或下划线");
        if (name.isBlank()) return fail("请输入员工姓名");
        if (!ROLES.contains(role)) return fail("账号角色不正确");
        if (password.length() < 6) return fail("初始密码不能少于6位");
        String time = now();
        try {
            db.update("insert into users(username,password,name,role,first_login,created_at,updated_at,deleted) values(?,?,?,?,1,?,?,0)",
                    username, encoder.encode(password), name, role, time, time);
        } catch (Exception e) {
            return fail("该登录账号已经存在");
        }
        log(request, "账号管理", "创建账号：" + username + "（" + role + "）");
        return ok("账号创建成功，首次登录必须修改密码");
    }

    @PutMapping("/users/{id}/status")
    Object userStatus(@PathVariable long id, @RequestBody Map<String, Object> body,
                      HttpServletRequest request) {
        require(request, "管理员");
        boolean active = Boolean.parseBoolean(String.valueOf(body.getOrDefault("active", false)));
        if (id == uid(request) && !active) return fail("不能停用当前正在登录的账号");
        int changed = db.update("update users set deleted=?,updated_at=? where id=?",
                active ? 0 : 1, now(), id);
        if (changed == 0) return fail("账号不存在");
        log(request, "账号管理", (active ? "启用" : "停用") + "账号ID：" + id);
        return ok(active ? "账号已启用" : "账号已停用");
    }

    @PutMapping("/users/{id}/role")
    Object userRole(@PathVariable long id, @RequestBody Map<String, Object> body,
                    HttpServletRequest request) {
        require(request, "管理员");
        String role = String.valueOf(body.getOrDefault("role", ""));
        if (!ROLES.contains(role)) return fail("账号角色不正确");
        if (id == uid(request) && !"管理员".equals(role)) return fail("不能取消当前账号的管理员权限");
        int changed = db.update("update users set role=?,updated_at=? where id=? and deleted=0",
                role, now(), id);
        if (changed == 0) return fail("账号不存在或已停用");
        log(request, "账号管理", "调整账号ID " + id + " 的角色为：" + role);
        return ok("角色已更新，下一次操作立即生效");
    }

    @PostMapping("/users/{id}/reset-password")
    Object resetPassword(@PathVariable long id, @RequestBody Map<String, Object> body,
                         HttpServletRequest request) {
        require(request, "管理员");
        String password = String.valueOf(body.getOrDefault("password", ""));
        if (password.length() < 6) return fail("新密码不能少于6位");
        int changed = db.update("update users set password=?,first_login=1,updated_at=? where id=?",
                encoder.encode(password), now(), id);
        if (changed == 0) return fail("账号不存在");
        log(request, "账号管理", "重置账号ID " + id + " 的密码");
        return ok("密码已重置，该账号下次登录必须修改密码");
    }

    @GetMapping("/settings/store")
    Object storeSettings() {
        Map<String, String> result = new LinkedHashMap<>();
        db.queryForList("select key,value from settings where deleted=0").forEach(row ->
                result.put(String.valueOf(row.get("key")), Objects.toString(row.get("value"), "")));
        return ok(result);
    }

    @PutMapping("/settings/store")
    Object saveStoreSettings(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员");
        List<String> keys = List.of("store_name", "store_phone", "store_address");
        String time = now();
        for (String key : keys) {
            if (!body.containsKey(key)) continue;
            db.update("insert into settings(key,value,description,created_at,updated_at,deleted) values(?,?,?, ?,?,0) " +
                            "on conflict(key) do update set value=excluded.value,updated_at=excluded.updated_at,deleted=0",
                    key, Objects.toString(body.get(key), ""), key, time, time);
        }
        log(request, "系统设置", "更新门店资料");
        return ok("门店资料已保存");
    }

    @GetMapping("/customers/{id}/profile")
    Object customerProfile(@PathVariable long id) {
        List<Map<String, Object>> customers = db.queryForList(
                "select * from customers where id=? and deleted=0", id);
        if (customers.isEmpty()) return fail("顾客不存在");
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("customer", customers.get(0));
        result.put("orders", db.queryForList(
                "select id,order_no,received,status,created_at from orders where customer_id=? and deleted=0 order by id desc limit 30", id));
        result.put("careRecords", db.queryForList(
                "select id,type,stage,care_date,next_date,before_photo,after_photo from care_records where customer_id=? and deleted=0 order by id desc limit 30", id));
        result.put("balanceLogs", db.queryForList(
                "select * from balance_logs where customer_id=? and deleted=0 order by id desc limit 50", id));
        result.put("packages", db.queryForList(
                "select p.*,s.name service_name from packages p left join services s on s.id=p.service_id where p.customer_id=? and p.deleted=0 order by p.id desc", id));
        return ok(result);
    }

    @PutMapping("/customers/{id}")
    Object updateCustomer(@PathVariable long id, @RequestBody Map<String, Object> body,
                          HttpServletRequest request) {
        require(request, "管理员", "店长", "前台", "技师");
        String name = Objects.toString(body.get("name"), "").trim();
        String phone = Objects.toString(body.get("phone"), "").trim();
        if (name.isBlank() || phone.isBlank()) return fail("姓名和手机号不能为空");
        try {
            int changed = db.update("update customers set name=?,phone=?,gender=?,age=?,birthday=?,source=?,address=?,remark=?,updated_at=? where id=? and deleted=0",
                    name, phone, body.get("gender"), body.get("age"), body.get("birthday"),
                    body.get("source"), body.get("address"), body.get("remark"), now(), id);
            if (changed == 0) return fail("顾客不存在");
        } catch (Exception e) {
            return fail("手机号已被其他顾客使用");
        }
        log(request, "顾客管理", "修改顾客资料：" + name);
        return ok("顾客资料已更新");
    }

    @Transactional
    @PostMapping("/members/adjust")
    Object adjustMemberBalance(@RequestBody Map<String, Object> body,
                               HttpServletRequest request) {
        require(request, "管理员", "店长");
        long customerId = Long.parseLong(String.valueOf(body.get("customerId")));
        BigDecimal principalChange = decimal(body.get("principalChange"), "本金变动");
        BigDecimal giftChange = decimal(body.get("giftChange"), "赠送金变动");
        String reason = Objects.toString(body.get("reason"), "").trim();
        if (principalChange.signum() == 0 && giftChange.signum() == 0) return fail("请输入余额变动金额");
        if (reason.length() < 2) return fail("请填写调整原因");
        Map<String, Object> customer;
        try {
            customer = db.queryForMap("select name,balance_principal,balance_gift from customers where id=? and deleted=0", customerId);
        } catch (Exception e) {
            return fail("顾客不存在");
        }
        BigDecimal principal = decimal(customer.get("balance_principal"), "本金余额");
        BigDecimal gift = decimal(customer.get("balance_gift"), "赠送金余额");
        BigDecimal before = principal.add(gift);
        if (principal.add(principalChange).signum() < 0 || gift.add(giftChange).signum() < 0) {
            return fail("调整后余额不能小于0");
        }
        BigDecimal change = principalChange.add(giftChange);
        String time = now();
        db.update("update customers set balance_principal=balance_principal+?,balance_gift=balance_gift+?,updated_at=? where id=?",
                principalChange, giftChange, time, customerId);
        db.update("insert into balance_logs(customer_id,type,before_amount,change_amount,after_amount,operator_id,remark,created_at,updated_at) values(?,?,?,?,?,?,?,?,?)",
                customerId, "人工调整", before, change, before.add(change), uid(request),
                "本金" + principalChange + "，赠送金" + giftChange + "；" + reason, time, time);
        log(request, "会员余额调整", customer.get("name") + "：本金" + principalChange + "，赠送金" + giftChange + "；" + reason);
        return ok("余额调整成功，当前合计：" + before.add(change));
    }

    @GetMapping("/suppliers")
    Object suppliers() {
        return ok(db.queryForList("select * from suppliers where deleted=0 order by id desc"));
    }

    @PostMapping("/suppliers")
    Object addSupplier(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长");
        String name = Objects.toString(body.get("name"), "").trim();
        if (name.isBlank()) return fail("请输入供应商名称");
        String time = now();
        db.update("insert into suppliers(name,contact,phone,address,remark,status,created_at,updated_at) values(?,?,?,?,?,'启用',?,?)",
                name, body.get("contact"), body.get("phone"), body.get("address"),
                body.get("remark"), time, time);
        log(request, "供应商管理", "新增供应商：" + name);
        return ok("供应商已保存");
    }

    @GetMapping("/purchases")
    Object purchases(@RequestParam(required = false) String month) {
        String selected = month == null || month.isBlank()
                ? LocalDate.now().toString().substring(0, 7) : month;
        return ok(db.queryForList(
                "select p.*,i.name inventory_name,i.unit,s.name supplier_name,u.name operator_name " +
                        "from purchases p left join inventory i on i.id=p.inventory_id " +
                        "left join suppliers s on s.id=p.supplier_id left join users u on u.id=p.operator_id " +
                        "where p.deleted=0 and p.business_date like ? order by p.business_date desc,p.id desc",
                selected + "%"));
    }

    @Transactional
    @PostMapping("/purchases")
    Object addPurchase(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员", "店长");
        long inventoryId = Long.parseLong(String.valueOf(body.get("inventoryId")));
        Long supplierId = nullableLong(body.get("supplierId"));
        BigDecimal quantity = decimal(body.get("quantity"), "采购数量");
        BigDecimal unitCost = decimal(body.get("unitCost"), "采购单价");
        if (quantity.signum() <= 0) return fail("采购数量必须大于0");
        if (unitCost.signum() < 0) return fail("采购单价不能小于0");
        Map<String, Object> inventory;
        try {
            inventory = db.queryForMap("select * from inventory where id=? and deleted=0", inventoryId);
        } catch (Exception e) {
            return fail("库存商品不存在");
        }
        BigDecimal before = decimal(inventory.get("quantity"), "原库存");
        BigDecimal oldCost = decimal(inventory.get("cost_price"), "原成本");
        BigDecimal after = before.add(quantity);
        BigDecimal weightedCost = after.signum() == 0 ? unitCost
                : before.multiply(oldCost).add(quantity.multiply(unitCost))
                .divide(after, 2, RoundingMode.HALF_UP);
        BigDecimal total = quantity.multiply(unitCost).setScale(2, RoundingMode.HALF_UP);
        String date = Objects.toString(body.get("businessDate"), LocalDate.now().toString());
        String method = Objects.toString(body.get("paymentMethod"), "现金");
        String purchaseNo = "CG" + System.currentTimeMillis();
        String time = now();
        db.update("insert into purchases(purchase_no,inventory_id,supplier_id,quantity,unit_cost,total_amount,business_date,payment_method,status,operator_id,remark,created_at,updated_at) values(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                purchaseNo, inventoryId, supplierId, quantity, unitCost, total, date, method,
                "未付款".equals(method) ? "已入库未付款" : "已入库", uid(request),
                body.get("remark"), time, time);
        db.update("update inventory set quantity=?,cost_price=?,supplier=coalesce((select name from suppliers where id=?),supplier),updated_at=? where id=?",
                after, weightedCost, supplierId, time, inventoryId);
        db.update("insert into inventory_logs(inventory_id,type,before_qty,change_qty,after_qty,unit_cost,operator_id,remark,created_at,updated_at) values(?,'采购入库',?,?,?,?,?,?,?,?)",
                inventoryId, before, quantity, after, unitCost, uid(request), purchaseNo, time, time);
        if (!"未付款".equals(method) && total.signum() > 0) {
            db.update("insert into finance_records(business_date,direction,category,amount,payment_method,operator_id,remark,created_at,updated_at) values(?,'支出','采购进货',?,?,?,?,?,?)",
                    date, total, method, uid(request), purchaseNo + " " + inventory.get("name"), time, time);
        }
        log(request, "采购入库", purchaseNo + "，" + inventory.get("name") + "，数量" + quantity + "，金额" + total);
        return ok(Map.of("purchaseNo", purchaseNo, "total", total, "stock", after));
    }

    @GetMapping("/inventory/{id}/logs")
    Object inventoryLogs(@PathVariable long id) {
        return ok(db.queryForList(
                "select l.*,u.name operator_name from inventory_logs l left join users u on u.id=l.operator_id where l.inventory_id=? and l.deleted=0 order by l.id desc limit 200",
                id));
    }

    @PutMapping("/employees/{id}")
    Object updateEmployee(@PathVariable long id, @RequestBody Map<String, Object> body,
                          HttpServletRequest request) {
        require(request, "管理员", "店长");
        BigDecimal baseSalary = decimal(body.get("baseSalary"), "底薪");
        if (baseSalary.signum() < 0) return fail("底薪不能小于0");
        int changed = db.update("update employees set name=?,phone=?,position=?,hire_date=?,status=?,base_salary=?,commission_rule=?,updated_at=? where id=? and deleted=0",
                body.get("name"), body.get("phone"), body.get("position"), body.get("hireDate"),
                body.getOrDefault("status", "在职"), baseSalary, body.get("commissionRule"), now(), id);
        if (changed == 0) return fail("员工不存在");
        log(request, "员工管理", "修改员工ID：" + id);
        return ok("员工资料已更新");
    }

    @GetMapping("/payroll")
    Object payroll(@RequestParam String from, @RequestParam String to,
                   HttpServletRequest request) {
        require(request, "管理员", "店长");
        List<Map<String, Object>> result = new ArrayList<>();
        for (Map<String, Object> employee : db.queryForList(
                "select * from employees where deleted=0 and status='在职' order by id")) {
            long employeeId = ((Number) employee.get("id")).longValue();
            BigDecimal commission = netCommission(employeeId, from, to);
            Map<String, Object> row = new LinkedHashMap<>(employee);
            row.put("commission", commission);
            row.put("payable", decimal(employee.get("base_salary"), "底薪").add(commission));
            row.put("settled", db.queryForObject(
                    "select count(*) from salary_settlements where employee_id=? and period_start=? and period_end=? and deleted=0",
                    Integer.class, employeeId, from, to));
            result.add(row);
        }
        return ok(result);
    }

    private BigDecimal netCommission(long employeeId, String from, String to) {
        BigDecimal value = db.queryForObject(
                "select coalesce(sum(c.amount * case when o.received>0 then max(0,1-coalesce((select sum(r.amount) from refunds r where r.order_id=o.id and r.deleted=0),0)/o.received) else 1 end),0) " +
                        "from commissions c left join orders o on o.id=c.order_id " +
                        "where c.employee_id=? and c.deleted=0 and date(c.created_at) between date(?) and date(?)",
                BigDecimal.class, employeeId, from, to);
        return value == null ? BigDecimal.ZERO : value.setScale(2, RoundingMode.HALF_UP);
    }

    @Transactional
    @PostMapping("/payroll/settle")
    Object settlePayroll(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        require(request, "管理员");
        long employeeId = Long.parseLong(String.valueOf(body.get("employeeId")));
        String from = Objects.toString(body.get("from"), "");
        String to = Objects.toString(body.get("to"), "");
        if (from.isBlank() || to.isBlank() || LocalDate.parse(from).isAfter(LocalDate.parse(to))) {
            return fail("工资结算日期不正确");
        }
        Map<String, Object> employee;
        try {
            employee = db.queryForMap("select * from employees where id=? and deleted=0", employeeId);
        } catch (Exception e) {
            return fail("员工不存在");
        }
        BigDecimal base = decimal(employee.get("base_salary"), "底薪");
        BigDecimal commission = netCommission(employeeId, from, to);
        BigDecimal adjustment = decimal(body.get("adjustment"), "调整金额");
        BigDecimal total = base.add(commission).add(adjustment).setScale(2, RoundingMode.HALF_UP);
        if (total.signum() < 0) return fail("实发工资不能小于0");
        String method = Objects.toString(body.get("paymentMethod"), "银行卡");
        String time = now();
        try {
            db.update("insert into salary_settlements(employee_id,period_start,period_end,base_salary,commission,adjustment,total,payment_method,operator_id,remark,paid_at,created_at,updated_at) values(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    employeeId, from, to, base, commission, adjustment, total, method,
                    uid(request), body.get("remark"), time, time, time);
        } catch (Exception e) {
            return fail("该员工在这个日期范围内已经结算过");
        }
        db.update("update commissions set settled=1,settled_at=?,updated_at=? where employee_id=? and deleted=0 and date(created_at) between date(?) and date(?)",
                time, time, employeeId, from, to);
        if (total.signum() > 0) {
            db.update("insert into finance_records(business_date,direction,category,amount,payment_method,operator_id,remark,created_at,updated_at) values(?,'支出','工资提成',?,?,?,?,?,?)",
                    LocalDate.now().toString(), total, method, uid(request),
                    employee.get("name") + " " + from + "至" + to + "工资结算", time, time);
        }
        log(request, "工资结算", employee.get("name") + "，" + from + "至" + to + "，实发" + total);
        return ok("工资结算成功，实发：" + total);
    }

    @GetMapping("/payroll/settlements")
    Object payrollSettlements(HttpServletRequest request) {
        require(request, "管理员", "店长");
        return ok(db.queryForList(
                "select s.*,e.name employee_name,u.name operator_name from salary_settlements s left join employees e on e.id=s.employee_id left join users u on u.id=s.operator_id where s.deleted=0 order by s.id desc limit 500"));
    }

    @PutMapping("/services/{id}")
    Object updateService(@PathVariable long id, @RequestBody Map<String, Object> body,
                         HttpServletRequest request) {
        require(request, "管理员", "店长");
        BigDecimal listPrice = decimal(body.get("listPrice"), "门市价");
        BigDecimal memberPrice = decimal(body.get("memberPrice"), "会员价");
        BigDecimal commission = decimal(body.get("commissionValue"), "提成");
        if (listPrice.signum() < 0 || memberPrice.signum() < 0 || commission.signum() < 0) {
            return fail("价格和提成不能小于0");
        }
        int changed = db.update("update services set name=?,category=?,duration=?,list_price=?,member_price=?,commission_type=?,commission_value=?,status=?,remark=?,updated_at=? where id=? and deleted=0",
                body.get("name"), body.get("category"), body.get("duration"), listPrice,
                memberPrice, body.getOrDefault("commissionType", "FIXED"), commission,
                Boolean.parseBoolean(String.valueOf(body.getOrDefault("status", true))) ? 1 : 0,
                body.get("remark"), now(), id);
        if (changed == 0) return fail("项目不存在");
        log(request, "项目管理", "修改项目ID：" + id);
        return ok("项目已更新");
    }
}
