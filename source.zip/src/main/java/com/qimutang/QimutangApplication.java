package com.qimutang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.awt.Desktop;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.URI;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@SpringBootApplication
@EnableScheduling
public class QimutangApplication {
    private static FileChannel instanceChannel;
    private static FileLock instanceLock;

    public static void main(String[] args) throws Exception {
        Path dataDir = Path.of(System.getProperty(
                "qimutang.data-dir",
                Path.of(System.getProperty("user.home"), "QimutangData", "data").toString()
        )).toAbsolutePath().normalize();

        System.setProperty("qimutang.data-dir", dataDir.toString());
        Files.createDirectories(dataDir.resolve("uploads/customer"));
        Files.createDirectories(dataDir.resolve("backup"));
        applyPendingRestore(dataDir);

        Path lockPath = dataDir.resolve("qimutang.running.lock");
        instanceChannel = FileChannel.open(lockPath,
                StandardOpenOption.CREATE, StandardOpenOption.WRITE);
        try {
            instanceLock = instanceChannel.tryLock();
        } catch (Exception ignored) {
            instanceLock = null;
        }

        if (instanceLock == null) {
            int runningPort = readPort(dataDir.resolve("server.port"), 8080);
            openBrowserWhenReady(runningPort, 20);
            return;
        }

        int requestedPort = Integer.getInteger("server.port", 8080);
        int port = chooseAvailablePort(requestedPort);
        System.setProperty("server.port", String.valueOf(port));
        Files.writeString(dataDir.resolve("server.port"), String.valueOf(port),
                StandardCharsets.UTF_8, StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING);

        SpringApplication.run(QimutangApplication.class, args);
        openBrowserWhenReady(port, 30);
    }

    private static int chooseAvailablePort(int preferred) {
        for (int candidate = preferred; candidate < preferred + 20; candidate++) {
            try (ServerSocket socket = new ServerSocket()) {
                socket.setReuseAddress(false);
                socket.bind(new InetSocketAddress("127.0.0.1", candidate));
                return candidate;
            } catch (IOException ignored) {
                // Try the next local port. This avoids an unexplained startup failure.
            }
        }
        throw new IllegalStateException("系统端口被占用，请关闭其他本地服务后重试");
    }

    private static int readPort(Path portFile, int fallback) {
        try {
            int port = Integer.parseInt(Files.readString(portFile).trim());
            return port > 0 && port <= 65535 ? port : fallback;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static void openBrowserWhenReady(int port, int attempts) {
        Thread opener = new Thread(() -> {
            String url = "http://127.0.0.1:" + port;
            for (int i = 0; i < attempts; i++) {
                try {
                    HttpURLConnection connection = (HttpURLConnection)
                            URI.create(url + "/api/health").toURL().openConnection();
                    connection.setConnectTimeout(800);
                    connection.setReadTimeout(800);
                    if (connection.getResponseCode() == 200) {
                        if (Desktop.isDesktopSupported()) {
                            Desktop.getDesktop().browse(URI.create(url));
                        }
                        return;
                    }
                } catch (Exception ignored) {
                    // The embedded server is still starting.
                }
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }, "qimutang-browser-opener");
        opener.setDaemon(true);
        opener.start();
    }

    private static void applyPendingRestore(Path dataDir) throws IOException {
        Path marker = dataDir.resolve("restore.pending");
        if (!Files.isRegularFile(marker)) return;

        String fileName = Files.readString(marker, StandardCharsets.UTF_8).trim();
        if (!fileName.matches("qimutang_[A-Za-z0-9_-]+\\.db")) {
            Files.deleteIfExists(marker);
            return;
        }

        Path backupDir = dataDir.resolve("backup").normalize();
        Path source = backupDir.resolve(fileName).normalize();
        if (!source.startsWith(backupDir) || !Files.isRegularFile(source)) {
            Files.deleteIfExists(marker);
            return;
        }

        Path database = dataDir.resolve("qimutang.db");
        if (Files.isRegularFile(database)) {
            String stamp = LocalDateTime.now().format(
                    DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS"));
            Files.copy(database, backupDir.resolve("qimutang_before_restore_" + stamp + ".db"),
                    StandardCopyOption.COPY_ATTRIBUTES);
        }

        Files.deleteIfExists(dataDir.resolve("qimutang.db-wal"));
        Files.deleteIfExists(dataDir.resolve("qimutang.db-shm"));
        Files.copy(source, database, StandardCopyOption.REPLACE_EXISTING,
                StandardCopyOption.COPY_ATTRIBUTES);
        Files.deleteIfExists(marker);
    }
}
