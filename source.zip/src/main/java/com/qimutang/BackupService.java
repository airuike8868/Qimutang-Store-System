package com.qimutang;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Value;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
class BackupService {
 private final Path data;
 private final JdbcTemplate db; BackupService(JdbcTemplate db,@Value("${qimutang.data-dir}")String dataDir){this.db=db;this.data=Paths.get(dataDir).toAbsolutePath().normalize();}
 @PostConstruct void init() throws Exception {Files.createDirectories(data.resolve("backup"));Files.createDirectories(data.resolve("uploads/customer"));backupOnceDaily();}
 @Scheduled(cron="0 5 2 * * *") synchronized void backupOnceDaily() throws Exception {Path file=data.resolve("qimutang.db");if(!Files.exists(file))return;Path target=data.resolve("backup/qimutang_"+LocalDate.now()+".db");if(!Files.exists(target)){db.execute("PRAGMA wal_checkpoint(FULL)");Files.copy(file,target,StandardCopyOption.COPY_ATTRIBUTES);}}
 synchronized Path backupNow() throws Exception {Path file=data.resolve("qimutang.db");if(!Files.exists(file))throw new IllegalArgumentException("数据库文件不存在");db.execute("PRAGMA wal_checkpoint(FULL)");String stamp=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS"));Path target=data.resolve("backup/qimutang_"+stamp+".db");Files.copy(file,target,StandardCopyOption.COPY_ATTRIBUTES);return target;}
 List<Map<String,Object>> list() throws Exception {List<Map<String,Object>>out=new ArrayList<>();try(var s=Files.list(data.resolve("backup"))){s.filter(p->p.getFileName().toString().endsWith(".db")).sorted(Comparator.reverseOrder()).forEach(p->{try{out.add(Map.of("name",p.getFileName().toString(),"size",Files.size(p),"modifiedAt",Files.getLastModifiedTime(p).toString()));}catch(Exception ignored){}});}return out;}
 synchronized void scheduleRestore(String name)throws Exception{if(name==null||!name.matches("qimutang_[A-Za-z0-9_-]+\\.db"))throw new IllegalArgumentException("备份文件名不合法");Path source=data.resolve("backup").resolve(name).normalize();if(!source.startsWith(data.resolve("backup"))||!Files.isRegularFile(source))throw new IllegalArgumentException("备份文件不存在");backupNow();Files.writeString(data.resolve("restore.pending"),name,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING);}
}

@RestController @RequestMapping("/api/system")
class BackupApi {
 private final BackupService backups; BackupApi(BackupService backups){this.backups=backups;}
 private void admin(HttpServletRequest r){if(!"管理员".equals(String.valueOf(r.getAttribute("role"))))throw new IllegalArgumentException("只有管理员可以操作数据备份");}
 @GetMapping("/backups") Object list(HttpServletRequest r)throws Exception{admin(r);return Map.of("success",true,"data",backups.list());}
 @PostMapping("/backup") Object backup(HttpServletRequest r)throws Exception{admin(r);return Map.of("success",true,"data",backups.backupNow().getFileName().toString());}
 @PostMapping("/restore") Object restore(@RequestBody Map<String,String>b,HttpServletRequest r)throws Exception{admin(r);backups.scheduleRestore(b.get("name"));return Map.of("success",true,"data","恢复任务已准备，请关闭系统后重新双击启动");}
}
