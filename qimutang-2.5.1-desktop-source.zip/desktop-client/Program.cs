using System.Diagnostics;
using System.Net;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace QimutangDesktop;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

internal sealed class MainForm : Form
{
    private readonly WebView2 webView = new() { Dock = DockStyle.Fill };
    private readonly Label statusLabel = new()
    {
        Dock = DockStyle.Fill,
        TextAlign = ContentAlignment.MiddleCenter,
        Font = new Font("Microsoft YaHei UI", 12F),
        Text = "正在启动齐沐堂门店管理系统…"
    };
    private Process? backendProcess;
    private bool startedBackend;
    private bool closing;

    private string DataDir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
        "QimutangData", "data");

    public MainForm()
    {
        Text = "齐沐堂门店管理系统 2.5.1";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1100, 720);
        Width = 1440;
        Height = 900;
        WindowState = FormWindowState.Maximized;

        try
        {
            var iconPath = Path.Combine(AppContext.BaseDirectory, "qimutang.ico");
            if (File.Exists(iconPath)) Icon = new Icon(iconPath);
        }
        catch { }

        Controls.Add(statusLabel);
        Shown += async (_, _) => await StartAsync();
        FormClosing += OnFormClosing;
    }

    private async Task StartAsync()
    {
        try
        {
            Directory.CreateDirectory(DataDir);

            var existingUrl = await FindRunningServerAsync(TimeSpan.FromSeconds(2));
            if (existingUrl is null)
            {
                StartBackend();
                existingUrl = await FindRunningServerAsync(TimeSpan.FromSeconds(45));
            }

            if (existingUrl is null)
                throw new InvalidOperationException("本地服务启动超时，请重新打开软件。若仍失败，请查看 QimutangData\\data\\logs 下的日志。 ");

            await ShowWebViewAsync(existingUrl);
        }
        catch (Exception ex)
        {
            statusLabel.Text = "启动失败\r\n\r\n" + ex.Message;
            MessageBox.Show(ex.Message, "齐沐堂门店管理系统", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void StartBackend()
    {
        var baseDir = AppContext.BaseDirectory;
        var java = Path.Combine(baseDir, "runtime", "bin", "javaw.exe");
        var jar = Path.Combine(baseDir, "app", "qimutang.jar");

        if (!File.Exists(java))
            throw new FileNotFoundException("客户端缺少 Java 运行环境。", java);
        if (!File.Exists(jar))
            throw new FileNotFoundException("客户端缺少 qimutang.jar。", jar);

        var psi = new ProcessStartInfo
        {
            FileName = java,
            Arguments = $"-Dfile.encoding=UTF-8 -Dqimutang.desktop=true -jar \"{jar}\"",
            WorkingDirectory = baseDir,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        backendProcess = Process.Start(psi) ?? throw new InvalidOperationException("无法启动齐沐堂后台服务。 ");
        startedBackend = true;
    }

    private async Task<string?> FindRunningServerAsync(TimeSpan timeout)
    {
        var end = DateTime.UtcNow + timeout;
        using var http = new HttpClient { Timeout = TimeSpan.FromMilliseconds(900) };

        while (DateTime.UtcNow < end)
        {
            var port = ReadServerPort();
            var url = $"http://127.0.0.1:{port}";
            try
            {
                using var response = await http.GetAsync(url + "/api/health");
                if (response.StatusCode == HttpStatusCode.OK)
                    return url;
            }
            catch { }

            await Task.Delay(400);
        }

        return null;
    }

    private int ReadServerPort()
    {
        try
        {
            var file = Path.Combine(DataDir, "server.port");
            if (File.Exists(file) && int.TryParse(File.ReadAllText(file).Trim(), out var port)
                && port is > 0 and <= 65535)
                return port;
        }
        catch { }
        return 8080;
    }

    private async Task ShowWebViewAsync(string url)
    {
        var webData = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "QimutangStoreSystem", "WebView2");
        Directory.CreateDirectory(webData);

        CoreWebView2Environment environment;
        try
        {
            environment = await CoreWebView2Environment.CreateAsync(null, webData);
        }
        catch (WebView2RuntimeNotFoundException)
        {
            throw new InvalidOperationException("电脑缺少 Microsoft Edge WebView2 Runtime。请安装 WebView2 Runtime 后重新打开齐沐堂系统。 ");
        }

        Controls.Clear();
        Controls.Add(webView);
        await webView.EnsureCoreWebView2Async(environment);

        webView.CoreWebView2.Settings.AreDevToolsEnabled = false;
        webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
        webView.CoreWebView2.Settings.IsStatusBarEnabled = false;
        webView.CoreWebView2.Settings.IsZoomControlEnabled = true;
        webView.CoreWebView2.NewWindowRequested += (_, e) =>
        {
            e.Handled = true;
            webView.CoreWebView2.Navigate(e.Uri);
        };
        webView.Source = new Uri(url);
    }

    private void OnFormClosing(object? sender, FormClosingEventArgs e)
    {
        if (closing) return;
        closing = true;

        if (!startedBackend) return;

        try
        {
            Directory.CreateDirectory(DataDir);
            File.WriteAllText(Path.Combine(DataDir, "shutdown.request"), DateTime.Now.ToString("O"));
        }
        catch { }

        try
        {
            if (backendProcess is { HasExited: false })
            {
                if (!backendProcess.WaitForExit(2500))
                    backendProcess.Kill(entireProcessTree: true);
            }
        }
        catch { }
    }
}
