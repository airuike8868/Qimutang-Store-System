package com.qimutang;

import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.DependsOn;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * 2.5.1 桌面客户端版兼容迁移。
 * 只做向前兼容变更，不删除历史经营数据。
 */
@Component
@DependsOn("v23Migration")
class V25Migration {
    private final JdbcTemplate db;

    V25Migration(JdbcTemplate db) {
        this.db = db;
    }

    @PostConstruct
    void migrate() {
        String tableSql = "create table if not exists package_templates(" +
                (DbCompat.isMySql(db) ? "id bigint primary key auto_increment," : "id integer primary key autoincrement,") +
                (DbCompat.isMySql(db) ? "name varchar(191) not null," : "name text not null,") +
                "template_type text not null default '次卡'," +
                "service_id integer," +
                "total_times integer default 1," +
                "price decimal default 0," +
                "valid_days integer default 0," +
                "status integer default 1," +
                "remark text," +
                "created_at text,updated_at text,deleted integer default 0)";
        db.execute(tableSql);
        DbCompat.createIndexIfMissing(db,"package_templates","idx_package_templates_status","status,deleted",false);
        if (DbCompat.isMySql(db)) DbCompat.createIndexIfMissing(db,"package_templates","idx_package_templates_name_unique","name,deleted",true);
        else db.execute("create unique index if not exists idx_package_templates_name_unique on package_templates(name) where deleted=0");

        String now = LocalDateTime.now().toString();
        DbCompat.upsertSetting(db,"app_version","2.5.1","系统版本",now);
    }
}
