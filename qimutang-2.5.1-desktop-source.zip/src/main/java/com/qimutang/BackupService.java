package com.qimutang;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.context.annotation.DependsOn;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.zip.*;

@Service
@DependsOn("v23Migration")
class BackupService {
 private final Path data;
 private final JdbcTemplate db; BackupService(JdbcTemplate db,@Value("${qimutang.data-dir}")String dataDir){this.db=db;this.data=Paths.get(dataDir).toAbsolutePath().normalize();}
 @PostConstruct void init() throws Exception {Files.createDirectories(data.resolve("backup"));Files.createDirectories(data.resolve("uploads/customer"));backupOnceDaily();}
 @Scheduled(cron="0 5 2 * * *") synchronized void backupOnceDaily() throws Exception {Path target=data.resolve("backup/qimutang_full_"+LocalDate.now()+".zip");if(Files.exists(target))return;if(DbCompat.isMySql(db))new MySqlLogicalBackup(db, data.resolve("uploads")).exportTo(target);else{Path file=data.resolve("qimutang.db");if(!Files.exists(file))return;fullBackup(target);}cleanupOldBackups();}
 synchronized Path backupNow() throws Exception {String stamp=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS"));if(DbCompat.isMySql(db)){Path target=data.resolve("backup/qimutang_mysql_"+stamp+".zip");new MySqlLogicalBackup(db, data.resolve("uploads")).exportTo(target);return target;}Path file=data.resolve("qimutang.db");if(!Files.exists(file))throw new IllegalArgumentException("数据库文件不存在");db.execute("PRAGMA wal_checkpoint(FULL)");Path target=data.resolve("backup/qimutang_"+stamp+".db");Files.copy(file,target,StandardCopyOption.COPY_ATTRIBUTES);return target;}
 synchronized Path fullBackupNow() throws Exception {String stamp=LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS"));Path target=data.resolve("backup/qimutang_full_"+stamp+".zip");if(DbCompat.isMySql(db))new MySqlLogicalBackup(db, data.resolve("uploads")).exportTo(target);else fullBackup(target);cleanupOldBackups();return target;}
 private void fullBackup(Path target) throws Exception {Path file=data.resolve("qimutang.db");if(!Files.isRegularFile(file))throw new IllegalArgumentException("数据库文件不存在");db.execute("PRAGMA wal_checkpoint(FULL)");Path temp=target.resolveSibling(target.getFileName()+".part");Files.deleteIfExists(temp);try{try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(temp,StandardOpenOption.CREATE_NEW)))){addZip(zip,file,"qimutang.db");Path uploads=data.resolve("uploads");if(Files.isDirectory(uploads)){try(var walk=Files.walk(uploads)){for(Path path:walk.filter(Files::isRegularFile).toList()){String entry="uploads/"+uploads.relativize(path).toString().replace('\\','/');addZip(zip,path,entry);}}}ZipEntry manifest=new ZipEntry("backup-info.txt");zip.putNextEntry(manifest);zip.write(("齐沐堂门店管理系统 2.5.1 整包备份\n生成时间："+LocalDateTime.now()+"\n包含：数据库、护理照片和凭证\n").getBytes(StandardCharsets.UTF_8));zip.closeEntry();}try{Files.move(temp,target,StandardCopyOption.ATOMIC_MOVE);}catch(AtomicMoveNotSupportedException ignored){Files.move(temp,target);}}finally{Files.deleteIfExists(temp);}}
 private void addZip(ZipOutputStream zip,Path source,String name)throws Exception{ZipEntry entry=new ZipEntry(name);entry.setTime(Files.getLastModifiedTime(source).toMillis());zip.putNextEntry(entry);Files.copy(source,zip);zip.closeEntry();}
 private void cleanupOldBackups()throws Exception{Path cutoffMarker=data.resolve("backup");try(var files=Files.list(cutoffMarker)){for(Path path:files.filter(Files::isRegularFile).toList()){String name=path.getFileName().toString();if((name.endsWith(".db")||name.endsWith(".zip"))&&Files.getLastModifiedTime(path).toInstant().isBefore(java.time.Instant.now().minus(java.time.Duration.ofDays(90))))Files.deleteIfExists(path);}}}
 List<Map<String,Object>> list() throws Exception {List<Map<String,Object>>out=new ArrayList<>();try(var s=Files.list(data.resolve("backup"))){s.filter(p->p.getFileName().toString().endsWith(".db")||p.getFileName().toString().endsWith(".zip")).sorted(Comparator.reverseOrder()).forEach(p->{try{out.add(Map.of("name",p.getFileName().toString(),"size",Files.size(p),"modifiedAt",Files.getLastModifiedTime(p).toString(),"full",p.getFileName().toString().endsWith(".zip")));}catch(Exception ignored){}});}return out;}
 Path resolveBackup(String name)throws Exception{if(name==null||!name.matches("qimutang_[A-Za-z0-9_-]+\\.(db|zip)"))throw new IllegalArgumentException("备份文件名不合法");Path root=data.resolve("backup").normalize();Path source=root.resolve(name).normalize();if(!source.startsWith(root)||!Files.isRegularFile(source))throw new IllegalArgumentException("备份文件不存在");return source;}
 synchronized void scheduleRestore(String name)throws Exception{Path source=resolveBackup(name);fullBackupNow();if(DbCompat.isMySql(db)){new MySqlLogicalBackup(db, data.resolve("uploads")).restoreFrom(source);return;}Files.writeString(data.resolve("restore.pending"),source.getFileName().toString(),StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING);}
}

@RestController @RequestMapping("/api/system")
class BackupApi {
 private final BackupService backups; BackupApi(BackupService backups){this.backups=backups;}
 private void admin(HttpServletRequest r){if(!"管理员".equals(String.valueOf(r.getAttribute("role"))))throw new IllegalArgumentException("只有管理员可以操作数据备份");}
 @GetMapping("/backups") Object list(HttpServletRequest r)throws Exception{admin(r);return Map.of("success",true,"data",backups.list());}
 @PostMapping("/backup") Object backup(HttpServletRequest r)throws Exception{admin(r);return Map.of("success",true,"data",backups.fullBackupNow().getFileName().toString());}
 @GetMapping("/backups/{name}/download") ResponseEntity<Resource> download(@PathVariable String name,HttpServletRequest r)throws Exception{admin(r);Path file=backups.resolveBackup(name);String disposition=ContentDisposition.attachment().filename(file.getFileName().toString(),StandardCharsets.UTF_8).build().toString();return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,disposition).contentLength(Files.size(file)).contentType(MediaType.APPLICATION_OCTET_STREAM).body(new FileSystemResource(file));}
 @PostMapping("/restore") Object restore(@RequestBody Map<String,String>b,HttpServletRequest r)throws Exception{admin(r);backups.scheduleRestore(b.get("name"));return Map.of("success",true,"data","数据恢复已执行；SQLite模式重启后生效，MySQL模式立即生效");}
}
