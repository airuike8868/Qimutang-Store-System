# 齐沐堂门店管理系统 2.5.1 Windows 客户端版

本版在 2.5.0 业务系统基础上增加真正的 Windows 桌面客户端：

- 双击 `齐沐堂门店管理系统.exe` 打开独立窗口，不再主动打开浏览器。
- 桌面窗口使用 Microsoft Edge WebView2 承载现有前端，保留全部现有业务功能。
- 客户端自动启动本地 Spring Boot 服务，并读取实际运行端口。
- 关闭客户端时会请求后台服务安全退出。
- 版本号统一为 2.5.1。
- 原数据库目录不变：`%USERPROFILE%\QimutangData\data`，升级不会主动删除历史数据。

说明：Windows 11 通常已包含 WebView2 Runtime；如目标电脑缺失，客户端会给出明确提示。
