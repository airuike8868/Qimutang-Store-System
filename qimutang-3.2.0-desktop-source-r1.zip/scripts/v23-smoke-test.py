#!/usr/bin/env python3
import io
import json
import sys
import time
import urllib.error
import urllib.request
import zipfile
from datetime import date


BASE = (sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:18080").rstrip("/")
TOKEN = None


def raw(path, method="GET", body=None, auth=True):
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(BASE + "/api" + path, data=data, method=method)
    request.add_header("Content-Type", "application/json")
    if auth and TOKEN:
        request.add_header("Authorization", "Bearer " + TOKEN)
    try:
        with urllib.request.urlopen(request, timeout=15) as response:
            return response.read(), response.headers.get_content_type()
    except urllib.error.HTTPError as error:
        return error.read(), error.headers.get_content_type()


def call(path, method="GET", body=None, auth=True):
    content, _ = raw(path, method, body, auth)
    payload = json.loads(content.decode("utf-8"))
    if not payload.get("success"):
        raise AssertionError(f"API failed {path}: {payload.get('message')}")
    return payload.get("data")


def expect_failure(path, method="GET", body=None, contains=None):
    content, _ = raw(path, method, body)
    payload = json.loads(content.decode("utf-8"))
    if payload.get("success"):
        raise AssertionError(f"Expected failure but succeeded: {path}")
    if contains and contains not in payload.get("message", ""):
        raise AssertionError(f"Unexpected failure message: {payload.get('message')}")


def expect(condition, message):
    if not condition:
        raise AssertionError(message)


def login(username, password):
    global TOKEN
    result = call("/auth/login", "POST", {"username": username, "password": password}, auth=False)
    TOKEN = result["token"]
    return result


def main():
    global TOKEN
    health = call("/health", auth=False)
    expect(health["status"] == "UP" and health["version"] in ("2.3.0", "2.5.0", "3.2.0"), "wrong app version")
    index = urllib.request.urlopen(BASE + "/", timeout=10).read().decode("utf-8")
    expect("v23-pages.js?v=3.2.0" in index, "2.3 UI bundle is not active")

    admin = login("admin", "123456")
    if admin.get("firstLogin"):
        call("/auth/change-password", "POST", {"oldPassword": "123456", "newPassword": "SmokePass2026!"})
    login("admin", "SmokePass2026!")

    stamp = str(int(time.time() * 1000))[-10:]
    today = date.today().isoformat()
    call("/v23/shifts/open", "POST", {"openingCash": 200, "remark": "自动化开班"})

    call("/v23/categories", "POST", {"type": "SERVICE", "name": "自动服务类", "sortOrder": 1, "color": "#146fca"})
    service_category = next(row for row in call("/v23/categories?type=SERVICE") if row["name"] == "自动服务类")
    call(f"/v23/categories/{service_category['id']}", "PUT", {"name": "自动护理类", "sortOrder": 1, "color": "#146fca", "enabled": True})
    call("/v23/categories", "POST", {"type": "PRODUCT", "name": "自动产品类", "sortOrder": 1, "color": "#18865c"})

    call("/v23/services", "POST", {
        "name": "自动护理服务", "category": "自动护理类", "duration": 45,
        "listPrice": 59.9, "memberPrice": 49.9,
        "commissionType": "FIXED", "commissionValue": 10, "status": True
    })
    service = next(row for row in call("/services") if row["name"] == "自动护理服务")
    expect(service["category"] == "自动护理类", "service category rename did not cascade")

    call("/customers", "POST", {"name": "测试顾客", "phone": "13" + stamp, "source": "验收"})
    customer = next(row for row in call("/customers") if row["phone"] == "13" + stamp)
    call("/employees", "POST", {"name": "测试技师", "phone": "15" + stamp, "position": "护理师", "hireDate": today, "baseSalary": 2000, "status": "在职"})
    employee = next(row for row in call("/employees") if row["phone"] == "15" + stamp)

    product_result = call("/v23/products", "POST", {
        "name": "自动护理液", "category": "自动产品类", "barcode": "69" + stamp,
        "quantity": 10, "unit": "瓶", "costPrice": 8, "minQuantity": 2,
        "retailPrice": 30, "memberPrice": 25, "retailEnabled": True,
        "productType": "护理产品", "commissionType": "FIXED", "commissionValue": 4
    })
    product_id = product_result["id"]
    expect(any(row["id"] == product_id for row in call("/v23/products?retailOnly=true")), "product is missing from checkout")

    recharge_body = {"clientRequestId": "RECHARGE-" + stamp, "customerId": customer["id"], "amount": 100, "gift": 20, "paymentMethod": "现金", "remark": "验收充值"}
    call("/v23/members/recharge", "POST", recharge_body)
    call("/v23/members/recharge", "POST", recharge_body)
    refreshed = next(row for row in call("/customers") if row["id"] == customer["id"])
    expect(float(refreshed["balance_principal"]) == 100 and float(refreshed["balance_gift"]) == 20, "recharge idempotency failed")

    order_body = {
        "clientRequestId": "ORDER-" + stamp, "customerId": customer["id"], "remark": "服务产品混合销售",
        "items": [
            {"type": "SERVICE", "id": service["id"], "quantity": 1, "price": 49.9, "employeeId": employee["id"]},
            {"type": "PRODUCT", "id": product_id, "quantity": 2, "price": 25, "employeeId": employee["id"]}
        ],
        "payments": [{"method": "会员余额", "amount": 40}, {"method": "现金", "amount": 59.9}]
    }
    order = call("/v23/orders", "POST", order_body)
    duplicate = call("/v23/orders", "POST", order_body)
    expect(duplicate.get("duplicate") is True and duplicate["orderId"] == order["orderId"], "order idempotency failed")
    product = next(row for row in call("/v23/products") if row["id"] == product_id)
    expect(float(product["quantity"]) == 8, "product stock was not deducted")

    detail = call(f"/orders/{order['orderId']}")
    product_item = next(row for row in detail["items"] if row["item_type"] == "PRODUCT")
    refund_body = {"clientRequestId": "REFUND-" + stamp, "reason": "测试退回一瓶", "externalRefundConfirmed": True,
                   "items": [{"orderItemId": product_item["id"], "quantity": 1, "amount": 25, "restock": True}]}
    call(f"/v23/orders/{order['orderId']}/refund-items", "POST", refund_body)
    call(f"/v23/orders/{order['orderId']}/refund-items", "POST", refund_body)
    product = next(row for row in call("/v23/products") if row["id"] == product_id)
    expect(float(product["quantity"]) == 9, "product refund did not restock exactly once")

    performance = call(f"/v23/reports/performance?from={today}&to={today}")
    product_category = next(row for row in performance["categories"] if row["category"] == "自动产品类")
    expect(float(product_category["net_amount"]) == 25, "category net performance is wrong")
    expect(float(product_category["cost_amount"]) == 8, "restocked product cost was not reversed")
    employee_product = next(row for row in performance["employees"] if row["employee_name"] == "测试技师" and row["category"] == "自动产品类")
    expect(float(employee_product["net_commission"]) == 4, "employee refund commission reversal is wrong")

    payroll = call(f"/payroll?from={today}&to={today}")
    pay_row = next(row for row in payroll if row["id"] == employee["id"])
    expect(float(pay_row["commission"]) == 14, f"net commission expected 14, got {pay_row['commission']}")
    call("/payroll/settle", "POST", {"employeeId": employee["id"], "from": today, "to": today, "adjustment": 0, "paymentMethod": "银行卡", "remark": "自动验收工资"})
    expect_failure("/payroll/settle", "POST", {"employeeId": employee["id"], "from": today, "to": today, "adjustment": 0, "paymentMethod": "银行卡"}, "重叠")

    package_body = {"clientRequestId": "PACKAGE-" + stamp, "customerId": customer["id"], "serviceId": service["id"],
                    "name": "自动3次卡", "totalTimes": 3, "price": 120, "payments": [{"method": "微信", "amount": 120}]}
    package_sale = call("/v23/packages/sell", "POST", package_body)
    package_duplicate = call("/v23/packages/sell", "POST", package_body)
    expect(int(package_duplicate["packageId"]) == int(package_sale["packageId"]), "package idempotency failed")
    call(f"/v23/packages/{package_sale['packageId']}/use", "POST", {"remark": "自动验收核销"})
    package = next(row for row in call("/packages") if row["id"] == package_sale["packageId"])
    expect(int(package["used_times"]) == 1 and int(package["total_times"]) == 3, "package use failed")
    summary = call(f"/reports/summary?from={today}&to={today}")
    expect(float(summary["expenses"]) == 2000, "salary commission or refund was deducted twice in operating contribution")

    current = call("/v23/shifts/current")
    expect(current and float(current["summary"]["cash"]) > 0 and float(current["summary"]["wechat"]) == 120, "shift summary is wrong")
    close_body = {"remark": "自动化日结"}
    names = {"cash": "Cash", "wechat": "Wechat", "alipay": "Alipay", "card": "Card", "meituan": "Meituan", "douyin": "Douyin", "other": "Other"}
    for key, suffix in names.items():
        close_body["actual" + suffix] = float(current["summary"][key])
    call(f"/v23/shifts/{current['id']}/close", "POST", close_body)
    expect(call("/v23/shifts/current") is None, "shift did not close")

    call("/users", "POST", {"username": "front_" + stamp, "name": "测试前台", "role": "前台", "password": "123456"})
    admin_token = TOKEN
    login("front_" + stamp, "123456")
    expect_failure(f"/inventory/{product_id}/adjust", "POST", {"type": "入库", "changeQty": 1, "remark": "越权测试"}, "没有此操作权限")
    TOKEN = admin_token

    backup_name = call("/system/backup", "POST", {})
    expect(backup_name.endswith(".zip"), "full backup was not created")
    binary, content_type = raw(f"/system/backups/{backup_name}/download")
    expect(content_type == "application/octet-stream", "backup download content type is wrong")
    with zipfile.ZipFile(io.BytesIO(binary)) as archive:
        names = set(archive.namelist())
        expect("qimutang.db" in names and "backup-info.txt" in names, "full backup content is incomplete")

    print(json.dumps({"status": "passed", "order": order["orderNo"], "package": package_sale["orderNo"], "backup": backup_name}, ensure_ascii=False))


if __name__ == "__main__":
    main()
