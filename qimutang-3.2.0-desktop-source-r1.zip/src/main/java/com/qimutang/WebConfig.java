package com.qimutang;
import org.springframework.context.annotation.Configuration;import org.springframework.web.servlet.config.annotation.*;import org.springframework.beans.factory.annotation.Value;import java.nio.file.*;
@Configuration class WebConfig implements WebMvcConfigurer {
 private final AuthInterceptor auth;private final String uploadUri; WebConfig(AuthInterceptor auth,@Value("${qimutang.data-dir}")String dataDir){this.auth=auth;this.uploadUri=Paths.get(dataDir,"uploads").toAbsolutePath().normalize().toUri().toString();}
 public void addResourceHandlers(ResourceHandlerRegistry r){r.addResourceHandler("/uploads/**").addResourceLocations(uploadUri);}
 public void addInterceptors(InterceptorRegistry r){r.addInterceptor(auth).addPathPatterns("/api/**").excludePathPatterns("/api/auth/login","/api/health","/api/public/branding");}
}
