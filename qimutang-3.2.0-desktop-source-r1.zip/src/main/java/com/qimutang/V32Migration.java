package com.qimutang;

import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.DependsOn;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/** 3.2.0 门店运营版：服务单、审批、排钟、异常、提醒与自定义品牌。 */
@Component
@DependsOn("v25Migration")
class V32Migration {
    private final JdbcTemplate db;
    V32Migration(JdbcTemplate db) { this.db = db; }

    @PostConstruct
    void migrate() {
        create("service_tickets", "create table if not exists service_tickets(" + id() +
                "ticket_no text unique,appointment_id integer,customer_id integer,employee_id integer,workstation_id integer," +
                "items_json text,status text default '待服务',order_id integer,price_approval_id integer,remark text," +
                "created_by integer,started_at text,finished_at text,settled_at text,created_at text,updated_at text,deleted integer default 0)");
        create("operation_approvals", "create table if not exists operation_approvals(" + id() +
                "action_type text not null default '',order_id integer,ticket_id integer,payload_json text,reason text,status text default '待审批'," +
                "requested_by integer,approved_by integer,rejected_by integer,decision_remark text,executed_at text," +
                "created_at text,updated_at text,deleted integer default 0)");
        create("workstations", "create table if not exists workstations(" + id() +
                "name text,workstation_type text,sort_order integer default 0,status text default '空闲',current_ticket_id integer," +
                "created_at text,updated_at text,deleted integer default 0)");
        create("employee_states", "create table if not exists employee_states(" + id() +
                "employee_id integer,work_status text default '候钟',queue_type text default '轮钟',queue_no integer default 0," +
                "workstation_id integer,current_ticket_id integer,updated_by integer,created_at text,updated_at text,deleted integer default 0)");
        create("risk_events", "create table if not exists risk_events(" + id() +
                "event_key text unique,event_type text,severity text,related_type text,related_id integer,title text,detail text," +
                "status text default '待处理',detected_at text,handled_by integer,handled_at text,remark text," +
                "created_at text,updated_at text,deleted integer default 0)");

        DbCompat.ensureColumn(db, "appointments", "ticket_id", "integer");
        DbCompat.ensureColumn(db, "appointments", "converted_at", "text");
        DbCompat.ensureColumn(db, "appointments", "workstation_id", "integer");
        DbCompat.ensureColumn(db, "orders", "source_ticket_id", "integer");
        DbCompat.ensureColumn(db, "orders", "approval_id", "integer");
        DbCompat.ensureColumn(db, "orders", "reversed_at", "text");
        DbCompat.ensureColumn(db, "orders", "reversed_by", "integer");
        DbCompat.ensureColumn(db, "orders", "reverse_reason", "text");
        DbCompat.ensureColumn(db, "followups", "source_type", "text");
        DbCompat.ensureColumn(db, "followups", "source_id", "integer");
        DbCompat.ensureColumn(db, "followups", "source_key", "text");

        DbCompat.createIndexIfMissing(db, "service_tickets", "idx_tickets_status", "status,deleted", false);
        DbCompat.createIndexIfMissing(db, "operation_approvals", "idx_approvals_status", "status,action_type,deleted", false);
        DbCompat.createIndexIfMissing(db, "employee_states", "idx_employee_states_employee", "employee_id,deleted", true);

        String now = LocalDateTime.now().toString();
        for (int i = 1; i <= 2; i++) {
            seedWorkstation("修脚椅" + i, "修脚椅", i, now);
            seedWorkstation("足疗椅" + i, "足疗椅", 10 + i, now);
            seedWorkstation("按摩床" + i, "按摩床", 20 + i, now);
        }
        DbCompat.insertSettingIfMissing(db, "system_name", "齐沐堂门店管理系统", "客户端显示名称", now);
        DbCompat.insertSettingIfMissing(db, "brand_logo", "/qimutang-logo.png", "客户端品牌Logo", now);
        DbCompat.upsertSetting(db, "app_version", "3.2.0", "系统版本", now);
    }

    private String id() { return DbCompat.isMySql(db) ? "id bigint primary key auto_increment," : "id integer primary key autoincrement,"; }
    private void create(String ignored, String sql) { db.execute(DbCompat.isMySql(db) ? DbCompat.mysqlDdl(sql) : sql); }
    private void seedWorkstation(String name, String type, int sort, String now) {
        Integer count = db.queryForObject("select count(*) from workstations where name=? and deleted=0", Integer.class, name);
        if (count != null && count == 0) db.update("insert into workstations(name,workstation_type,sort_order,status,created_at,updated_at,deleted) values(?,?,?,'空闲',?,?,0)", name, type, sort, now, now);
    }
}
