#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const app = read('src/main/resources/static/app.js');
const css = read('src/main/resources/static/app.css');
const v23 = read('src/main/resources/static/v23-pages.js');
const v32 = read('src/main/resources/static/v32-pages.js');
const v33 = read('src/main/resources/static/v33-pages.js');
const pages = read('src/main/resources/static/pages.js');
const api = read('src/main/java/com/qimutang/Api.java');
const operations = read('src/main/java/com/qimutang/OperationsApi.java');
const v33Api = read('src/main/java/com/qimutang/V33Api.java');
const index = read('src/main/resources/static/index.html');
const failures = [];
let checks = 0;
const expect = (condition, message) => { checks += 1; if (!condition) failures.push(message); };

expect(app.includes('data-nav-group'), '缺少侧栏分组折叠结构');
expect(app.includes('side-compact'), '缺少整栏图标模式');
expect(app.includes('UI_STORAGE_KEYS'), '缺少界面状态持久化');
expect(app.includes('scopedUiStorageKey'), '界面状态未按登录账号隔离');
expect(app.includes('reset-layout'), '缺少一键恢复默认布局');
expect(app.includes('data-nav-badge'), '缺少菜单真实待办数');
expect(app.includes('店长: menuGroups.flatMap(group => group.items)'), '店长缺少经营设置入口');
expect(css.includes('.nav-group.is-folded .nav-group-items'), '缺少侧栏折叠样式');
expect(css.includes('body.side-compact .side'), '缺少图标侧栏样式');
expect(css.includes('.panel.is-folded .panel-fold-body'), '缺少页面面板折叠样式');
expect(v33.includes("['basic','品牌与门店'"), '缺少品牌与门店设置分区');
expect(v33.includes("['rules','经营规则'"), '缺少经营规则设置分区');
expect(v33.includes("['access','账号权限'"), '缺少账号权限设置分区');
expect(v33.includes("['data','数据安全'"), '缺少数据安全设置分区');
expect(v33.includes("['license','授权版本'"), '缺少授权版本设置分区');
expect(v33.includes('v332SettingsPage') && v33.includes('data-v332-tab'), '系统设置未按页签懒加载');
expect((v33.match(/data-setting-group/g) || []).length >= 2, '缺少经营规则折叠绑定');
expect(v23.includes("'packages:templates',true"), '会员卡模板未设置默认折叠');
expect(v23.includes("'reports:employees',true"), '员工业绩未设置默认折叠');
expect(v23.includes("'shifts:history',true"), '日结历史未设置默认折叠');
expect(v23.includes('makePanelCollapsible(panel,`care:'), '护理档案未按顾客折叠');
expect(v23.includes('/care-records?customerId='), '护理档案未按选中顾客加载');
expect(v23.includes('/orders/page') && v23.includes('/packages/page'), '订单或会员卡未启用分页');
expect(pages.includes('/customers/page'), '顾客与会员未启用分页');
expect(app.includes('bindCustomerLookup') && !v23.includes("api('/customers')") && !v32.includes("api('/customers')"), '高频页面仍一次加载全部顾客');
expect(operations.includes('@GetMapping("/orders/page")') && operations.includes('@GetMapping("/packages/page")') && operations.includes('@GetMapping("/audit-logs/page")'), '后端分页接口不完整');
expect(api.includes('@GetMapping("/customers/page")'), '顾客分页接口缺失');
expect(v33Api.includes('@GetMapping("/ui-summary")'), '真实菜单统计接口缺失');
expect(v33Api.includes('MANAGER_SETTING_GROUPS'), '店长经营设置权限缺失');
expect(v32.includes("'reminders:cards',true"), '到期卡项未设置默认折叠');
expect(index.includes('app.js?v=3.3.3') && index.includes('v33-pages.js?v=3.3.3'), '静态资源版本未更新为3.3.3');

if (failures.length) {
  console.error(JSON.stringify({status:'failed', failures}, null, 2));
  process.exit(1);
}
console.log(JSON.stringify({status:'passed', checks}, null, 2));
