const API = '/api';
const root = document.getElementById('app');
const pages = {};

const state = {
  user: loadUser(),
  page: '首页',
  cart: [],
  payments: [],
  searchSeed: null,
  checkoutTicket: null,
  branding: { system_name: '齐沐堂门店管理系统', brand_logo: '/qimutang-logo.png' }
};

const menuGroups = [
  { title: '经营', items: ['首页', '服务看板', '收银开单', '订单管理', '预约管理', '交班日结'] },
  { title: '顾客', items: ['顾客档案', '护理档案', '会员管理', '会员卡', '回访提醒', '经营提醒'] },
  { title: '门店', items: ['项目中心', '护理产品', '员工管理', '排钟工位', '采购管理'] },
  { title: '财务', items: ['收支管理', '工资提成', '营业报表'] },
  { title: '风控', items: ['审批中心', '异常中心'] },
  { title: '系统', items: ['系统设置'] }
];

const navMarks = {
  首页: '首', 服务看板: '服', 收银开单: '单', 订单管理: '订', 预约管理: '约', 交班日结: '班',
  顾客档案: '客', 护理档案: '护', 会员管理: '会', 会员卡: '卡', 回访提醒: '访', 经营提醒: '醒',
  项目中心: '项', 护理产品: '品', 员工管理: '员', 排钟工位: '钟', 采购管理: '采',
  收支管理: '账', 工资提成: '薪', 营业报表: '报', 审批中心: '审', 异常中心: '异', 系统设置: '设'
};

const roleMenus = {
  管理员: menuGroups.flatMap(group => group.items),
  店长: menuGroups.flatMap(group => group.items).filter(name => name !== '系统设置'),
  前台: ['首页', '服务看板', '收银开单', '订单管理', '预约管理', '交班日结', '顾客档案', '护理档案',
    '会员管理', '会员卡', '回访提醒', '经营提醒', '排钟工位', '审批中心'],
  技师: ['首页', '服务看板', '预约管理', '顾客档案', '护理档案', '回访提醒', '经营提醒', '排钟工位']
};

function loadUser() {
  try {
    return JSON.parse(localStorage.getItem('qmt_user') || 'null');
  } catch (_) {
    localStorage.removeItem('qmt_user');
    return null;
  }
}

function $(id) {
  return document.getElementById(id);
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
}

function money(value) {
  return `¥${Number(value || 0).toFixed(2)}`;
}

function shortDate(value) {
  if (!value) return '-';
  return String(value).replace('T', ' ').slice(0, 16);
}

function today() {
  const date = new Date();
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function monthStart() {
  return `${today().slice(0, 7)}-01`;
}

function input(id, placeholder, type = 'text', value = '', extra = '') {
  return `<input id="${esc(id)}" type="${esc(type)}" placeholder="${esc(placeholder)}" value="${esc(value)}" ${extra}>`;
}

function select(id, rows, label = 'name', selected = '', firstOption = '') {
  const first = firstOption ? `<option value="">${esc(firstOption)}</option>` : '';
  return `<select id="${esc(id)}">${first}${rows.map(row => {
    const value = typeof row === 'object' ? row.id : row;
    const text = typeof row === 'object' ? row[label] : row;
    return `<option value="${esc(value)}" ${String(value) === String(selected) ? 'selected' : ''}>${esc(text)}</option>`;
  }).join('')}</select>`;
}

function field(label, control, hint = '') {
  return `<label class="field"><span>${esc(label)}</span>${control}${hint ? `<small>${esc(hint)}</small>` : ''}</label>`;
}

function empty(text) {
  return `<div class="empty"><b>暂无数据</b><span>${esc(text)}</span></div>`;
}

function statusTag(value) {
  const text = String(value ?? '-');
  const danger = /取消|退款|停用|爽约|报损|未付款/.test(text);
  const success = /正常|完成|启用|在职|已入库|已支付/.test(text);
  return `<span class="tag ${danger ? 'red' : success ? 'green' : ''}">${esc(text)}</span>`;
}

async function api(path, options = {}) {
  const headers = {
    ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
    ...(options.headers || {})
  };
  if (state.user?.token) headers.Authorization = `Bearer ${state.user.token}`;

  let response;
  try {
    response = await fetch(API + path, { ...options, headers });
  } catch (_) {
    throw new Error('系统服务未启动，请关闭后重新打开齐沐堂系统');
  }

  let payload;
  try {
    payload = await response.json();
  } catch (_) {
    throw new Error(`系统返回异常（HTTP ${response.status}）`);
  }

  if (response.status === 401) {
    localStorage.removeItem('qmt_user');
    state.user = null;
    showLogin();
    throw new Error('登录已失效，请重新登录');
  }
  if (!payload.success) throw new Error(payload.message || '操作失败');
  return payload.data;
}

function toast(text, bad = false) {
  const node = document.createElement('div');
  node.className = `toast ${bad ? 'error' : ''}`;
  node.textContent = text;
  document.body.appendChild(node);
  setTimeout(() => node.remove(), 3000);
}

function showError(error) {
  toast(error?.message || String(error), true);
}

function openGlobalSearch(initialValue = '') {
  if (!state.user) return;
  document.querySelector('.global-search-mask')?.remove();
  const mask = document.createElement('div');
  mask.className = 'modal-mask global-search-mask';
  mask.innerHTML = `<section class="global-search-panel">
    <header><div><b>全局搜索</b><span>顾客姓名、手机号、会员号或订单号</span></div><button type="button" class="icon-button search-close" aria-label="关闭">×</button></header>
    <div class="global-search-box"><span>⌕</span><input id="global-search-input" value="${esc(initialValue)}" placeholder="输入至少2个字符，按 Enter 搜索"><small>Enter</small></div>
    <div id="global-search-results" class="global-search-results"><div class="search-welcome"><b>快速找到经营资料</b><span>按 F3 可随时打开全局搜索</span></div></div>
  </section>`;
  document.body.appendChild(mask);
  const inputNode = $('global-search-input');
  const resultsNode = $('global-search-results');
  const close = () => mask.remove();
  const go = (page, value) => {
    state.searchSeed = { page, value };
    state.page = page;
    close();
    render();
  };
  const run = async () => {
    const keyword = inputNode.value.trim();
    if (keyword.length < 2) {
      resultsNode.innerHTML = '<div class="search-welcome"><b>请输入至少2个字符</b><span>例如顾客姓名、手机号后4位或订单号</span></div>';
      return;
    }
    resultsNode.innerHTML = '<div class="loading"><span></span>正在搜索…</div>';
    try {
      const data = await api(`/search?q=${encodeURIComponent(keyword)}`);
      const customers = data.customers || [];
      const orders = (roleMenus[state.user.role] || []).includes('订单管理') ? (data.orders || []) : [];
      resultsNode.innerHTML = `${customers.length ? `<div class="search-section"><h4>顾客 <small>${customers.length}</small></h4>${customers.map(row => `
        <button type="button" class="search-result" data-search-customer="${esc(row.phone || row.name)}"><span class="search-avatar">${esc((row.name || '客').slice(0, 1))}</span><span><b>${esc(row.name)}</b><small>${esc(row.phone)} · ${esc(row.member_no || '普通顾客')}</small></span><strong>${money(Number(row.balance_principal) + Number(row.balance_gift))}</strong></button>`).join('')}</div>` : ''}
        ${orders.length ? `<div class="search-section"><h4>订单 <small>${orders.length}</small></h4>${orders.map(row => `
        <button type="button" class="search-result" data-search-order="${esc(row.order_no)}"><span class="search-order-mark">订</span><span><b>${esc(row.order_no)}</b><small>${esc(row.customer_name || '散客')} · ${esc(shortDate(row.created_at))}</small></span><strong>${money(row.received)}</strong></button>`).join('')}</div>` : ''}
        ${!customers.length && !orders.length ? '<div class="search-welcome"><b>没有找到匹配资料</b><span>请检查姓名、手机号或订单号</span></div>' : ''}`;
      resultsNode.querySelectorAll('[data-search-customer]').forEach(button => button.addEventListener('click', () => go('顾客档案', button.dataset.searchCustomer)));
      resultsNode.querySelectorAll('[data-search-order]').forEach(button => button.addEventListener('click', () => go('订单管理', button.dataset.searchOrder)));
    } catch (error) {
      resultsNode.innerHTML = `<div class="search-welcome error-panel"><b>搜索失败</b><span>${esc(error.message)}</span></div>`;
    }
  };
  mask.querySelector('.search-close').addEventListener('click', close);
  mask.addEventListener('click', event => { if (event.target === mask) close(); });
  inputNode.addEventListener('keydown', event => {
    if (event.key === 'Enter') run();
    if (event.key === 'Escape') close();
  });
  inputNode.focus();
  if (initialValue.trim().length >= 2) run();
}

function modal(title, body, onSave, options = {}) {
  const mask = document.createElement('div');
  mask.className = 'modal-mask';
  const cancel = options.closable === false ? '' : '<button type="button" class="ghost modal-cancel">取消</button>';
  const close = options.closable === false ? '' : '<button type="button" class="icon-button modal-close" aria-label="关闭">×</button>';
  mask.innerHTML = `<div class="modal ${options.wide ? 'modal-wide' : ''}">
    <div class="modal-head"><h3>${esc(title)}</h3>${close}</div>
    <div class="modal-body">${body}</div>
    <div class="modal-foot">${cancel}<button type="button" class="modal-save">${esc(options.saveText || '保存')}</button></div>
  </div>`;
  document.body.appendChild(mask);
  const closeModal = () => mask.remove();
  mask.querySelector('.modal-close')?.addEventListener('click', closeModal);
  mask.querySelector('.modal-cancel')?.addEventListener('click', closeModal);
  mask.querySelector('.modal-save').addEventListener('click', async event => {
    const button = event.currentTarget;
    button.disabled = true;
    button.textContent = '正在保存…';
    try {
      await onSave(mask);
      if (options.autoClose !== false) closeModal();
    } catch (error) {
      showError(error);
    } finally {
      if (document.body.contains(button)) {
        button.disabled = false;
        button.textContent = options.saveText || '保存';
      }
    }
  });
  return mask;
}

function confirmAction(message) {
  return window.confirm(message);
}

function downloadCsv(filename, columns, rows) {
  const quote = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
  const text = '\ufeff' + [columns.map(column => quote(column.label)).join(','),
    ...rows.map(row => columns.map(column => quote(
      typeof column.value === 'function' ? column.value(row) : row[column.value]
    )).join(','))].join('\r\n');
  const url = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

function showLogin() {
  const brandName = state.branding.system_name || '齐沐堂门店管理系统';
  const brandLogo = state.branding.brand_logo || '/qimutang-logo.png';
  document.title = brandName;
  root.innerHTML = `<div class="login-screen">
    <section class="login-intro">
      <img class="login-logo" src="${esc(brandLogo)}" alt="${esc(brandName)}标志" onerror="this.src='/qimutang-logo.png'">
      <h1>${esc(brandName)}</h1>
      <p>门店经营、顾客护理、会员库存和财务数据，一套系统统一管理。</p>
      <ul><li>本机存储，断网也能用</li><li>每日自动备份</li><li>账号权限与操作留痕</li></ul>
    </section>
    <section class="login-card">
      <div class="mobile-brand"><img src="${esc(brandLogo)}" alt="${esc(brandName)}标志" onerror="this.src='/qimutang-logo.png'"><b>${esc(brandName)}</b></div>
      <h2>登录门店系统</h2>
      <p>请输入账号和密码</p>
      ${field('登录账号', input('login-username', '请输入账号', 'text', 'admin', 'autocomplete="username"'))}
      ${field('登录密码', input('login-password', '请输入密码', 'password', '', 'autocomplete="current-password"'))}
      <button id="login-button" class="wide">登录</button>
      <small class="login-tip">首次运行账号：admin　密码：123456</small>
    </section>
  </div>`;

  const submit = async () => {
    const button = $('login-button');
    button.disabled = true;
    button.textContent = '正在登录…';
    try {
      const username = $('login-username').value.trim();
      const password = $('login-password').value;
      state.user = await api('/auth/login', {
        method: 'POST', body: JSON.stringify({ username, password })
      });
      if (state.user.firstLogin) await forcePasswordChange(password);
      localStorage.setItem('qmt_user', JSON.stringify(state.user));
      state.page = '首页';
      await render();
    } catch (error) {
      showError(error);
      state.user = null;
    } finally {
      if ($('login-button')) {
        button.disabled = false;
        button.textContent = '登录';
      }
    }
  };

  $('login-button').addEventListener('click', submit);
  $('login-password').addEventListener('keydown', event => {
    if (event.key === 'Enter') submit();
  });
}

function forcePasswordChange(oldPassword) {
  return new Promise(resolve => {
    const gate = modal('首次登录，请先修改密码', `
      <div class="notice">为了保护门店营业数据，初始密码不能继续使用。</div>
      ${field('新密码', input('first-password', '至少8位，含字母和数字', 'password'))}
      ${field('再次输入', input('first-password-confirm', '再次输入新密码', 'password'))}
    `, async () => {
      const password = $('first-password').value;
      if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) throw new Error('新密码至少8位，并同时包含字母和数字');
      if (password !== $('first-password-confirm').value) throw new Error('两次输入的密码不一致');
      if (password === oldPassword) throw new Error('新密码不能和初始密码相同');
      await api('/auth/change-password', {
        method: 'POST', body: JSON.stringify({ oldPassword, newPassword: password })
      });
      state.user.firstLogin = false;
      toast('密码修改成功');
      resolve();
    }, { closable: false, saveText: '修改密码并进入系统' });
    gate.querySelector('#first-password')?.focus();
  });
}

function renderShell() {
  const allowed = roleMenus[state.user.role] || [];
  const brandName = state.branding.system_name || '齐沐堂门店管理系统';
  const brandLogo = state.branding.brand_logo || '/qimutang-logo.png';
  document.title = `${state.page} - ${brandName}`;
  root.innerHTML = `<aside class="side">
    <div class="brand"><img src="${esc(brandLogo)}" alt="${esc(brandName)}标志" onerror="this.src='/qimutang-logo.png'"><div><b>${esc(brandName)}</b><small>商业交付版 · MySQL</small></div></div>
    ${allowed.includes('收银开单') ? '<button type="button" class="side-order" id="side-quick-order"><span>＋</span><b>快速开单</b><small>F2</small></button>' : ''}
    <nav>${menuGroups.map(group => {
      const items = group.items.filter(name => allowed.includes(name));
      if (!items.length) return '';
      return `<div class="nav-group"><small>${esc(group.title)}</small>${items.map(name =>
        `<button type="button" class="nav ${state.page === name ? 'active' : ''}" data-page="${esc(name)}"><span class="nav-mark">${esc(navMarks[name] || name.slice(0, 1))}</span><span class="nav-label">${esc(name)}</span></button>`
      ).join('')}</div>`;
    }).join('')}</nav>
    <div class="side-foot"><span class="status-dot"></span><b>MySQL 数据服务正常</b><small>商业交付版 3.3.0</small></div>
  </aside>
  <main class="main">
    <header class="topbar">
      <div class="top-title"><button id="menu-toggle" class="icon-button menu-toggle">☰</button><div><h2>${esc(state.page)}</h2><p>${new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' })}</p></div></div>
      <div class="account"><button type="button" id="top-global-search" class="global-search-trigger"><span>⌕</span><b>搜索顾客、订单</b><small>F3</small></button>${allowed.includes('收银开单') && state.page !== '收银开单' ? '<button id="top-quick-order" class="top-order">＋ 开单</button>' : ''}<span><b>${esc(state.user.name)}</b><small>${esc(state.user.role)}</small></span><button id="logout-button" class="ghost">退出</button></div>
    </header>
    <section id="content"><div class="loading"><span></span>正在加载…</div></section>
  </main>`;

  document.querySelectorAll('[data-page]').forEach(button => {
    button.addEventListener('click', async () => {
      state.page = button.dataset.page;
      document.body.classList.remove('menu-open');
      await render();
    });
  });
  $('logout-button').addEventListener('click', () => {
    localStorage.removeItem('qmt_user');
    state.user = null;
    showLogin();
  });
  $('menu-toggle').addEventListener('click', () => document.body.classList.toggle('menu-open'));
  $('top-global-search')?.addEventListener('click', () => openGlobalSearch());
  const goOrder = async () => { state.page = '收银开单'; document.body.classList.remove('menu-open'); await render(); };
  $('side-quick-order')?.addEventListener('click', goOrder);
  $('top-quick-order')?.addEventListener('click', goOrder);
}

async function render() {
  if (!state.user) return showLogin();
  const allowed = roleMenus[state.user.role] || [];
  if (!allowed.includes(state.page)) state.page = '首页';
  renderShell();
  try {
    const page = pages[state.page] || pages['首页'];
    await page();
  } catch (error) {
    const content = $('content');
    if (content) content.innerHTML = `<div class="panel error-panel"><h3>页面加载失败</h3><p>${esc(error.message)}</p><button onclick="render()">重新加载</button></div>`;
  }
}

async function bootstrap() {
  document.addEventListener('keydown', event => {
    if (state.user && (event.key === 'F3' || (event.ctrlKey && event.key.toLowerCase() === 'k'))) {
      event.preventDefault(); openGlobalSearch(); return;
    }
    if (event.key === 'F2' && state.user && (roleMenus[state.user.role] || []).includes('收银开单')) {
      event.preventDefault(); state.page = '收银开单'; render();
    }
  });
  try { state.branding = {...state.branding, ...(await api('/public/branding'))}; } catch (_) { /* 使用默认品牌 */ }
  state.user ? render() : showLogin();
}
