package com.qimutang;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

@RestController
@RequestMapping("/api/v33")
class V33Api {
    private static final Map<String,List<String>> GROUPS=Map.of(
            "store",List.of("store_name","store_phone","store_address","store_business_hours","receipt_header","receipt_footer"),
            "checkout",List.of("order_prefix","payment_methods","cash_rounding","frontdesk_discount_limit","manager_discount_limit","allow_debt","refund_days"),
            "member",List.of("balance_deduct_order","dormant_customer_days","card_expiry_notice_days"),
            "service",List.of("appointment_slot_minutes","appointment_cancel_hours","queue_mode","workstation_auto_release"),
            "inventory",List.of("negative_stock_allowed","low_stock_default","expiry_notice_days","auto_consumables"),
            "risk",List.of("night_start","night_end","frequent_refund_count","privacy_photo_requires_approval"),
            "system",List.of("session_timeout_minutes","login_max_failures","backup_hour","backup_retention_days","backup_external_path","diagnostic_redact","update_channel"),
            "device",List.of("receipt_paper_width","receipt_copies","printer_name","barcode_enabled")
    );
    private static final Set<String> BOOLEANS=Set.of("allow_debt","workstation_auto_release","negative_stock_allowed","auto_consumables","privacy_photo_requires_approval","diagnostic_redact","barcode_enabled");
    private static final Map<String,int[]> INTS=Map.ofEntries(
            Map.entry("frontdesk_discount_limit",new int[]{0,100}),Map.entry("manager_discount_limit",new int[]{0,100}),
            Map.entry("refund_days",new int[]{0,3650}),Map.entry("dormant_customer_days",new int[]{1,3650}),
            Map.entry("card_expiry_notice_days",new int[]{1,365}),Map.entry("appointment_slot_minutes",new int[]{5,240}),
            Map.entry("appointment_cancel_hours",new int[]{0,168}),Map.entry("low_stock_default",new int[]{0,999999}),
            Map.entry("expiry_notice_days",new int[]{1,730}),Map.entry("frequent_refund_count",new int[]{2,99}),
            Map.entry("session_timeout_minutes",new int[]{15,1440}),Map.entry("login_max_failures",new int[]{3,20}),
            Map.entry("backup_hour",new int[]{0,23}),Map.entry("backup_retention_days",new int[]{7,3650}),
            Map.entry("receipt_copies",new int[]{1,5})
    );

    private final JdbcTemplate db;private final SettingsService settings;private final LicenseService licenses;
    private final BusinessGuard businessGuard;private final BackupService backups;private final AuditIntegrityService auditIntegrity;
    private final SystemStatusService systemStatus;private final ObjectMapper json;private final Path dataDir;
    V33Api(JdbcTemplate db,SettingsService settings,LicenseService licenses,BusinessGuard businessGuard,
           BackupService backups,AuditIntegrityService auditIntegrity,SystemStatusService systemStatus,ObjectMapper json,
           @org.springframework.beans.factory.annotation.Value("${qimutang.data-dir}")String dataDir){
        this.db=db;this.settings=settings;this.licenses=licenses;this.businessGuard=businessGuard;this.backups=backups;
        this.auditIntegrity=auditIntegrity;this.systemStatus=systemStatus;this.json=json;this.dataDir=Path.of(dataDir).toAbsolutePath().normalize();
    }

    private Map<String,Object>ok(Object value){return Map.of("success",true,"data",value);}private Map<String,Object>fail(String value){return Map.of("success",false,"message",value);}
    private long uid(HttpServletRequest r){Object v=r.getAttribute("userId");if(!(v instanceof Number))throw new IllegalArgumentException("登录已失效");return((Number)v).longValue();}
    private String role(HttpServletRequest r){return Objects.toString(r.getAttribute("role"),"");}
    private void require(HttpServletRequest r,String...roles){if(Arrays.stream(roles).noneMatch(role(r)::equals))throw new IllegalArgumentException("当前账号没有此操作权限");}
    private String text(Object v){return Objects.toString(v,"").trim();}private String now(){return LocalDateTime.now().toString();}
    private BigDecimal money(Object value){try{return new BigDecimal(text(value)).setScale(2,RoundingMode.HALF_UP);}catch(Exception e){throw new IllegalArgumentException("金额格式不正确");}}
    private void log(HttpServletRequest r,String type,String content){String n=now();db.update("insert into audit_logs(user_id,type,content,ip,created_at,updated_at) values(?,?,?,?,?,?)",uid(r),type,content,r.getRemoteAddr(),n,n);}

    @GetMapping("/settings")
    Object getSettings(HttpServletRequest r){require(r,"管理员");Map<String,Object>out=new LinkedHashMap<>();out.put("values",settings.all());out.put("groups",GROUPS);out.put("history",db.queryForList("select s.*,u.name operator_name from setting_changes s left join users u on u.id=s.operator_id where s.deleted=0 order by s.id desc limit 200"));return ok(out);}

    @PutMapping("/settings/{group}")
    Object saveSettings(@PathVariable String group,@RequestBody Map<String,Object>body,HttpServletRequest r){
        require(r,"管理员");List<String>keys=GROUPS.get(group);if(keys==null)return fail("设置分组不存在");
        Object raw=body.get("values");if(!(raw instanceof Map<?,?>values))return fail("设置内容格式不正确");String reason=text(body.get("reason"));if(reason.length()<2)return fail("请填写修改原因");
        for(String key:keys){if(!values.containsKey(key))continue;String value=validateSetting(key,text(values.get(key)));settings.update(key,value,key,reason,uid(r));}
        log(r,"系统设置","修改"+group+"设置；原因："+reason);return ok("设置已保存；新规则只用于之后产生的业务数据");
    }

    @GetMapping("/license") Object license(HttpServletRequest r){require(r,"管理员");return ok(licenses.state());}
    @PostMapping("/license/activate") Object activate(@RequestBody Map<String,Object>body,HttpServletRequest r)throws Exception{require(r,"管理员");Map<String,Object>state=licenses.activate(text(body.get("activationCode")),uid(r));log(r,"软件授权","激活授权："+state.get("licenseId")+"，"+state.get("type"));return ok(state);}

    @GetMapping("/system/status")Object status(HttpServletRequest r){require(r,"管理员");return ok(systemStatus.status());}
    @GetMapping("/audit/verify")Object auditVerify(HttpServletRequest r){require(r,"管理员");return ok(auditIntegrity.verify());}

    @GetMapping("/business-days")Object businessDays(HttpServletRequest r){require(r,"管理员","店长");return ok(db.queryForList("select b.*,l.name locker_name,u.name unlocker_name from business_day_locks b left join users l on l.id=b.locked_by left join users u on u.id=b.unlocked_by where b.deleted=0 order by b.business_date desc limit 365"));}
    @PostMapping("/business-days/{date}/lock")Object lockDay(@PathVariable String date,@RequestBody Map<String,Object>body,HttpServletRequest r){require(r,"管理员","店长");LocalDate day=LocalDate.parse(date);if(day.isAfter(LocalDate.now()))return fail("不能锁定未来账期");String n=now();Integer count=db.queryForObject("select count(*) from business_day_locks where business_date=? and deleted=0",Integer.class,date);if(count!=null&&count>0)db.update("update business_day_locks set status='已锁定',locked_by=?,locked_at=?,remark=?,updated_at=? where business_date=?",uid(r),n,text(body.get("remark")),n,date);else db.update("insert into business_day_locks(business_date,status,locked_by,locked_at,remark,created_at,updated_at,deleted) values(?,'已锁定',?,?,?,?,?,0)",date,uid(r),n,text(body.get("remark")),n,n);db.update("update orders set locked=1 where business_date=? and deleted=0",date);log(r,"账期锁定","锁定营业日"+date);return ok("账期已锁定，历史订单只能查看");}
    @PostMapping("/business-days/{date}/unlock")Object unlockDay(@PathVariable String date,@RequestBody Map<String,Object>body,HttpServletRequest r){require(r,"管理员","店长");long approvalId=Long.parseLong(text(body.get("approvalId")));List<Map<String,Object>> approvals=db.queryForList("select payload_json from operation_approvals where id=? and action_type='解锁账期' and status='已通过' and deleted=0",approvalId);if(approvals.isEmpty())return fail("请先提交并通过解锁账期审批");String payload=text(approvals.get(0).get("payload_json"));if(!payload.contains("\"businessDate\":\""+date+"\""))return fail("该审批单不是当前账期的解锁审批");String n=now();db.update("update business_day_locks set status='已解锁',unlocked_by=?,unlocked_at=?,unlock_approval_id=?,updated_at=? where business_date=? and deleted=0",uid(r),n,approvalId,n,date);db.update("update orders set locked=0 where business_date=? and deleted=0",date);log(r,"账期解锁","解锁营业日"+date+"，审批#"+approvalId);return ok("账期已按审批解锁");}

    @GetMapping("/services/{serviceId}/consumables")
    Object serviceConsumables(@PathVariable long serviceId,HttpServletRequest r){require(r,"管理员","店长");return ok(db.queryForList("select sc.*,i.name inventory_name,i.unit,i.quantity stock from service_consumables sc join inventory i on i.id=sc.inventory_id where sc.service_id=? and sc.deleted=0 and i.deleted=0 order by i.name",serviceId));}

    @PutMapping("/services/{serviceId}/consumables")
    @Transactional
    Object saveServiceConsumables(@PathVariable long serviceId,@RequestBody Map<String,Object>body,HttpServletRequest r){require(r,"管理员","店长");if(db.queryForObject("select count(*) from services where id=? and deleted=0",Integer.class,serviceId)==0)return fail("服务项目不存在");Object raw=body.get("items");if(!(raw instanceof List<?>items))return fail("耗材配置格式不正确");String n=now();db.update("update service_consumables set deleted=1,updated_at=? where service_id=? and deleted=0",n,serviceId);Set<Long>seen=new HashSet<>();for(Object value:items){if(!(value instanceof Map<?,?>item))continue;long inventoryId=Long.parseLong(text(item.get("inventoryId")));if(!seen.add(inventoryId))return fail("同一耗材不能重复配置");BigDecimal quantity=money(item.get("quantity"));if(quantity.signum()<=0)return fail("单次耗材数量必须大于0");if(db.queryForObject("select count(*) from inventory where id=? and deleted=0",Integer.class,inventoryId)==0)return fail("耗材商品不存在");db.update("insert into service_consumables(service_id,inventory_id,quantity,enabled,created_at,updated_at,deleted) values(?,?,?,1,?,?,0)",serviceId,inventoryId,quantity,n,n);}log(r,"服务耗材","更新服务ID "+serviceId+"的自动耗材配置");return ok("服务耗材规则已保存，之后结账将按规则自动扣减");}

    @PostMapping("/privacy/requests")
    Object privacyRequest(@RequestBody Map<String,Object>body,HttpServletRequest r){require(r,"管理员","店长","前台");long customerId=Long.parseLong(text(body.get("customerId")));String type=text(body.get("requestType"));if(!List.of("删除护理照片","导出个人资料","撤回隐私同意").contains(type))return fail("隐私申请类型不正确");String reason=text(body.get("reason"));if(reason.length()<2)return fail("请填写申请原因");String n=now();db.update("insert into privacy_requests(customer_id,request_type,scope,reason,status,requested_by,created_at,updated_at,deleted) values(?,?,?,?,'待审批',?,?,?,0)",customerId,type,text(body.get("scope")),reason,uid(r),n,n);log(r,"隐私申请",type+"，顾客ID "+customerId);return ok("隐私申请已提交，完成审批前不会删除原始资料");}

    @GetMapping("/privacy/requests")
    Object privacyRequests(HttpServletRequest r){require(r,"管理员","店长");return ok(db.queryForList("select p.*,c.name customer_name,u.name requester_name from privacy_requests p join customers c on c.id=p.customer_id left join users u on u.id=p.requested_by where p.deleted=0 order by p.id desc limit 300"));}

    @PostMapping("/backups/{name}/verify")
    Object verifyBackup(@PathVariable String name,HttpServletRequest r)throws Exception{require(r,"管理员");Path file=backups.resolveBackup(name);Map<String,Object>result=verifyBackupFile(file);String n=now();db.update("insert into backup_verifications(file_name,file_size,sha256,status,detail,verified_by,verified_at,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,0)",name,Files.size(file),result.get("sha256"),result.get("status"),result.get("detail"),uid(r),n,n,n);log(r,"备份校验",name+"："+result.get("status"));return ok(result);}

    @PostMapping("/diagnostics")
    Object diagnostics(HttpServletRequest r)throws Exception{require(r,"管理员");Path dir=dataDir.resolve("diagnostics");Files.createDirectories(dir);String name="qimutang-diagnostic-"+LocalDateTime.now().toString().replace(":","-")+".zip";Path out=dir.resolve(name).normalize();try(ZipOutputStream zip=new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(out)))){addText(zip,"system-status.json",json.writerWithDefaultPrettyPrinter().writeValueAsString(systemStatus.status()));addText(zip,"audit-integrity.json",json.writerWithDefaultPrettyPrinter().writeValueAsString(auditIntegrity.verify()));addLog(zip,dataDir.resolve("logs/qimutang.log"),"logs/qimutang.log");addLog(zip,dataDir.resolve("logs/desktop-startup.log"),"logs/desktop-startup.log");Path mysql=dataDir.getParent()==null?dataDir.resolve("mysql-error.log"):dataDir.getParent().resolve("logs/mysql-error.log");addLog(zip,mysql,"logs/mysql-error.log");}
        String n=now();db.update("insert into diagnostic_events(error_code,event_type,severity,summary,detail,status,created_at,updated_at,deleted) values(?, '诊断包','信息','生成脱敏诊断包',?,'已处理',?,?,0)","DIA-"+System.currentTimeMillis(),name,n,n);log(r,"系统诊断","生成诊断包："+name);return ok(Map.of("fileName",name,"message","诊断包已生成，不包含顾客数据库和护理照片"));}

    @GetMapping("/diagnostics/{name}/download")ResponseEntity<Resource>downloadDiagnostic(@PathVariable String name,HttpServletRequest r)throws Exception{require(r,"管理员");if(!name.matches("qimutang-diagnostic-[A-Za-z0-9_.-]+\\.zip"))throw new IllegalArgumentException("诊断文件名不正确");Path root=dataDir.resolve("diagnostics").normalize(),file=root.resolve(name).normalize();if(!file.startsWith(root)||!Files.isRegularFile(file))throw new IllegalArgumentException("诊断包不存在");return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,ContentDisposition.attachment().filename(name,StandardCharsets.UTF_8).build().toString()).contentType(MediaType.APPLICATION_OCTET_STREAM).contentLength(Files.size(file)).body(new FileSystemResource(file));}

    @PostMapping("/customers/merge")
    @Transactional
    Object mergeCustomers(@RequestBody Map<String,Object>body,HttpServletRequest r)throws Exception{
        require(r,"管理员","店长");long source=Long.parseLong(text(body.get("sourceCustomerId"))),target=Long.parseLong(text(body.get("targetCustomerId")));if(source==target)return fail("不能合并同一个顾客");String reason=text(body.get("reason"));if(reason.length()<2)return fail("请填写合并原因");
        Map<String,Object>s;Map<String,Object>t;try{s=db.queryForMap("select * from customers where id=? and deleted=0",source);t=db.queryForMap("select * from customers where id=? and deleted=0",target);}catch(Exception e){return fail("源顾客或目标顾客不存在");}
        String snapshot=json.writeValueAsString(Map.of("source",s,"target",t));String n=now();
        for(String table:List.of("orders","care_records","followups","appointments","packages","balance_logs"))db.update("update "+table+" set customer_id=? where customer_id=?",target,source);
        BigDecimal principal=money(s.getOrDefault("balance_principal",0)),gift=money(s.getOrDefault("balance_gift",0));db.update("update customers set balance_principal=balance_principal+?,balance_gift=balance_gift+?,visit_count=visit_count+?,total_spent=total_spent+?,updated_at=? where id=?",principal,gift,s.getOrDefault("visit_count",0),s.getOrDefault("total_spent",0),n,target);db.update("update customers set balance_principal=0,balance_gift=0,deleted=1,updated_at=? where id=?",n,source);
        db.update("insert into customer_merge_logs(source_customer_id,target_customer_id,snapshot_json,operator_id,reason,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,0)",source,target,snapshot,uid(r),reason,n,n);log(r,"顾客合并",s.get("name")+"合并到"+t.get("name")+"；"+reason);return ok("顾客档案已安全合并，订单、护理档案、卡项和余额已转入目标顾客");
    }

    @PostMapping("/purchases/{purchaseId}/pay")
    @Transactional
    Object payPurchase(@PathVariable long purchaseId,@RequestBody Map<String,Object>body,HttpServletRequest r){require(r,"管理员","店长");Map<String,Object>p;try{p=db.queryForMap("select * from purchases where id=? and deleted=0",purchaseId);}catch(Exception e){return fail("采购单不存在");}BigDecimal total=money(p.get("total_amount")),paid=money(p.getOrDefault("paid_amount",0)),amount=money(body.get("amount"));if(amount.signum()<=0||paid.add(amount).compareTo(total)>0)return fail("付款金额超过采购单剩余应付");String method=text(body.getOrDefault("paymentMethod","银行卡")),date=text(body.getOrDefault("businessDate",LocalDate.now().toString()));businessGuard.assertWritable(LocalDate.parse(date));String n=now();db.update("insert into supplier_payments(supplier_id,purchase_id,amount,payment_method,business_date,operator_id,remark,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,0)",p.get("supplier_id"),purchaseId,amount,method,date,uid(r),text(body.get("remark")),n,n);BigDecimal after=paid.add(amount);db.update("update purchases set paid_amount=?,status=?,updated_at=? where id=?",after,after.compareTo(total)>=0?"已付清":"部分付款",n,purchaseId);if(p.get("supplier_id")!=null)db.update("update suppliers set balance_due=case when balance_due>=? then balance_due-? else 0 end,updated_at=? where id=?",amount,amount,n,p.get("supplier_id"));db.update("insert into finance_records(business_date,direction,category,amount,payment_method,operator_id,remark,created_at,updated_at,deleted) values(?,'支出','采购付款',?,?,?,?,?, ?,0)",date,amount,method,uid(r),"采购单"+p.get("purchase_no"),n,n);log(r,"采购付款",p.get("purchase_no")+"付款"+amount);return ok("采购付款已登记，剩余应付："+total.subtract(after));}

    @GetMapping("/reports/advanced")
    Object advancedReport(@RequestParam String from,@RequestParam String to,HttpServletRequest r){require(r,"管理员","店长");LocalDate.parse(from);LocalDate.parse(to);Map<String,Object>out=new LinkedHashMap<>();out.put("payments",db.queryForList("select method,sum(amount) amount from payments where deleted=0 and date(created_at) between date(?) and date(?) group by method order by amount desc",from,to));out.put("refundPayments",db.queryForList("select method,sum(amount) amount from refund_payments where deleted=0 and date(created_at) between date(?) and date(?) group by method order by amount desc",from,to));out.put("memberLiability",db.queryForMap("select coalesce(sum(balance_principal),0) principal,coalesce(sum(balance_gift),0) gift,coalesce(sum(balance_principal+balance_gift),0) total from customers where deleted=0"));out.put("supplierDebt",db.queryForObject("select coalesce(sum(balance_due),0) from suppliers where deleted=0",BigDecimal.class));out.put("inventoryValue",db.queryForObject("select coalesce(sum(quantity*cost_price),0) from inventory where deleted=0",BigDecimal.class));out.put("platformIncome",db.queryForList("select method,sum(amount) gross from payments where deleted=0 and method in ('美团','抖音') and date(created_at) between date(?) and date(?) group by method",from,to));out.put("lockedDays",db.queryForList("select business_date,status,locked_at from business_day_locks where deleted=0 and date(business_date) between date(?) and date(?) order by business_date",from,to));return ok(out);}

    @GetMapping("/expiring-batches")Object expiringBatches(HttpServletRequest r){require(r,"管理员","店长","前台");int days=settings.integer("expiry_notice_days",60);String cutoff=LocalDate.now().plusDays(days).toString();return ok(db.queryForList("select b.*,i.name inventory_name,i.unit from product_batches b join inventory i on i.id=b.inventory_id where b.deleted=0 and b.remaining_quantity>0 and b.expires_at is not null and b.expires_at<>'' and substr(b.expires_at,1,10)<=? order by b.expires_at",cutoff));}

    private String validateSetting(String key,String value){
        if(value.length()>500)throw new IllegalArgumentException(key+"内容过长");if(BOOLEANS.contains(key)){if(!List.of("true","false").contains(value))throw new IllegalArgumentException(key+"只能开启或关闭");return value;}
        int[]range=INTS.get(key);if(range!=null){int n;try{n=Integer.parseInt(value);}catch(Exception e){throw new IllegalArgumentException(key+"必须填写整数");}if(n<range[0]||n>range[1])throw new IllegalArgumentException(key+"范围应为"+range[0]+"至"+range[1]);}
        if(List.of("night_start","night_end").contains(key)&&!value.matches("(?:[01]\\d|2[0-3]):[0-5]\\d"))throw new IllegalArgumentException("时间格式应为HH:mm");
        if("balance_deduct_order".equals(key)&&!List.of("GIFT_FIRST","PRINCIPAL_FIRST").contains(value))throw new IllegalArgumentException("余额扣款顺序不正确");
        if("queue_mode".equals(key)&&!List.of("轮钟","点钟","手工").contains(value))throw new IllegalArgumentException("排钟方式不正确");
        if("update_channel".equals(key)&&!List.of("正式版","测试版").contains(value))throw new IllegalArgumentException("更新通道不正确");
        if("receipt_paper_width".equals(key)&&!List.of("58","80").contains(value))throw new IllegalArgumentException("小票纸宽只支持58或80毫米");
        return value;
    }

    private Map<String,Object>verifyBackupFile(Path file)throws Exception{MessageDigest digest=MessageDigest.getInstance("SHA-256");try(var in=new BufferedInputStream(Files.newInputStream(file))){byte[]buf=new byte[1024*1024];int n;while((n=in.read(buf))>0)digest.update(buf,0,n);}String hash=HexFormat.of().formatHex(digest.digest());String status="通过",detail="文件可读取";if(file.getFileName().toString().endsWith(".zip")){try(ZipFile zip=new ZipFile(file.toFile(),StandardCharsets.UTF_8)){boolean hasDb=zip.getEntry("mysql-data.jsonl")!=null||zip.getEntry("qimutang.db")!=null;if(!hasDb){status="失败";detail="备份包缺少数据库数据";}else{var entries=zip.entries();while(entries.hasMoreElements()){ZipEntry e=entries.nextElement();try(var in=zip.getInputStream(e)){in.transferTo(new ByteArrayOutputStream());}}detail="压缩结构和数据库入口完整，共"+zip.size()+"个文件";}}catch(Exception e){status="失败";detail="压缩包损坏："+e.getMessage();}}return Map.of("status",status,"detail",detail,"sha256",hash,"size",Files.size(file));}
    private void addText(ZipOutputStream zip,String name,String value)throws Exception{zip.putNextEntry(new ZipEntry(name));zip.write(value.getBytes(StandardCharsets.UTF_8));zip.closeEntry();}
    private void addLog(ZipOutputStream zip,Path file,String name)throws Exception{if(!Files.isRegularFile(file))return;byte[]bytes=Files.readAllBytes(file);if(bytes.length>1024*1024)bytes=Arrays.copyOfRange(bytes,bytes.length-1024*1024,bytes.length);String text=new String(bytes,StandardCharsets.UTF_8).replaceAll("(?<!\\d)(1\\d{2})\\d{4}(\\d{4})(?!\\d)","$1****$2").replaceAll("(?i)(password|pwd|secret|token)([=: ]+)[^\\s,;]+","$1$2***");addText(zip,name,text);}
}

@RestController
class V33PublicApi {
    private final LicenseService licenses;
    V33PublicApi(LicenseService licenses){this.licenses=licenses;}
    @GetMapping("/api/public/license")Object license(){return Map.of("success",true,"data",licenses.state());}
}
