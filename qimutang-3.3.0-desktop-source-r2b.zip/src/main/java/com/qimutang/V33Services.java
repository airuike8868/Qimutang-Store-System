package com.qimutang;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileStore;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

@Service
class SettingsService {
    private final JdbcTemplate db;
    SettingsService(JdbcTemplate db) { this.db = db; }

    Map<String,String> all() {
        Map<String,String> out = new LinkedHashMap<>();
        String sql = DbCompat.isMySql(db) ? "select `key`,value from settings where deleted=0" :
                "select key,value from settings where deleted=0";
        db.queryForList(sql).forEach(row -> out.put(Objects.toString(row.get("key"), ""), Objects.toString(row.get("value"), "")));
        return out;
    }

    String get(String key, String fallback) { return all().getOrDefault(key, fallback); }
    int integer(String key, int fallback) { try { return Integer.parseInt(get(key, String.valueOf(fallback))); } catch (Exception ignored) { return fallback; } }
    boolean bool(String key, boolean fallback) { String value=get(key,String.valueOf(fallback));return "true".equalsIgnoreCase(value)||"1".equals(value)||"是".equals(value); }

    void update(String key, String value, String description, String reason, long operatorId) {
        String old = get(key, "");
        if (Objects.equals(old, value)) return;
        String now = LocalDateTime.now().toString();
        DbCompat.upsertSetting(db, key, value, description, now);
        db.update("insert into setting_changes(setting_key,old_value,new_value,reason,operator_id,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,0)",
                key, old, value, reason, operatorId, now, now);
    }
}

@Service
class JwtKeyService {
    private final Path keyFile;
    JwtKeyService(@Value("${qimutang.data-dir}")String dataDir){this.keyFile=Path.of(dataDir).toAbsolutePath().normalize().resolve("security/jwt.key");}
    synchronized SecretKey key(){
        try{
            Files.createDirectories(keyFile.getParent());
            if(!Files.isRegularFile(keyFile)){byte[]raw=new byte[64];new SecureRandom().nextBytes(raw);Files.writeString(keyFile,Base64.getEncoder().encodeToString(raw),StandardCharsets.US_ASCII,StandardOpenOption.CREATE_NEW);}
            byte[]raw=Base64.getDecoder().decode(Files.readString(keyFile,StandardCharsets.US_ASCII).trim());if(raw.length<32)throw new IllegalStateException("登录密钥长度不正确");return new SecretKeySpec(raw,"HmacSHA256");
        }catch(Exception e){throw new IllegalStateException("无法读取本机登录安全密钥",e);}
    }
}

@Service
class BusinessGuard {
    private final JdbcTemplate db;
    BusinessGuard(JdbcTemplate db) { this.db = db; }
    void assertWritable(LocalDate date) {
        Integer count = db.queryForObject("select count(*) from business_day_locks where business_date=? and status='已锁定' and deleted=0", Integer.class, date.toString());
        if (count != null && count > 0) throw new IllegalArgumentException(date + " 已完成日结并锁定，不能继续改账；请由店长发起解锁审批");
    }
}

@Service
class LicenseService {
    private final JdbcTemplate db;
    private final SettingsService settings;
    private final Path dataDir;
    private final PublicKey publicKey;

    LicenseService(JdbcTemplate db, SettingsService settings, @Value("${qimutang.data-dir}") String dataDir) throws Exception {
        this.db=db;this.settings=settings;this.dataDir=Path.of(dataDir).toAbsolutePath().normalize();
        this.publicKey=loadPublicKey();
    }

    Map<String,Object> state() {
        String type=settings.get("license_type","试用版");
        String start=settings.get("license_start_date",LocalDate.now().toString());
        String expiry=settings.get("license_expires_date",LocalDate.now().plusDays(30).toString());
        int grace=Math.max(0,settings.integer("license_grace_days",7));
        LocalDate today=LocalDate.now();
        boolean permanent="永久版".equals(type);
        LocalDate end=permanent?LocalDate.of(2999,12,31):safeDate(expiry,today.minusDays(1));
        long remaining=permanent?999999:ChronoUnit.DAYS.between(today,end);
        boolean active=permanent||!today.isAfter(end);
        boolean graceActive=!active&&!today.isAfter(end.plusDays(grace));
        String status=active?("试用版".equals(type)?"试用中":"有效"):graceActive?"宽限期":"已到期";
        Map<String,Object> out=new LinkedHashMap<>();
        out.put("licenseId",settings.get("license_id",""));out.put("type",type);out.put("startDate",start);
        out.put("expiresDate",permanent?"永久":expiry);out.put("graceDays",grace);out.put("remainingDays",remaining);
        out.put("status",status);out.put("canOperate",active||graceActive);out.put("deviceId",deviceId());
        out.put("boundDevice",settings.get("license_bound_device",""));out.put("features",settings.get("license_features","STANDARD"));
        out.put("message",active?(permanent?"永久授权已生效":"授权正常，剩余"+Math.max(0,remaining)+"天"):
                graceActive?"授权已到期，当前处于"+grace+"天宽限期":"授权已到期；历史查询、导出和备份仍可使用");
        return out;
    }

    boolean canOperate() { return Boolean.TRUE.equals(state().get("canOperate")); }

    void requireOperation(String method, String uri) {
        if ("GET".equalsIgnoreCase(method)||"HEAD".equalsIgnoreCase(method)||"OPTIONS".equalsIgnoreCase(method)) return;
        if (uri.startsWith("/api/auth/")||uri.startsWith("/api/v33/license/")||uri.equals("/api/system/backup")||uri.startsWith("/api/v33/diagnostics")) return;
        if (!canOperate()) throw new IllegalArgumentException("软件授权已到期，当前仅允许查询、导出和备份；请输入续费授权码后继续经营操作");
    }

    synchronized Map<String,Object> activate(String activationCode, long userId) throws Exception {
        String code=Objects.toString(activationCode,"").trim();String[] parts=code.split("\\.");
        if(parts.length!=2)throw new IllegalArgumentException("授权码格式不正确");
        byte[] payload=Base64.getUrlDecoder().decode(parts[0]);byte[] signed=Base64.getUrlDecoder().decode(parts[1]);
        Signature verifier=Signature.getInstance("SHA256withRSA");verifier.initVerify(publicKey);verifier.update(payload);
        if(!verifier.verify(signed))throw new IllegalArgumentException("授权码签名无效，请联系软件发布方重新获取");
        String text=new String(payload,StandardCharsets.UTF_8);String[] fields=text.split("\\|",-1);
        if(fields.length!=10||!"QMT1".equals(fields[0]))throw new IllegalArgumentException("授权码版本不受支持");
        String licenseId=fields[1],type=fields[2],store=fields[3],requestedDevice=fields[4],start=fields[5],expiry=fields[6],graceText=fields[7],features=fields[8],nonce=fields[9];
        if(!List.of("月度版","年度版","永久版","试用版").contains(type))throw new IllegalArgumentException("授权类型不正确");
        LocalDate.parse(start);if(!"永久版".equals(type))LocalDate.parse(expiry);int grace=Integer.parseInt(graceText);if(grace<0||grace>30)throw new IllegalArgumentException("宽限期不正确");
        String device=deviceId();if(!"*".equals(requestedDevice)&&!device.equals(requestedDevice))throw new IllegalArgumentException("授权码与当前电脑不匹配，当前设备编号："+device);
        String now=LocalDateTime.now().toString();String hash=sha256(code.getBytes(StandardCharsets.UTF_8));
        Integer used=db.queryForObject("select count(*) from license_activations where activation_code_hash=? and status='已激活' and deleted=0",Integer.class,hash);
        if(used!=null&&used>0)return state();
        settings.update("license_id",licenseId,"授权编号","导入签名授权码",userId);settings.update("license_type",type,"软件授权类型","导入签名授权码",userId);
        settings.update("license_start_date",start,"授权开始日期","导入签名授权码",userId);settings.update("license_expires_date",expiry,"授权到期日期","导入签名授权码",userId);
        settings.update("license_grace_days",String.valueOf(grace),"授权宽限天数","导入签名授权码",userId);settings.update("license_bound_device",device,"授权绑定设备","导入签名授权码",userId);
        settings.update("license_features",features,"授权功能集合","导入签名授权码",userId);
        db.update("insert into license_activations(license_id,license_type,store_name,device_id,start_date,expires_date,grace_days,features,activation_code_hash,status,activated_by,activated_at,created_at,updated_at,deleted) values(?,?,?,?,?,?,?,?,?,'已激活',?,?,?,?,0)",
                licenseId,type,store,device,start,expiry,grace,features,hash,userId,now,now,now);
        return state();
    }

    String deviceId() {
        try {
            Path dir=dataDir.resolve("license");Files.createDirectories(dir);Path file=dir.resolve("device.id");
            if(!Files.isRegularFile(file))Files.writeString(file,"QMT-"+UUID.randomUUID().toString().replace("-","").toUpperCase(),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
            return Files.readString(file,StandardCharsets.UTF_8).trim();
        } catch(Exception e){throw new IllegalStateException("无法读取本机设备编号",e);}
    }

    private PublicKey loadPublicKey() throws Exception {
        try(InputStream in=getClass().getResourceAsStream("/qimutang-license-public.pem")){
            if(in==null)throw new IllegalStateException("安装包缺少授权公钥");String pem=new String(in.readAllBytes(),StandardCharsets.US_ASCII)
                    .replace("-----BEGIN PUBLIC KEY-----","").replace("-----END PUBLIC KEY-----","").replaceAll("\\s+","");
            return KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(pem)));
        }
    }
    private LocalDate safeDate(String value, LocalDate fallback){try{return LocalDate.parse(value);}catch(Exception ignored){return fallback;}}
    static String sha256(byte[] bytes){try{return java.util.HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));}catch(Exception e){throw new IllegalStateException(e);}}
}

@Service
class AuditIntegrityService {
    private final JdbcTemplate db;
    AuditIntegrityService(JdbcTemplate db){this.db=db;}

    @Scheduled(fixedDelay=60000, initialDelay=5000)
    synchronized void sealNewLogs(){
        String previous="GENESIS";List<String> hashes=db.query("select event_hash from audit_logs where event_hash is not null and event_hash<>'' order by id desc limit 1",(rs,i)->rs.getString(1));if(!hashes.isEmpty())previous=hashes.get(0);
        for(Map<String,Object>row:db.queryForList("select * from audit_logs where event_hash is null or event_hash='' order by id")){
            long id=((Number)row.get("id")).longValue();String canonical=id+"|"+Objects.toString(row.get("user_id"),"")+"|"+Objects.toString(row.get("type"),"")+"|"+Objects.toString(row.get("content"),"")+"|"+Objects.toString(row.get("ip"),"")+"|"+Objects.toString(row.get("created_at"),"")+"|"+previous;
            String hash=LicenseService.sha256(canonical.getBytes(StandardCharsets.UTF_8));db.update("update audit_logs set previous_hash=?,event_hash=?,sealed_at=? where id=? and (event_hash is null or event_hash='')",previous,hash,LocalDateTime.now().toString(),id);previous=hash;
        }
    }

    Map<String,Object> verify(){
        sealNewLogs();String previous="GENESIS";int checked=0;
        for(Map<String,Object>row:db.queryForList("select * from audit_logs order by id")){
            long id=((Number)row.get("id")).longValue();String canonical=id+"|"+Objects.toString(row.get("user_id"),"")+"|"+Objects.toString(row.get("type"),"")+"|"+Objects.toString(row.get("content"),"")+"|"+Objects.toString(row.get("ip"),"")+"|"+Objects.toString(row.get("created_at"),"")+"|"+previous;
            String actual=LicenseService.sha256(canonical.getBytes(StandardCharsets.UTF_8));if(!Objects.equals(previous,Objects.toString(row.get("previous_hash"),""))||!Objects.equals(actual,Objects.toString(row.get("event_hash"),"")))return Map.of("valid",false,"checked",checked,"brokenAt",id,"message","操作日志校验失败，记录可能被修改");
            previous=actual;checked++;
        }
        return Map.of("valid",true,"checked",checked,"message","操作日志链完整");
    }
}

@Service
class SystemStatusService {
    private final JdbcTemplate db;private final Path dataDir;private final LicenseService licenses;
    SystemStatusService(JdbcTemplate db,@Value("${qimutang.data-dir}")String dataDir,LicenseService licenses){this.db=db;this.dataDir=Path.of(dataDir).toAbsolutePath().normalize();this.licenses=licenses;}
    Map<String,Object> status(){
        Map<String,Object> out=new LinkedHashMap<>();out.put("version","3.3.0");out.put("database",DbCompat.isMySql(db)?"MySQL":"SQLite");out.put("databaseReady",databaseReady());out.put("dataDirectory",dataDir.toString());out.put("license",licenses.state());
        try{FileStore store=Files.getFileStore(dataDir);out.put("diskFreeBytes",store.getUsableSpace());out.put("diskHealthy",store.getUsableSpace()>1024L*1024*1024);}catch(Exception e){out.put("diskHealthy",false);}
        out.put("logsDirectory",dataDir.resolve("logs").toString());out.put("backupDirectory",dataDir.resolve("backup").toString());return out;
    }
    private boolean databaseReady(){try{Integer one=db.queryForObject("select 1",Integer.class);return one!=null&&one==1;}catch(Exception ignored){return false;}}
}
