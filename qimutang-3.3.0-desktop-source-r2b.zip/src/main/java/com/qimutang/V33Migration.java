package com.qimutang;

import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.DependsOn;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/** 3.3.0 商业交付层：授权、规则配置、账期锁定、诊断、批次、导入和审计完整性。 */
@Component
@DependsOn("v32Migration")
class V33Migration {
    private final JdbcTemplate db;

    V33Migration(JdbcTemplate db) { this.db = db; }

    @PostConstruct
    void migrate() {
        create("create table if not exists setting_changes(" + id() +
                "setting_key varchar(191),old_value text,new_value text,reason text,operator_id integer," +
                "created_at varchar(40),updated_at varchar(40),deleted integer default 0)");
        create("create table if not exists business_day_locks(" + id() +
                "business_date text unique,status text default '已锁定',locked_by integer,locked_at text," +
                "unlocked_by integer,unlocked_at text,unlock_approval_id integer,remark text," +
                "created_at text,updated_at text,deleted integer default 0)");
        create("create table if not exists license_activations(" + id() +
                "license_id text,license_type text,store_name text,device_id text,start_date text,expires_date text," +
                "grace_days integer default 7,features text,activation_code_hash text,status text," +
                "activated_by integer,activated_at text,created_at text,updated_at text,deleted integer default 0)");
        create("create table if not exists diagnostic_events(" + id() +
                "error_code text,event_type text,severity text,summary text,detail text,status text default '待处理'," +
                "handled_by integer,handled_at text,created_at text,updated_at text,deleted integer default 0)");
        create("create table if not exists customer_merge_logs(" + id() +
                "source_customer_id integer,target_customer_id integer,snapshot_json text,operator_id integer,reason text," +
                "created_at text,updated_at text,deleted integer default 0)");
        create("create table if not exists import_jobs(" + id() +
                "import_type text,file_name text,total_rows integer default 0,success_rows integer default 0," +
                "failed_rows integer default 0,error_json text,status text,operator_id integer," +
                "created_at text,updated_at text,deleted integer default 0)");
        create("create table if not exists product_batches(" + id() +
                "inventory_id integer,purchase_id integer,batch_no text,quantity decimal default 0,remaining_quantity decimal default 0," +
                "unit_cost decimal default 0,produced_at text,expires_at varchar(40),status text default '正常'," +
                "created_at text,updated_at text,deleted integer default 0)");
        create("create table if not exists supplier_payments(" + id() +
                "supplier_id integer,purchase_id integer,amount decimal default 0,payment_method text,business_date text," +
                "operator_id integer,remark text,created_at text,updated_at text,deleted integer default 0)");
        create("create table if not exists service_consumables(" + id() +
                "service_id integer,inventory_id integer,quantity decimal default 1,enabled integer default 1," +
                "created_at text,updated_at text,deleted integer default 0)");
        create("create table if not exists backup_verifications(" + id() +
                "file_name text,file_size integer,sha256 text,status text,detail text,verified_by integer,verified_at text," +
                "created_at text,updated_at text,deleted integer default 0)");
        create("create table if not exists privacy_requests(" + id() +
                "customer_id integer,request_type text,scope text,reason text,status text default '待审批'," +
                "requested_by integer,approved_by integer,completed_at text,created_at text,updated_at text,deleted integer default 0)");

        DbCompat.ensureColumn(db, "users", "login_failed_count", "integer default 0");
        DbCompat.ensureColumn(db, "users", "locked_until", "text");
        DbCompat.ensureColumn(db, "users", "password_changed_at", "text");
        DbCompat.ensureColumn(db, "orders", "rule_snapshot", "text");
        DbCompat.ensureColumn(db, "orders", "locked", "integer default 0");
        DbCompat.ensureColumn(db, "refunds", "approval_id", "integer");
        DbCompat.ensureColumn(db, "purchases", "paid_amount", "decimal default 0");
        DbCompat.ensureColumn(db, "purchases", "due_date", "text");
        DbCompat.ensureColumn(db, "purchases", "batch_no", "text");
        DbCompat.ensureColumn(db, "purchases", "expires_at", "text");
        DbCompat.ensureColumn(db, "inventory", "category_id", "integer");
        DbCompat.ensureColumn(db, "package_templates", "card_mode", "text default 'COUNT'");
        DbCompat.ensureColumn(db, "package_templates", "daily_limit", "integer default 1");
        DbCompat.ensureColumn(db, "packages", "card_mode", "text default 'COUNT'");
        DbCompat.ensureColumn(db, "packages", "daily_limit", "integer default 1");
        DbCompat.ensureColumn(db, "package_logs", "service_id", "integer");
        DbCompat.ensureColumn(db, "suppliers", "balance_due", "decimal default 0");
        DbCompat.ensureColumn(db, "customers", "privacy_consent", "integer default 0");
        DbCompat.ensureColumn(db, "customers", "privacy_consent_at", "text");
        DbCompat.ensureColumn(db, "care_records", "consent_version", "text");
        DbCompat.ensureColumn(db, "care_records", "photo_visibility", "text default '护理人员可见'");
        DbCompat.ensureColumn(db, "audit_logs", "previous_hash", "text");
        DbCompat.ensureColumn(db, "audit_logs", "event_hash", "text");
        DbCompat.ensureColumn(db, "audit_logs", "sealed_at", "text");

        seedBusinessCategories();
        db.update("update services set category_id=(select min(c.id) from categories c where c.type='SERVICE' and c.name=services.category and c.deleted=0) where category_id is null");
        db.update("update inventory set category_id=(select min(c.id) from categories c where c.type='PRODUCT' and c.name=inventory.category and c.deleted=0) where category_id is null");

        DbCompat.createIndexIfMissing(db, "setting_changes", "idx_setting_changes_key", "setting_key,created_at", false);
        DbCompat.createIndexIfMissing(db, "business_day_locks", "idx_business_day_lock_date", "business_date,deleted", true);
        DbCompat.createIndexIfMissing(db, "product_batches", "idx_batches_inventory", "inventory_id,expires_at,deleted", false);
        DbCompat.createIndexIfMissing(db, "supplier_payments", "idx_supplier_payments_purchase", "purchase_id,deleted", false);
        DbCompat.createIndexIfMissing(db, "service_consumables", "idx_consumables_service", "service_id,inventory_id,deleted", true);
        DbCompat.createIndexIfMissing(db, "services", "idx_services_category", "category_id,status,deleted", false);
        DbCompat.createIndexIfMissing(db, "inventory", "idx_inventory_category", "category_id,retail_enabled,deleted", false);

        seedSettings();
        DbCompat.upsertSetting(db, "app_version", "3.3.0", "系统版本", LocalDateTime.now().toString());
    }

    private void seedSettings() {
        String now = LocalDateTime.now().toString();
        Map<String, String[]> values = new LinkedHashMap<>();
        values.put("store_business_hours", new String[]{"09:00-22:00", "门店营业时间"});
        values.put("receipt_header", new String[]{"感谢光临", "小票顶部文字"});
        values.put("receipt_footer", new String[]{"护理服务请按约定时间回访", "小票底部文字"});
        values.put("order_prefix", new String[]{"QM", "订单编号前缀"});
        values.put("payment_methods", new String[]{"微信,支付宝,现金,银行卡,美团,抖音,会员余额,其他", "启用的付款方式"});
        values.put("cash_rounding", new String[]{"0.01", "现金抹零精度"});
        values.put("frontdesk_discount_limit", new String[]{"0", "前台最大优惠百分比"});
        values.put("manager_discount_limit", new String[]{"20", "店长最大优惠百分比"});
        values.put("allow_debt", new String[]{"false", "是否允许挂账"});
        values.put("refund_days", new String[]{"30", "允许退款天数"});
        values.put("balance_deduct_order", new String[]{"GIFT_FIRST", "余额扣款顺序"});
        values.put("dormant_customer_days", new String[]{"60", "沉睡顾客天数"});
        values.put("card_expiry_notice_days", new String[]{"30", "卡项到期提醒天数"});
        values.put("appointment_slot_minutes", new String[]{"30", "预约时间间隔"});
        values.put("appointment_cancel_hours", new String[]{"2", "预约取消提前小时"});
        values.put("queue_mode", new String[]{"轮钟", "默认排钟方式"});
        values.put("workstation_auto_release", new String[]{"true", "结账后自动释放工位"});
        values.put("negative_stock_allowed", new String[]{"false", "是否允许负库存"});
        values.put("low_stock_default", new String[]{"5", "默认库存预警线"});
        values.put("expiry_notice_days", new String[]{"60", "临期提醒天数"});
        values.put("auto_consumables", new String[]{"true", "服务结账自动扣耗材"});
        values.put("night_start", new String[]{"23:00", "深夜操作开始时间"});
        values.put("night_end", new String[]{"06:00", "深夜操作结束时间"});
        values.put("frequent_refund_count", new String[]{"2", "频繁退款判定次数"});
        values.put("session_timeout_minutes", new String[]{"720", "登录有效分钟数"});
        values.put("login_max_failures", new String[]{"5", "连续登录失败锁定次数"});
        values.put("backup_hour", new String[]{"2", "每日自动备份小时"});
        values.put("backup_retention_days", new String[]{"90", "备份保留天数"});
        values.put("backup_external_path", new String[]{"", "外部备份目录"});
        values.put("receipt_paper_width", new String[]{"80", "小票纸宽毫米"});
        values.put("receipt_copies", new String[]{"1", "小票打印份数"});
        values.put("printer_name", new String[]{"", "默认小票打印机"});
        values.put("barcode_enabled", new String[]{"true", "是否启用扫码枪"});
        values.put("privacy_photo_requires_approval", new String[]{"true", "删除护理照片需要审批"});
        values.put("diagnostic_redact", new String[]{"true", "诊断包隐藏敏感资料"});
        values.put("update_channel", new String[]{"正式版", "软件更新通道"});
        values.put("license_type", new String[]{"试用版", "软件授权类型"});
        values.put("license_start_date", new String[]{LocalDate.now().toString(), "授权开始日期"});
        values.put("license_expires_date", new String[]{LocalDate.now().plusDays(30).toString(), "授权到期日期"});
        values.put("license_grace_days", new String[]{"7", "授权宽限天数"});
        values.put("license_id", new String[]{"TRIAL-" + LocalDate.now(), "授权编号"});
        values.put("license_bound_device", new String[]{"", "授权绑定设备"});
        values.put("license_features", new String[]{"STANDARD", "授权功能集合"});
        values.forEach((key, value) -> DbCompat.insertSettingIfMissing(db, key, value[0], value[1], now));
    }

    private void seedBusinessCategories() {
        String now = LocalDateTime.now().toString();
        DbCompat.insertCategoryIfMissing(db, "SERVICE", "脚病修复", 15, now);
        DbCompat.insertCategoryIfMissing(db, "PRODUCT", "护理产品", 10, now);
    }

    private String id() { return DbCompat.isMySql(db) ? "id bigint primary key auto_increment," : "id integer primary key autoincrement,"; }
    private void create(String sql) { db.execute(DbCompat.isMySql(db) ? DbCompat.mysqlDdl(sql) : sql); }
}
