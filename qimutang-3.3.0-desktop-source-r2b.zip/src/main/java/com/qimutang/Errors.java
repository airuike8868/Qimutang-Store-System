package com.qimutang;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.Map;

@RestControllerAdvice
class Errors {
    private static final Logger log = LoggerFactory.getLogger(Errors.class);

    @ExceptionHandler(IllegalArgumentException.class)
    Map<String, Object> business(IllegalArgumentException e) {
        return Map.of("success", false, "message", e.getMessage());
    }

    @ExceptionHandler({NoResourceFoundException.class, HttpRequestMethodNotSupportedException.class})
    Map<String, Object> clientVersionMismatch(Exception e) {
        log.warn("客户端请求与当前后台版本不匹配: {}", e.getMessage());
        return Map.of(
                "success", false,
                "message", "客户端页面缓存与后台版本不一致，请关闭软件后重新打开"
        );
    }

    @ExceptionHandler(Exception.class)
    Map<String, Object> other(Exception e) {
        log.error("系统操作失败", e);
        return Map.of("success", false, "message", "操作失败，请检查输入数据或联系管理员");
    }
}
