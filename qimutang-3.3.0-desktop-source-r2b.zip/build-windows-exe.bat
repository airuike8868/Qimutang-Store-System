@echo off
setlocal EnableExtensions
chcp 65001 >nul
where java >nul 2>nul || (echo 未检测到 JDK 17。& if not defined CI pause & exit /b 1)
where mvn >nul 2>nul || (echo 未检测到 Maven 3.9+。& if not defined CI pause & exit /b 1)
where jpackage >nul 2>nul || (echo 当前 JDK 不包含 jpackage，请安装完整 JDK 17。& if not defined CI pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\preflight-windows-mysql.ps1"
if errorlevel 1 (echo MySQL 发布前环境检查失败。& if not defined CI pause & exit /b 1)
echo [1/3] 编译齐沐堂门店管理系统 3.3.0 MySQL商业版...
call mvn clean package
if errorlevel 1 exit /b 1
if exist package-input rmdir /s /q package-input
mkdir package-input
copy /y target\qimutang.jar package-input\qimutang.jar >nul
copy /y start-qimutang.cmd package-input\start-qimutang.cmd >nul
xcopy /e /i /y scripts package-input\scripts >nul
echo [2/3] 生成 Windows 应用镜像...
if exist dist rmdir /s /q dist
jpackage --type app-image --name "齐沐堂门店管理系统" --app-version 3.3.0 --vendor "齐沐堂" --description "齐沐堂单店 MySQL 商业门店管理系统" --input package-input --main-jar qimutang.jar --dest dist --icon "packaging\qimutang.ico" --java-options "-Dfile.encoding=UTF-8"
if errorlevel 1 exit /b 1
echo [3/3] 完成。首次使用前请运行 scripts\configure-mysql-windows.ps1 配置 MySQL 8。
echo 注意：正式门店发布前仍需在 Windows 11 + MySQL 8 真机执行回归验收。
if not defined CI pause
